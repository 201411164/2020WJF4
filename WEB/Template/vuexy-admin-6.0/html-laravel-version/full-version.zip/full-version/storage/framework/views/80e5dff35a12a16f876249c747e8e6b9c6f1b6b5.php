<?php $__env->startSection('title', 'i18n'); ?>

<?php $__env->startSection('content'); ?>
<!-- internationalization -->
<section id="internationalization">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Change Locale</h4>
        </div>
        <div class="card-body">
          <div class="language-options checkbox">
            <div class="custom-control custom-radio mb-50">
              <input
                type="radio"
                id="i18n-lang-radio1"
                name="i18n-lang-radios"
                class="custom-control-input i18n-lang-option"
                data-lng="en_p"
                checked
              />
              <label class="custom-control-label" for="i18n-lang-radio1">English</label>
            </div>
            <div class="custom-control custom-radio mb-50">
              <input
                type="radio"
                id="i18n-lang-radio2"
                name="i18n-lang-radios"
                class="custom-control-input i18n-lang-option"
                data-lng="fr_p"
              />
              <label class="custom-control-label" for="i18n-lang-radio2">French</label>
            </div>
            <div class="custom-control custom-radio mb-50">
              <input
                type="radio"
                id="i18n-lang-radio3"
                name="i18n-lang-radios"
                class="custom-control-input i18n-lang-option"
                data-lng="de_p"
              />
              <label class="custom-control-label" for="i18n-lang-radio3">German</label>
            </div>
            <div class="custom-control custom-radio mb-50">
              <input
                type="radio"
                id="i18n-lang-radio4"
                name="i18n-lang-radios"
                class="custom-control-input i18n-lang-option"
                data-lng="pt_p"
              />
              <label class="custom-control-label" for="i18n-lang-radio4">Portuguese</label>
            </div>
          </div>

          <div class="card-localization border rounded mt-3 p-2">
            <h5 class="mb-1">Title</h5>
            <p class="card-text" data-i18n="key">
              Cake sesame snaps cupcake gingerbread danish I love gingerbread. Apple pie pie jujubes chupa chups muffin
              halvah lollipop. Chocolate cake oat cake tiramisu marzipan sugar plum. Donut sweet pie oat cake dragée
              fruitcake cotton candy lemon drops.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ internationalization -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
  <!-- Page js files -->
  <script src="<?php echo e(asset(mix('js/scripts/extensions/ext-component-i18n.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//content/extensions/ext-component-i18n.blade.php ENDPATH**/ ?>