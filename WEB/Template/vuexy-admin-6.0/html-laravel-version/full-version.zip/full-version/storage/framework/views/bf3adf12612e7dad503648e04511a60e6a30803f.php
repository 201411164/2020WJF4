
<div class="buy-now">
    <a href="https://1.envato.market/vuexy_admin" target="_blank" class="btn btn-danger">Buy Now</a>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-versions/vuexy-admin-v5.4 2/html-laravel-version-new/full-version/resources/views/content/pages/buy-now.blade.php ENDPATH**/ ?>