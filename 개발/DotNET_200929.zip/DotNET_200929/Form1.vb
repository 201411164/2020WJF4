﻿Public Class Form1
    Public vCompany As SAPbobsCOM.Company

    Private Sub bt_Connection_Click(sender As Object, e As EventArgs) Handles bt_Connection.Click

        vCompany = New SAPbobsCOM.Company

        'Initialize the Company Object for the Connect method
        vCompany.Server = "77106151-PC\MSSQLSERVER_2017"
        vCompany.CompanyDB = "SBODemoKR"
        vCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017
        vCompany.UserName = "manager"
        vCompany.Password = "manager"

        Dim nResult As Long
        Dim strErrString As String

        'Connect to the database
        nResult = vCompany.Connect

        'Display the result
        MsgBox("result is " + Str(nResult))
        Call vCompany.GetLastError(nResult, strErrString)
        MsgBox("GetLastError(" + Str(nResult) + ", " + strErrString + ")")
    End Sub

    Private Sub bt_Select_Click(sender As Object, e As EventArgs) Handles bt_Select.Click
        Dim Count As Long
        Dim FldName As String
        Dim FldVal As String
        Dim FldName1 As String
        Dim FldVal1 As String
        Dim i As Integer
        Dim RecSet As SAPbobsCOM.Recordset
        RecSet = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        RecSet.DoQuery("select * from OADM")

        Count = RecSet.Fields.Count
        While RecSet.EoF = False

            'The inner loop runs over all the fields in one record (line) of the table
            For i = 0 To Count - 1
                FldName = RecSet.Fields.Item(i).Name
                FldVal = RecSet.Fields.Item(i).Value
                FldName1 += FldName + " "
                FldVal1 += FldVal + " "

                'Here you can manipulate the data as you want
            Next i
            'Move to the next record
            RecSet.MoveNext()
        End While

        MessageBox.Show(FldName1 + vbLf + FldVal1)
    End Sub

    Private Sub bt_SP_Click(sender As Object, e As EventArgs) Handles bt_SP.Click

        Dim Form2 As New Form2()
        Form2.Show()

    End Sub
End Class
