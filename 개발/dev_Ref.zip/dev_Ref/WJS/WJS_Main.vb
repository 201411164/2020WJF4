﻿Option Strict Off
Option Explicit On

Imports AddOnBase
Imports SAPbobsCOM
Imports SAPbouiCOM
Imports System.Xml
Imports System.Windows.Forms
Imports System.Reflection


Public Class WJS_Main

    Inherits B1AddOn

    Public Sub New()
        MyBase.New()
        'ADD YOUR INITIALIZATION CODE HERE	...
    End Sub

    Public Overrides Sub OnShutDown()
        'ADD YOUR TERMINATION CODE HERE	...
        System.Windows.Forms.Application.Exit()
    End Sub

    Public Overrides Sub OnCompanyChanged()
        Dim Form As SAPbouiCOM.Form = Nothing
        Dim i As Integer = 0

        Try

            For i = 0 To B1Connections.theAppl.Forms.Count - 1 Step 1

                If B1Connections.theAppl.Forms.Item(i).TypeEx = "169" Then
                    Form = B1Connections.theAppl.Forms.Item(i)
                    Exit For
                End If

            Next

            B1Connections.Reinit()

            If Not IsNothing(Form) Then
                Form.Freeze(True)
            End If

            B1AddOn.Moduleinit()

            If Not IsNothing(Form) Then
                Form.Freeze(False)
                Form.Update()
            End If

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
        Finally
            Form = Nothing
        End Try
    End Sub


    Public Overrides Sub OnLanguageChanged(ByVal language As SAPbouiCOM.BoLanguages)
        Dim Form As SAPbouiCOM.Form = Nothing
        Dim i As Integer = 0

        Try

            For i = 0 To B1Connections.theAppl.Forms.Count - 1 Step 1

                If B1Connections.theAppl.Forms.Item(i).TypeEx = "169" Then
                    Form = B1Connections.theAppl.Forms.Item(i)
                    Exit For
                End If

            Next

            B1Connections.Reinit()

            If Not IsNothing(Form) Then
                Form.Freeze(True)
            End If

            B1AddOn.Moduleinit()

            If Not IsNothing(Form) Then
                Form.Freeze(False)
                Form.Update()
            End If

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
        Finally
            Form = Nothing
        End Try
    End Sub

    Public Overrides Sub OnStatusBarErrorMessage(ByVal txt As String)
        'ADD YOUR CODE HERE	...
    End Sub

    Public Overrides Sub OnStatusBarSuccessMessage(ByVal txt As String)
        'ADD YOUR CODE HERE	...
    End Sub

    Public Overrides Sub OnStatusBarWarningMessage(ByVal txt As String)
        'ADD YOUR CODE HERE	...
    End Sub

    Public Overrides Sub OnStatusBarNoTypedMessage(ByVal txt As String)
        'ADD YOUR CODE HERE	...
    End Sub

    Public Overrides Function OnBeforeProgressBarCreated() As Boolean
        'ADD YOUR CODE HERE	...
        Return True
    End Function

    Public Overrides Function OnAfterProgressBarCreated() As Boolean
        'ADD YOUR CODE HERE	...
        Return True
    End Function

    Public Overrides Function OnBeforeProgressBarStopped(ByVal success As Boolean) As Boolean
        'ADD YOUR CODE HERE	...
        Return True
    End Function

    Public Overrides Function OnAfterProgressBarStopped(ByVal success As Boolean) As Boolean
        'ADD YOUR CODE HERE	...
        Return True
    End Function

    Public Overrides Function OnProgressBarReleased() As Boolean
        'ADD YOUR CODE HERE	...
        Return True
    End Function


    Public Shared Sub Main()
        Dim retCode As Integer = 0
        Dim connStr As String = ""
        Dim diRequired As Boolean = True
        Dim itheApiProcessId As Integer = 0
        Dim bProcessId As Boolean = False
        'CHANGE ADDON IDENTIFIER BEFORE RELEASING TO CUSTOMER (Solution Identifier)
        Dim addOnIdentifierStr As String = "5645523035446576656C6F706D656E743A4730393036313732343831B8E4AFB3C2130B13E287247A4" & _
            "43CA06CB6C5B9FD"

        ' 디버깅 Command Argument 설정: 0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056

        If (System.Environment.GetCommandLineArgs().Length < 3) Then '보다 작으면 AddOn Patch 사용하지 않음.
            connStr = B1Connections.connStr
            itheApiProcessId = -1
        Else '패치 사용함. [0]: 실행경로, [1]:SBO Connection String, [2]:AddOn Patch Clinet에서 연결된 SBO UI API Process ID

            connStr = B1Connections.connStr
            If IsNumeric(System.Environment.GetCommandLineArgs().GetValue(2).ToString()) Then
                bProcessId = True
                itheApiProcessId = Integer.Parse(System.Environment.GetCommandLineArgs().GetValue(2).ToString())
            Else
                bProcessId = False
                itheApiProcessId = -1
            End If

        End If

        Try

#If DEBUG Then
            If bProcessId = True Then
                retCode = B1Connections.Init(connStr, addOnIdentifierStr, diRequired, itheApiProcessId)
            Else
                retCode = B1Connections.Init(connStr, addOnIdentifierStr, diRequired)
            End If
#Else
            If bProcessId = True Then
                retCode = B1Connections.Init(connStr, addOnIdentifierStr, B1Connections.ConnectionType.MultipleAddOns, itheApiProcessId)
            Else
                retCode = B1Connections.Init(connStr, addOnIdentifierStr, B1Connections.ConnectionType.MultipleAddOns)
            End If
#End If


            'CONNECTION FAILED
            If (retCode <> 0) Then
                System.Windows.Forms.MessageBox.Show("ERROR - Connection failed: " + B1Connections.diCompany.GetLastErrorDescription())
                Return
            End If

            Dim addOn As WJS_Main = New WJS_Main
            System.Windows.Forms.Application.Run()


        Catch com_err As System.Runtime.InteropServices.COMException
            'HANDLE ANY COMException HERE
            System.Windows.Forms.MessageBox.Show("ERROR - Connection failed: " + com_err.Message)
        Catch ex As Exception
            'HANDLE ANY COMException HERE
            System.Windows.Forms.MessageBox.Show("ERROR - Connection failed: " + ex.Message)
        End Try
    End Sub


End Class
