
Imports System.IO
Imports System.Net

Imports VB = Microsoft.VisualBasic

Public Class WJSBO_DIAPI
    Private oCompany As SAPbobsCOM.Company

    'Dim oCompany As New SAPbobsCOM.Company

    Private Sub WJSBOBatchServiceExe_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PollingPass()
    End Sub

    Private Sub Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button.Click
        PollingPass()
    End Sub


    'INI ��Ʈ���� �о���� ���� API ����
    Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" _
        (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, _
        ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer



    'INI ��Ʈ���� ����ϱ� ���� API ����
    Public Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" _
        (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpString As String, ByVal lpFileName As String) As Integer

    Public Function INIRead(ByVal Session As String, ByVal KeyValue As String, ByVal INIFILE As String) As String

        'INI �� �б�

        Dim s As New String("", 1024)


        Dim ReturnValue As Long

        ReturnValue = GetPrivateProfileString(Session, KeyValue, "", s, 1024, INIFILE)

        Return Mid(s, 1, InStr(s, Chr(0)) - 1)

    End Function



    '*************************************************************
    '�Լ���:    PollProcess 
    '��  ��:    
    '��  ��:    
    '��  ��:    
    '������:    
    '������:    

    '������:
    '*************************************************************
    Private Sub PollingPass()

        '-----------------------------------------------------------------------------
        '-- SBO ���� ����
        '-----------------------------------------------------------------------------

        Dim AppPath As String = Application.StartupPath


        Try

            '������
            oCompany = New SAPbobsCOM.Company

            oCompany.Server = "77106152-PC\MSSQLSERVER_2017"
            oCompany.language = SAPbobsCOM.BoSuppLangs.ln_Korean_Kr
            'oCompany.UseTrusted = True
            oCompany.CompanyDB = "DEV_TEST01"
            oCompany.LicenseServer = "localhost"
            oCompany.UserName = "manager"
            oCompany.Password = "1111"
            oCompany.DbUserName = "sa"
            oCompany.DbPassword = "root"
            oCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017

            If oCompany.Connect <> 0 Then
                MsgBox(oCompany.GetLastErrorDescription)
                If oCompany.Connected Then
                    oCompany.Disconnect()
                End If

                System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany)

                oCompany = Nothing

                Me.Dispose()
                Me.Close()

                Exit Sub

            Else
                'MsgBox("1")
            End If



        Catch ex As System.Exception
            MsgBox(Err.Description)

            If oCompany.Connected Then
                oCompany.Disconnect()
            End If

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany)

            oCompany = Nothing

            Me.Dispose()
            Me.Close()

        Finally


        End Try


        '-----------------------------------------------------------------------------
        '-- SBO ���� ��
        '-----------------------------------------------------------------------------
        Dim xSQL As String = ""
        Dim oRS As SAPbobsCOM.Recordset = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim i As Integer = 0
        'OITEM
        Dim oITEM As SAPbobsCOM.Items = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)


        'Try
        '    If oITEM.GetByKey("TEST00001") Then
        '        oITEM.ItemName = "TEST00001"
        '        oITEM.UserFields.Fields.Item("U_SPEC").Value = "LKH"
        '        oITEM.UserFields.Fields.Item("U_SURFACE1").Value = "4444"
        '        'oITEM.UserFields.Fields.Item("U_PERMITDT").Value = "4444"
        '        If oITEM.Update <> 0 Then
        '            MsgBox(oCompany.GetLastErrorDescription)
        '        Else
        '            MsgBox("���� �Ϸ�")

        '        End If
        '    Else
        '        oITEM.ItemCode = "TEST00001"
        '        oITEM.ItemName = "TEST00001"

        '        oITEM.ItemType = SAPbobsCOM.ItemTypeEnum.itItems

        '        oITEM.SalesItem = SAPbobsCOM.BoYesNoEnum.tYES
        '        oITEM.PurchaseItem = SAPbobsCOM.BoYesNoEnum.tYES
        '        oITEM.InventoryItem = SAPbobsCOM.BoYesNoEnum.tYES


        '        If oITEM.Add <> 0 Then
        '            MsgBox(oCompany.GetLastErrorDescription)
        '        Else
        '            MsgBox("Add completed")
        '        End If

        '    End If
        'Catch ex As System.Exception
        '    MsgBox(Err.Description)

        'Finally
        '    System.Runtime.InteropServices.Marshal.ReleaseComObject(oITEM)
        '    oITEM = Nothing

        'End Try

        'Dim oBP As SAPbobsCOM.BusinessPartners = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)

        'Try

        '    If oBP.GetByKey("TEST_BP_00001") Then
        '        oBP.CardCode = "TEST_BP_00001"
        '        oBP.CardForeignName = "LKH"
        '        If oBP.Update <> 0 Then
        '            MsgBox(oCompany.GetLastErrorDescription)
        '        Else
        '            MsgBox("BP ���� �Ϸ�")
        '        End If
        '    Else
        '        oBP.CardCode = "TEST_BP_00001"
        '        oBP.CardName = "TEST_BP_00001"


        '        If oBP.Add <> 0 Then
        '            MsgBox(oCompany.GetLastErrorDescription)
        '        Else
        '            MsgBox("BP ���� �Ϸ�")
        '        End If
        '    End If



        'Catch ex As System.Exception
        '    MsgBox(Err.Description)


        'Finally

        '    System.Runtime.InteropServices.Marshal.ReleaseComObject(oBP)
        '    oBP = Nothing

        'End Try


        ''-----------------------------------------------------------------------------
        ''-- �Ǹſ��� ����� ����
        ''-----------------------------------------------------------------------------

        'Dim oORDR As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders)

        ''Try


        ''    xSQL = ""

        ''    xSQL = xSQL & "SELECT  T0.CardCode," & vbCrLf
        ''    xSQL = xSQL & "        T1.ItemCode," & vbCrLf
        ''    xSQL = xSQL & "        T1.Quantity," & vbCrLf
        ''    xSQL = xSQL & "        T1.LineTotal" & vbCrLf
        ''    xSQL = xSQL & "FROM ORDR T0" & vbCrLf
        ''    xSQL = xSQL & "INNER JOIN RDR1 T1 ON T0.DocEntry = T1.DocEntry" & vbCrLf
        ''    xSQL = xSQL & "WHERE T0.DocEntry = '1'" & vbCrLf


        ''    oRS.DoQuery(xSQL)

        ''    If Not oRS.EoF Then



        ''        oORDR.DocDate = Now.Date.ToString("yyyy-MM-dd")
        ''        oORDR.DocDueDate = Now.Date.ToString("yyyy-MM-dd")

        ''        oORDR.CardCode = oRS.Fields.Item("CardCode").Value

        ''        oORDR.Lines.SetCurrentLine(0)

        ''        oORDR.BPL_IDAssignedToInvoice = "1"

        ''        For i = 1 To oRS.RecordCount
        ''            oORDR.Lines.ItemCode = oRS.Fields.Item("ItemCode").Value.ToString.Trim
        ''            oORDR.Lines.Quantity = oRS.Fields.Item("Quantity").Value.ToString.Trim
        ''            oORDR.Lines.LineTotal = oRS.Fields.Item("LineTotal").Value.ToString.Trim
        ''            oORDR.Lines.Add()

        ''            oRS.MoveNext()

        ''        Next

        ''        If oORDR.Add <> 0 Then
        ''            MsgBox(oCompany.GetLastErrorDescription)
        ''        Else
        ''            MsgBox(oCompany.GetNewObjectKey & "�� �Ǹſ��� ���� �Ϸ�")
        ''        End If
        ''    End If


        ''Catch ex As System.Exception
        ''    MsgBox(Err.Description)


        ''Finally


        ''    System.Runtime.InteropServices.Marshal.ReleaseComObject(oORDR)
        ''    oORDR = Nothing

        ''End Try


        'Try

        '    If oORDR.GetByKey(CInt("6013")) Then
        '        oORDR.Comments = "LKH"
        '        MsgBox("���� �Ϸ�")

        '    Else
        '        MsgBox("����")
        '    End If
        'Catch ex As Exception

        'Finally
        '    System.Runtime.InteropServices.Marshal.ReleaseComObject(oORDR)
        '    oORDR = Nothing
        'End Try
        ''-----------------------------------------------------------------------------
        ''-- �Ǹſ��� ����� ��
        ''-----------------------------------------------------------------------------


        ''-----------------------------------------------------------------------------
        ''-- �а� ����� ����
        ''-----------------------------------------------------------------------------

        'Try

        '    xSQL = ""

        '    xSQL = xSQL & "SELECT  T0.Memo," & vbCrLf
        '    xSQL = xSQL & "        T1.Account," & vbCrLf
        '    xSQL = xSQL & "        T1.Debit," & vbCrLf
        '    xSQL = xSQL & "        T1.Credit," & vbCrLf
        '    xSQL = xSQL & "        T1.ShortName," & vbCrLf
        '    xSQL = xSQL & "T1.Line_ID" & vbCrLf
        '    xSQL = xSQL & "FROM OJDT T0" & vbCrLf
        '    xSQL = xSQL & "INNER JOIN JDT1 T1 ON T0.TransID = T1.TransID" & vbCrLf
        '    xSQL = xSQL & "WHERE T0.TransID = '23'" & vbCrLf


        '    oRS.DoQuery(xSQL)

        '    If Not oRS.EoF Then

        '        Dim oJE As SAPbobsCOM.JournalEntries = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oJournalEntries)

        '        oJE.ReferenceDate = Now.Date.ToString("yyyy-MM-dd")
        '        oJE.Memo = oRS.Fields.Item("Memo").Value

        '        oJE.Lines.SetCurrentLine(0)

        '        For i = 1 To oRS.RecordCount
        '            oJE.Lines.AccountCode = oRS.Fields.Item("Account").Value.ToString.Trim

        '            If oRS.Fields.Item("Debit").Value <> 0 Then
        '                oJE.Lines.Debit = oRS.Fields.Item("Debit").Value
        '            End If

        '            If oRS.Fields.Item("Credit").Value <> 0 Then
        '                oJE.Lines.Credit = oRS.Fields.Item("Credit").Value
        '            End If

        '            oJE.Lines.ShortName = oRS.Fields.Item("ShortName").Value

        '            oJE.Lines.Add()

        '            oRS.MoveNext()

        '        Next

        '        If oJE.Add <> 0 Then
        '            MsgBox(oCompany.GetLastErrorDescription)
        '        Else
        '            MsgBox(oCompany.GetNewObjectKey & "�� �а����� �Ϸ�")
        '        End If
        '    End If


        'Catch ex As System.Exception
        '    MsgBox(Err.Description)


        'Finally

        '    If oCompany.Connected Then
        '        oCompany.Disconnect()
        '    End If

        '    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany)

        '    oCompany = Nothing
        '    oRS = Nothing

        '    Me.Dispose()
        '    Me.Close()

        'End Try

        '-----------------------------------------------------------------------------
        '-- �а� ����� ��
        '-----------------------------------------------------------------------------

        '-----------------------------------------------------------------------------
        '-- ����
        '-- ǰ�� ������ ���� 100�� ��ȸ�ϰ� ǰ���ڵ� + N�� �̸����� �ؼ� ����
        '-----------------------------------------------------------------------------

        'Dim oitem2 As SAPbobsCOM.Items = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
        'Dim otmpItem As SAPbobsCOM.Items = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
        'xSQL = ""
        'xSQL = xSQL & "select top 100 itemcode from oitm order by itemcode asc"
        'Try
        '    oRS.DoQuery(xSQL)
        '    For i = 1 To oRS.RecordCount
        '        otmpItem.GetByKey(oRS.Fields.Item("Itemcode").Value.ToString.Trim)
        '        otmpItem.ItemCode = otmpItem.ItemCode & "N"

        '        ' �ߺ� üũ
        '        If oitem2.GetByKey(otmpItem.ItemCode) <> 0 Then
        '            If otmpItem.Add() <> 0 Then
        '                MsgBox(oCompany.GetLastErrorDescription)
        '            Else
        '                MsgBox("Add completed")
        '            End If
        '        End If
        '        oRS.MoveNext()
        '    Next
        'Catch ex As Exception

        'End Try
        '-----------------------------------------------------------------------------
        '-- ���� ��
        '-----------------------------------------------------------------------------

        '-----------------------------------------------------------------------------
        '-- ����2 AP ���� ����� ����
        '-----------------------------------------------------------------------------


        'Try


        '    xSQL = ""

        '    xSQL = xSQL & "SELECT  T0.CardCode," & vbCrLf
        '    xSQL = xSQL & "        T1.ItemCode," & vbCrLf
        '    xSQL = xSQL & "        T1.Quantity," & vbCrLf
        '    xSQL = xSQL & "        T1.LineTotal" & vbCrLf
        '    xSQL = xSQL & "FROM ORDR T0" & vbCrLf
        '    xSQL = xSQL & "INNER JOIN RDR1 T1 ON T0.DocEntry = T1.DocEntry" & vbCrLf
        '    xSQL = xSQL & "WHERE T0.DocEntry = '1'" & vbCrLf


        '    oRS.DoQuery(xSQL)

        '    If Not oRS.EoF Then



        '        oORDR.DocDate = Now.Date.ToString("yyyy-MM-dd")
        '        oORDR.DocDueDate = Now.Date.ToString("yyyy-MM-dd")

        '        oORDR.CardCode = oRS.Fields.Item("CardCode").Value

        '        oORDR.Lines.SetCurrentLine(0)

        '        oORDR.BPL_IDAssignedToInvoice = "1"

        '        For i = 1 To oRS.RecordCount
        '            oORDR.Lines.ItemCode = oRS.Fields.Item("ItemCode").Value.ToString.Trim
        '            oORDR.Lines.Quantity = oRS.Fields.Item("Quantity").Value.ToString.Trim
        '            oORDR.Lines.LineTotal = oRS.Fields.Item("LineTotal").Value.ToString.Trim
        '            oORDR.Lines.Add()

        '            oRS.MoveNext()

        '        Next

        '        If oORDR.Add <> 0 Then
        '            MsgBox(oCompany.GetLastErrorDescription)
        '        Else
        '            MsgBox(oCompany.GetNewObjectKey & "�� �Ǹſ��� ���� �Ϸ�")
        '        End If
        '    End If


        'Catch ex As System.Exception
        '    MsgBox(Err.Description)


        'Finally


        '    System.Runtime.InteropServices.Marshal.ReleaseComObject(oORDR)
        '    oORDR = Nothing

        'End Try

        Dim oAP As SAPbobsCOM.Documents = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oPurchaseInvoices)

        Try
            '�̹� �ִ��� üũ ������ ���� ������ ������Ʈ
            Debug.Print(oAP.GetByKey(425))
            'If oAP.GetByKey(425) <> 0 Then
            '    ����
            '    oAP.CardCode = "S00422"
            '    oAP.NumAtCard = "S00422"
            '    oAP.DocDate = "2020.10.01"
            '    oAP.DocDueDate = "2020.11.30"
            '    oAP.TaxDate = "2020.10.01"
            '    oAP.DocType = SAPbobsCOM.BoDocumentTypes.dDocument_Service
            '    oAP.BPL_IDAssignedToInvoice = 2
            '    If oAP.Lines.Count <= 2 Then
            '        ������Ʈ
            '        oAP.Lines.ItemDescription = "��ö��"
            '        oAP.Lines.AccountCode = "81101"
            '        oAP.Lines.LineTotal = 100000
            '        oAP.Lines.VatGroup = "V1"
            '        oAP.Lines.Add()

            '        oAP.Lines.ItemDescription = "�̿���"
            '        oAP.Lines.AccountCode = "81401"
            '        oAP.Lines.LineTotal = 35000
            '        oAP.Lines.VatGroup = "V3"
            '        Dim retCode As Long
            '        oAP.Lines.Add()
            '        retCode = oAP.Update()
            '        If retCode <> 0 Then
            '            MsgBox(oCompany.GetLastErrorDescription)
            '        Else
            '            MsgBox("���� �Ϸ�")
            '        End If
            '    End If
            '    If oAP.Add() <> 0 Then
            '        MsgBox(oCompany.GetLastErrorDescription)
            '    Else
            '        MsgBox("���� �Ϸ�")
            '    End If
            'Else
            '    MsgBox("�̹� ����")
            'End If

        Catch ex As Exception

        Finally
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oAP)
            oAP = Nothing
        End Try
        '-----------------------------------------------------------------------------
        '-- ����2 AP ���� ����� ��
        '-----------------------------------------------------------------------------


    End Sub


End Class
