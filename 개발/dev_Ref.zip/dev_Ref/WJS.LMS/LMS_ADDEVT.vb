﻿Imports AddOnBase
Imports SAPbobsCOM
Imports SAPbouiCOM
Imports System.Runtime.InteropServices
Imports WJS.COMM


Public Class LMS_ADDEVT
    Implements IDisposable


    Public Sub New()
        Me.Init()
    End Sub

    Public Sub Init()

        Try

            cApp = B1Connections.theAppl

        Catch ex As Exception

            B1Connections.theAppl.MessageBox(ex.Message)

        End Try

    End Sub


    Public WithEvents cApp As SAPbouiCOM.Application


    ''' <summary>
    ''' cApp_MenuEvent
    ''' </summary>
    ''' <param name="pVal"></param>
    ''' <param name="BubbleEvent"></param>
    ''' <remarks></remarks>
    Public Sub cApp_MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean) Handles cApp.MenuEvent
        Dim cForm As SAPbouiCOM.Form = Nothing

        Try

            '애드온 메뉴일 경우에만 실행
            If pVal.MenuUID.StartsWith("WJS_") Then

                cForm = cApp.Forms.ActiveForm

                If Not IsNothing(cForm) Then cForm.Freeze(True)

                '메뉴 클릭시 애드온 메뉴일 경우에는 테이블복사(Copy Table) 메뉴 비활성화 및 색상값 설정
                If cForm.UniqueID.StartsWith("WJS_") Then

                    '테이블복사(Copy Table) 메뉴 비활성
                    cForm.EnableMenu(771, True)     '잘라내기
                    cForm.EnableMenu(772, True)     '복사
                    cForm.EnableMenu(773, True)     '붙여넣기
                    cForm.EnableMenu(784, False)    '테이블복사

                    '애드온화면 Color Menu 활성화
                    LMS_COMMON.SetColorMenuItem()

                End If


                'If pVal.BeforeAction = False And pVal.MenuUID = "WJS_TRB4030" Then

                '    Dim ActiveForm As SAPbouiCOM.Form = cApp.Forms.ActiveForm

                '    Try

                '        ActiveForm.Freeze(False)

                '        '계정별잔액/원장(싸이트 버전에서 사용안하는 부분을 숨긴다.)
                '        If ActiveForm.UniqueID.StartsWith("WJS_TRB4030") Then Me.SetWJS_Form(ActiveForm, "SRF\LMS\TR\WJS_TRB4030_LMS.srf")

                '    Catch ex As Exception
                '        B1Connections.theAppl.MessageBox(ex.Message)
                '    Finally
                '        ActiveForm.Freeze(False)
                '        ActiveForm = Nothing
                '    End Try

                'End If

            End If

        Catch ex As Exception
            B1Connections.theAppl.MessageBox(ex.Message)
        Finally
            If Not IsNothing(cForm) Then cForm.Freeze(False)
            cForm = Nothing
        End Try

    End Sub


    'Private Sub cApp_ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean) Handles cApp.ItemEvent
    '    Dim meForm As SAPbouiCOM.Form
    '    'Dim cItem As Long

    '    Try

    '        If pVal.EventType = BoEventTypes.et_CHOOSE_FROM_LIST Then

    '            meForm = cApp.Forms.ActiveForm

    '            If meForm.TypeEx = "139" Then

    '                Dim a As String = ""

    '            End If

    '        End If

    '        'cForm = cApp.Forms.ActiveForm

    '        'If FormUID.StartsWith("WJS_") And BubbleEvent And (pVal.EventType = BoEventTypes.et_VALIDATE Or pVal.EventType = BoEventTypes.et_CLICK) Then

    '        '    'Select Case cForm.Items.Item(Trim(pVal.ItemUID)).Type

    '        '    '    Case BoFormItemTypes.it_EDIT, BoFormItemTypes.it_EXTEDIT
    '        '    '        cForm.EnableMenu(772, True) '복사
    '        '    '        cForm.EnableMenu(771, True) '잘라내기

    '        '    '    Case BoFormItemTypes.it_MATRIX, BoFormItemTypes.it_GRID
    '        '    '        cForm.EnableMenu(772, True) '복사
    '        '    '        cForm.EnableMenu(771, True) '잘라내기

    '        '    'End Select

    '        'End If

    '    Catch ex As Exception
    '        B1Connections.theAppl.MessageBox(ex.Message)
    '    Finally
    '        meForm = Nothing
    '    End Try

    'End Sub


    ''' <summary>
    ''' cApp_RightClickEvent
    ''' </summary>
    ''' <param name="eventInfo"></param>
    ''' <param name="BubbleEvent"></param>
    ''' <remarks></remarks>
    Private Sub cApp_RightClickEvent(ByRef eventInfo As SAPbouiCOM.ContextMenuInfo, ByRef BubbleEvent As Boolean) Handles cApp.RightClickEvent
        Dim cForm As SAPbouiCOM.Form
        Dim cItem As Long

        Try

            cForm = cApp.Forms.ActiveForm

            If eventInfo.BeforeAction Then

                '애드온 메뉴 이면서 메트릭스와 그리드 일때만 테이블복사(Copy Table) 메뉴가 활성화 되도록 처리함.
                If Not eventInfo.FormUID.StartsWith("WJS_") Then

                    Exit Try

                ElseIf eventInfo.FormUID.StartsWith("WJS_") And Trim(eventInfo.ItemUID) = "" Then

                    cForm.EnableMenu(771, False)    '잘라내기
                    cForm.EnableMenu(772, False)    '복사
                    'cForm.EnableMenu(773, False)    '붙여넣기
                    cForm.EnableMenu(784, False)    '테이블복사

                Else

                    cItem = cForm.Items.Item(Trim(eventInfo.ItemUID)).Type

                    If cItem = BoFormItemTypes.it_EDIT Or cItem = BoFormItemTypes.it_EXTEDIT Then
                        If Not cForm.Menu.Exists("771") Then cForm.EnableMenu(771, True) '잘라내기
                        If Not cForm.Menu.Exists("773") Then cForm.EnableMenu(773, True) '붙여넣기
                    Else
                        cForm.EnableMenu(771, False) '잘라내기
                        'cForm.EnableMenu(773, False) '붙여넣기
                    End If

                    If cItem = BoFormItemTypes.it_GRID Or cItem = BoFormItemTypes.it_MATRIX Then
                        If Not cForm.Menu.Exists("784") Then cForm.EnableMenu(784, True)
                    Else
                        cForm.EnableMenu(784, False)
                    End If

                    If Not cForm.Menu.Exists("772") Then cForm.EnableMenu(772, True) '복사

                End If
            End If

        Catch ex As Exception
            B1Connections.theAppl.MessageBox(ex.Message)
        Finally
            cForm = Nothing
        End Try

    End Sub


    ''' <summary>
    ''' SetWJS_Form
    ''' </summary>
    ''' <param name="ActiveForm"></param>
    ''' <remarks></remarks>
    Public Sub SetWJS_Form(ByVal ActiveForm As SAPbouiCOM.Form, ByVal strFilePath As String)
        Dim xmlDoc As Xml.XmlDocument = New Xml.XmlDocument()
        Dim pStartPath As String = ""
        Dim xmlFile As String = ""
        Dim xmlStr As String = ""

        Try

            '파일의경로를읽어온다. 
            pStartPath = System.Reflection.Assembly.GetExecutingAssembly.Location
            pStartPath = pStartPath.Substring(0, InStrRev(pStartPath, "\"))

            '스크린 페인터 파일을 지정한다.
            xmlFile = pStartPath & strFilePath

            'Xml Load
            xmlDoc.Load(xmlFile)

            '폼 ID 값을 현재 오픈된 Uid로 변경
            xmlDoc.SelectSingleNode("Application/forms/action/form/@uid").Value = ActiveForm.UniqueID.ToString

            'Xml 값을 String로 변경
            xmlStr = xmlDoc.DocumentElement.OuterXml

            '폼값 Update
            B1Connections.theAppl.LoadBatchActions(xmlStr)

        Catch ex As Exception
            B1Connections.theAppl.MessageBox(ex.Message)
        End Try

    End Sub


    Private disposedValue As Boolean = False        ' 중복 호출을 검색하려면

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: 명시적으로 호출되면 관리되지 않는 리소스를 해제합니다.
            End If

            ' TODO: 관리되지 않는 공유 리소스를 해제합니다.
        End If
        Me.disposedValue = True
    End Sub


#Region " IDisposable Support "
    ' 삭제 가능한 패턴을 올바르게 구현하기 위해 Visual Basic에서 추가한 코드입니다.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' 이 코드는 변경하지 마십시오. 위의 Dispose(ByVal disposing As Boolean)에 정리 코드를 입력하십시오.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region


End Class
