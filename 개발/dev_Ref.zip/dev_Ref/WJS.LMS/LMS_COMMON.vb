﻿Imports AddOnBase
Imports SAPbobsCOM
Imports SAPbouiCOM
Imports System.Runtime.InteropServices
Imports WJS.COMM
Imports System.Xml
Imports System.Data.OleDb
Imports System.Data
Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Net.Mail
Imports Excel.Constants
Imports Excel.XlBordersIndex
Imports Excel.XlLineStyle
Imports Excel.XlBorderWeight

Module LMS_COMMON

    'Public Const ITMGRP_S01 As String = "100"    '상품
    'Public Const ITMGRP_S02 As String = "101"    '제품
    'Public Const ITMGRP_S03 As String = "102"    '반제품
    'Public Const ITMGRP_S04 As String = "103"    '원재료
    'Public Const ITMGRP_S05 As String = "104"    '부재료
    'Public Const ITMGRP_S06 As String = "105"    '저장품
    '기준변경 -- 2018-05-04

    ''' <summary>
    ''' 상품
    ''' </summary>
    ''' <remarks></remarks>
    Public Const ITMGRP_S01 As String = "S01"    '상품
    ''' <summary>
    ''' 제품
    ''' </summary>
    ''' <remarks></remarks>
    Public Const ITMGRP_S02 As String = "S02"    '제품
    ''' <summary>
    ''' 반제품
    ''' </summary>
    ''' <remarks></remarks>
    Public Const ITMGRP_S03 As String = "S03"    '반제품
    ''' <summary>
    ''' 원재료
    ''' </summary>
    ''' <remarks></remarks>
    Public Const ITMGRP_S04 As String = "S04"    '원재료
    ''' <summary>
    ''' 부재료
    ''' </summary>
    ''' <remarks></remarks>
    Public Const ITMGRP_S05 As String = "S05"    '부재료
    ''' <summary>
    ''' 저장품
    ''' </summary>
    ''' <remarks></remarks>
    Public Const ITMGRP_S06 As String = "S06"    '저장품

#Region "WJS_EXCEL_TO_Data"

    Private trd_Setup As Threading.Thread

    ''' <summary>
    ''' ExcelToDataDable
    ''' </summary>
    ''' <param name="strFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ExcelToDataDable(ByVal strFileName As String) As System.Data.DataTable
        Dim Dt_Data As System.Data.DataTable = Nothing
        Dim Ds_Data As System.Data.DataSet = Nothing

        Try

            Ds_Data = ExcelToDataSet(strFileName)
            Dt_Data = Ds_Data.Tables(0)

        Catch ex As Exception
            Return Nothing
        End Try

        Return Dt_Data
    End Function


    ''' <summary>
    ''' ExcelToDataSet
    ''' </summary>
    ''' <param name="strFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ExcelToDataSet(ByVal strFileName As String) As System.Data.DataSet
        Dim Ds_Data As System.Data.DataSet = Nothing

        Dim objExcel As Excel.Application = Nothing
        Dim objWorkbook As Excel.Workbook = Nothing
        Dim objWorksheet As Excel.Worksheet = Nothing
        Dim iHandle As Long
        Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
        Dim MyConnection As System.Data.OleDb.OleDbConnection

        Try

            objExcel = CreateObject("Excel.Application")
            objWorkbook = objExcel.Workbooks.Open(strFileName, True, True)
            objWorksheet = objWorkbook.Sheets(1)

            iHandle = IntPtr.Zero
            If CInt(objExcel.Version) < "10.0" Then
                iHandle = FindWindow(Nothing, objExcel.Caption)
            Else
                iHandle = objExcel.Parent.Hwnd
            End If

            MyConnection = New System.Data.OleDb.OleDbConnection( _
                  "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strFileName & ";Extended Properties=" + Convert.ToChar(34).ToString() + "Excel 12.0;Imex=1;HDR=Yes;" + Convert.ToChar(34).ToString())

            ' Select the data from Sheet1 of the workbook.
            MyCommand = New System.Data.OleDb.OleDbDataAdapter( _
                  "select * from [" & objWorksheet.Name & "$]", MyConnection)

            'Sheet1
            Ds_Data = New System.Data.DataSet()

            '업로드 컨트롤 설치 파일이 없으면 설치
            Try
                MyCommand.Fill(Ds_Data)
            Catch ex As Exception

                If CFL.COMMON_MESSAGE("?", "엑셀업로드컨트롤 설치가 필요합니다. 지금 설치 하시겠습니까?") = 1 Then
                    trd_Setup = New Threading.Thread(AddressOf Thread_Setup)
                    trd_Setup.Start()
                End If

                Ds_Data = Nothing
                MyCommand = Nothing
                MyConnection = Nothing

                If (Not objWorksheet Is Nothing Or Not objWorkbook Is Nothing Or Not objExcel Is Nothing) Then
                    objWorksheet = Nothing
                    objWorkbook.Close(False)    '// 저장하시않고 다음(False)
                    objWorkbook = Nothing

                    objExcel.Quit()
                    objExcel = Nothing

                    KillExcel(iHandle)
                    GC.Collect()
                    GC.WaitForPendingFinalizers()

                End If

                Return Nothing
            End Try

            MyConnection.Close()

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message.ToString)
        Finally

            Ds_Data = Nothing
            MyCommand = Nothing
            MyConnection = Nothing

            If (Not objWorksheet Is Nothing Or Not objWorkbook Is Nothing Or Not objExcel Is Nothing) Then
                objWorksheet = Nothing
                objWorkbook.Close(False)    '// 저장하시않고 다음(False)
                objWorkbook = Nothing

                objExcel.Quit()
                objExcel = Nothing

                KillExcel(iHandle)
                GC.Collect()
                GC.WaitForPendingFinalizers()

            End If

        End Try

        Return Ds_Data

    End Function


    ''' <summary>
    ''' Thread_Setup
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Thread_Setup()
        Dim strSetupExe As String = "\CrystalViewer.exe"
        Dim strStartPath As String = System.Reflection.Assembly.GetExecutingAssembly.Location
        Dim strSetupPats As String = ""

        'Dim proc As Process

        Try
            strStartPath = strStartPath.Substring(0, strStartPath.LastIndexOf("\"))

            Try
                If System.Environment.Is64BitProcess = True Then strSetupExe = "\AccessDatabaseEngine_X64.exe"
            Catch ex As Exception
                strSetupExe = "\AccessDatabaseEngine.exe"
            End Try

            strSetupPats = strStartPath + strSetupExe

            If (System.IO.File.Exists(strSetupPats)) Then

                System.IO.File.SetAttributes(strSetupPats, FileAttributes.Normal)

                Shell(strSetupPats, AppWinStyle.NormalFocus)

            Else
                CFL.COMMON_MESSAGE("!", "엑셀업로드컨트롤 설치파일이 없습니다. 시스템관리자에게 문의 하십시오.")
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("Thread_Setup Error : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub


#End Region

#Region "WJS_EXCEL_TO_XML"

    ''' <summary>
    ''' 엑셀내역을 조회하여 XML로 변환한다.
    ''' </summary>
    ''' <param name="strFileName"></param>
    ''' <param name="blnHeader"></param>
    ''' <param name="iTableIndex"></param>
    ''' <param name="strTableName"></param>
    ''' <returns>엑셀에 있는 각 시트의 내역을 XML로 변환하여 배열로 리턴한다.</returns>
    ''' <remarks></remarks>
    'Public Function GetAllXML(ByVal strFileName As String, ByVal blnHeader As Boolean, ByVal iTableIndex As Integer, ByRef strTableName As String) As String()

    '    Dim dsExcelData As DataSet
    '    Dim strComand As String
    '    Dim i As Integer
    '    Dim nullCnt As Integer = 0
    '    Dim strSheetTableName() As String
    '    Dim strSheetName As String
    '    'Dim ExcelCon As String = "Provider=Microsoft.Jet.OLEDB.4.0;"
    '    Dim ExcelCon As String ' = "Provider=Microsoft.ACE.OLEDB.12.0;"
    '    Dim strConnectionString As String
    '    Dim oleCon As System.Data.OleDb.OleDbConnection = Nothing
    '    Dim oleAdapter As System.Data.OleDb.OleDbDataAdapter
    '    Dim dts As System.Data.DataTable

    '    Dim strXml() As String

    '    Try

    '        '엑셀 CONNECT (MICROSOFT.JET.OLEDB) 활용 
    '        '파일경로, 헤더데이터여부를 넘김다.
    '        If blnHeader Then
    '            ExcelCon = "Provider=Microsoft.ACE.OLEDB.12.0;"
    '            'strConnectionString = ExcelCon + "Data Source=" + strFileName + ";Extended Properties=" + Convert.ToChar(34).ToString() + "Excel 8.0;HDR=No;IMEX=1;" + Convert.ToChar(34).ToString()
    '            strConnectionString = ExcelCon + "Data Source=" + strFileName + ";Extended Properties=" + Convert.ToChar(34).ToString() + "Excel 12.0;HDR=Yes;IMEX=1;" + Convert.ToChar(34).ToString()
    '        Else
    '            ExcelCon = "Provider=Microsoft.ACE.OLEDB.12.0;"
    '            strConnectionString = ExcelCon + "Data Source=" + strFileName + ";Extended Properties=" + Convert.ToChar(34).ToString() + "Excel 8.0;HDR=No;IMEX=1;" + Convert.ToChar(34).ToString()
    '        End If

    '        '엑셀 oledb객체생성
    '        oleCon = New OleDbConnection()
    '        oleCon.ConnectionString = strConnectionString

    '        '엑셀 oledb객체 연결
    '        oleCon.Open()

    '        '엑셀시트스키가 가져오기
    '        dts = oleCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

    '        '시트 갯수만큼 시트명을 가져온다.
    '        ReDim strSheetTableName(dts.Rows.Count() - 1)

    '        For i = 1 To dts.Rows.Count()

    '            strSheetName = dts.Rows(i - 1).Item("TABLE_NAME").ToString()

    '            If Right(strSheetName, 1) <> "_" Then

    '                strSheetTableName(i - 1) = strSheetName.Substring(0, strSheetName.Length() - 1)

    '            End If

    '            If ((i - 1) = iTableIndex) Then
    '                strTableName = strSheetTableName(i - 1)
    '            End If


    '        Next

    '        '배열초기화 ( 시트의 갯수만큼 배열초기화)
    '        ReDim strXml(strSheetTableName.Length() - 1)

    '        '데이터테이블 초기화
    '        dts.Clear()

    '        '시트의 갯수만큼 루핑으로 XML변환
    '        For i = 1 To strSheetTableName.Length()

    '            If Not strSheetTableName(i - 1) Is Nothing And (i - 1) = iTableIndex Then

    '                '' 엑셀의 시트내역을 데이터베이스처럼 인식하여 시트명이 테이블네임이 된다
    '                '' 헤더정보를 가져올경우 첫번째 라인이 컬럼이 된다.
    '                '' 헤더정보를 안가져올경우 컬럼은 순차적으로 F1, F2, F3 ~~~~~ 이런식으로 변환된다.
    '                '' 한글과 영어는 인식하지만 숫자와 부호는 _x0026_ 이런식으로 16진수로 변환되서 나온다.
    '                strComand = "select * from [" + strSheetTableName(i - 1) + "$]"

    '                '엑셀연결
    '                oleAdapter = New OleDbDataAdapter(strComand, oleCon)

    '                '데이터테이블 설정(xml로 변환하기 위하여 데이터테이블에 저장)
    '                dts = New System.Data.DataTable(strSheetTableName(i - 1))

    '                '데이터테이블에 엑셀내용 저장
    '                oleAdapter.FillSchema(dts, SchemaType.Source)
    '                oleAdapter.Fill(dts)

    '                '각 시트별로 담기위하여 데이터셋 설정
    '                dsExcelData = New DataSet()
    '                dsExcelData.Tables.Add(dts)


    '                '시트이 데이터가 있는경우만 xml을 배열에 담는다.
    '                If dts.Rows.Count() > 0 Then

    '                    '데이터셋에서 xml 추출
    '                    strXml(i - 1) = dsExcelData.GetXml()
    '                    nullCnt = nullCnt + 1

    '                End If

    '                '연결내역 제거
    '                dts.Clear()
    '                oleAdapter.Dispose()
    '                dsExcelData.Dispose()

    '            End If

    '        Next

    '        '빈 배열값을 제거
    '        ReDim Preserve strXml(nullCnt - 1)

    '        Return strXml


    '    Catch ex As Exception
    '        Return Nothing
    '    Finally

    '        oleCon.Close()

    '        dts = Nothing
    '        oleAdapter = Nothing
    '        oleCon = Nothing
    '        dsExcelData = Nothing
    '    End Try

    'End Function
    Public Function GetAllXML(ByVal strFileName As String, ByVal blnHeader As Boolean, ByVal iTableIndex As Integer, ByRef strTableName As String) As String()

        Dim dsExcelData As DataSet
        Dim strComand As String
        Dim i As Integer
        Dim nullCnt As Integer = 0
        Dim strSheetTableName() As String
        Dim strSheetName As String
        Dim strConnectionString As String
        Dim oleCon As System.Data.OleDb.OleDbConnection
        Dim oleAdapter As System.Data.OleDb.OleDbDataAdapter
        Dim enumerator As System.Data.OleDb.OleDbEnumerator
        Dim ProviderList As ArrayList = New ArrayList()
        Dim iCnt As Integer
        Dim dts As System.Data.DataTable
        Dim dtsTemp As System.Data.DataTable
        Dim ExcelCon As String = "Provider="
        Dim cv_OLEDB_s As String = ""
        Dim cv_OLEVR_d As Double
        Dim cv_ExcelVR_d As String = ""
        Dim strXml() As String

        Try

            'OleDbEnumerator enumerator = new OleDbEnumerator(); 
            'DataTable table = enumerator.GetElements();
            'List aryProviders = new List();
            'foreach (DataRow row in table.Rows)
            '{
            '    aryProviders.Add(row[0].ToString());
            '}
            'table.Dispose();
            'aryProviders.Sort((p, n) => n.CompareTo(p));

            'string sFoundString = aryProviders.Find(m => m.StartsWith("Microsoft.ACE.OLEDB"));
            '            If (String.IsNullOrEmpty(sFoundString)) Then
            'sFoundString = aryProviders.Find(m => m.StartsWith("Microsoft.Jet.OLEDB"));
            'g_sProviderName = sFoundString; 



            enumerator = New OleDbEnumerator()
            '엑셀 Provider 여부에 따라 접속방식변경
            dts = enumerator.GetElements
            For iCnt = 1 To dts.Rows.Count()
                ProviderList.Add(dts.Rows(iCnt - 1).Item(0).ToString)
            Next

            ProviderList.Sort()

            cv_OLEVR_d = 0

            For iCnt = 1 To ProviderList.Count

                If ProviderList(iCnt - 1).ToString.IndexOf("Microsoft.ACE.OLEDB.") >= 0 Then

                    If cv_OLEVR_d < Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.ACE.OLEDB.", "")) Then
                        cv_OLEDB_s = ProviderList(iCnt - 1).ToString
                        cv_OLEVR_d = Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.ACE.OLEDB.", ""))
                    End If
                End If

            Next

            cv_OLEVR_d = 0

            If cv_OLEDB_s = "" Then
                For iCnt = 1 To ProviderList.Count

                    If ProviderList(iCnt - 1).ToString.IndexOf("Microsoft.Jet.OLEDB.") >= 0 Then
                        If cv_OLEVR_d < Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.Jet.OLEDB.", "")) Then
                            cv_OLEDB_s = ProviderList(iCnt - 1).ToString
                            cv_OLEVR_d = Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.Jet.OLEDB.", ""))
                        End If
                    End If
                Next
            End If


            ExcelCon = ExcelCon & cv_OLEDB_s & ";"

            If cv_OLEDB_s.IndexOf("Microsoft.ACE.OLEDB.12") >= 0 Then
                cv_ExcelVR_d = "Excel 12.0;"
            Else
                cv_ExcelVR_d = "Excel 8.0;"
            End If

            dts.Clear()

            '엑셀 CONNECT (MICROSOFT.JET.OLEDB) 활용 
            '파일경로, 헤더데이터여부를 넘김다.
            If blnHeader Then
                strConnectionString = ExcelCon + "Data Source=" + strFileName + ";Extended Properties=" + Convert.ToChar(34).ToString() + cv_ExcelVR_d + "HDR=Yes;IMEX=1;" + Convert.ToChar(34).ToString()
            Else
                strConnectionString = ExcelCon + "Data Source=" + strFileName + ";Extended Properties=" + Convert.ToChar(34).ToString() + cv_ExcelVR_d + "HDR=No;IMEX=1;" + Convert.ToChar(34).ToString()
            End If

            '엑셀 oledb객체생성
            oleCon = New OleDbConnection()
            oleCon.ConnectionString = strConnectionString

            '엑셀 oledb객체 연결
            oleCon.Open()

            '엑셀시트스키가 가져오기
            dts = oleCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)



            'For i = 0 To dts.Rows.Count() - 1
            '    If dts.Rows.Count() > i Then
            '        If Left(dts.Rows(i).Item("TABLE_NAME").ToString(), 5) <> "Sheet" Then
            '            dts.Rows.Remove(dts.Rows(i))
            '        End If
            '    End If
            'Next

            '시트 갯수만큼 시트명을 가져온다.
            ReDim strSheetTableName(dts.Rows.Count() - 1)

            For i = 1 To dts.Rows.Count()

                strSheetName = dts.Rows(i - 1).Item("TABLE_NAME").ToString()

                If Right(strSheetName, 1) <> "_" Then



                    strSheetTableName(i - 1) = strSheetName.Substring(0, strSheetName.Length() - 1)

                End If

                If ((i - 1) = iTableIndex) Then
                    strTableName = strSheetTableName(i - 1)
                End If


            Next

            '배열초기화 ( 시트의 갯수만큼 배열초기화)
            ReDim strXml(strSheetTableName.Length() - 1)

            '데이터테이블 초기화
            dts.Clear()

            '시트의 갯수만큼 루핑으로 XML변환
            'For i = 1 To strSheetTableName.Length()

            '    If Not strSheetTableName(i - 1) Is Nothing And (i - 1) = iTableIndex Then

            Try
                '' 엑셀의 시트내역을 데이터베이스처럼 인식하여 시트명이 테이블네임이 된다
                '' 헤더정보를 가져올경우 첫번째 라인이 컬럼이 된다.
                '' 헤더정보를 안가져올경우 컬럼은 순차적으로 F1, F2, F3 ~~~~~ 이런식으로 변환된다.
                '' 한글과 영어는 인식하지만 숫자와 부호는 _x0026_ 이런식으로 16진수로 변환되서 나온다.
                strComand = "select * from [Sheet1$]"

                '엑셀연결
                oleAdapter = New OleDbDataAdapter(strComand, oleCon)

                '데이터테이블 설정(xml로 변환하기 위하여 데이터테이블에 저장)
                dts = New System.Data.DataTable("Sheet1")

                '데이터테이블에 엑셀내용 저장
                oleAdapter.FillSchema(dts, SchemaType.Source)
                oleAdapter.Fill(dts)

                '각 시트별로 담기위하여 데이터셋 설정
                dsExcelData = New DataSet()
                dsExcelData.Tables.Add(dts)


                '시트이 데이터가 있는경우만 xml을 배열에 담는다.
                If dts.Rows.Count() > 0 Then

                    '데이터셋에서 xml 추출
                    strXml(0) = dsExcelData.GetXml()
                    nullCnt = nullCnt + 1

                End If

                '연결내역 제거
                dts.Clear()
                oleAdapter.Dispose()
                dsExcelData.Dispose()
            Catch ex As Exception

            End Try

            '    End If

            'Next

            '빈 배열값을 제거
            ReDim Preserve strXml(nullCnt - 1)

            Return strXml


        Catch ex As Exception
            Return Nothing
        Finally

            oleCon.Close()

            dts = Nothing
            oleAdapter = Nothing
            oleCon = Nothing
            dsExcelData = Nothing
            enumerator = Nothing
            ProviderList = Nothing

        End Try

    End Function

#End Region

#Region "WJS_ZZ_Excel"

    ''' <summary>
    ''' 엑셀모듈 
    ''' </summary>
    ''' <remarks>기존 엑셀모듈 컨버젼</remarks>
    Class WJS_ZZ_Excel

        '---- True,False선택
        Public Enum xTriConstants
            eFalse = 0
            eTrue = 1
        End Enum

        '---- True,False선택
        Public Enum x1TriConstants
            e1False = 0
            e1True = 1
        End Enum


        '---- 정렬값 지정

        Public Enum eAlignConstants
            eCenter = -4108
            eLeft = -4131
            eRight = -4152
            eButtom = -4107
            eTop = -4160
        End Enum

        ''' <summary>
        ''' 셀전체 -> 폰트설정 (크기,굵기,이텔릭체,색상,폰트)
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tSize"></param>
        ''' <param name="tBold"></param>
        ''' <param name="tItalic"></param>
        ''' <param name="tColor"></param>
        ''' <param name="tFontName"></param>
        ''' <remarks>셀전체 -> 폰트설정 (크기,굵기,이텔릭체,색상,폰트)</remarks>
        Public Sub xlsCellsFontSize(ByVal txls As Object, _
        Optional ByVal tSize As Integer = 10, _
        Optional ByVal tBold As xTriConstants = xTriConstants.eFalse, _
        Optional ByVal tItalic As xTriConstants = xTriConstants.eFalse, _
        Optional ByVal tColor As Integer = 1, _
        Optional ByVal tFontName As String = "")

            With txls.Cells.Font
                .Size = tSize              '글자크기

                .Bold = tBold              '굵기
                .Italic = tItalic          '이텔릭체
                .ColorIndex = tColor       '글자색상


                '폰트설정
                If tFontName <> "" Then
                    .Name = tFontName
                End If

            End With

        End Sub

        ''' <summary>
        ''' 셀범위 -> 폰트설정 (크기,굵기,이텔릭체,색상,폰트)
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tCol1"></param>
        ''' <param name="tRow1"></param>
        ''' <param name="tCol2"></param>
        ''' <param name="tRow2"></param>
        ''' <param name="tSize"></param>
        ''' <param name="tBold"></param>
        ''' <param name="tItalic"></param>
        ''' <param name="tColor"></param>
        ''' <param name="tFontName"></param>
        ''' <remarks>셀범위 -> 폰트설정 (크기,굵기,이텔릭체,색상,폰트)</remarks>
        Public Sub xlsCellFont(ByVal txls As Object, _
            ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long, _
        Optional ByVal tSize As Integer = 10, _
        Optional ByVal tBold As xTriConstants = xTriConstants.eFalse, _
        Optional ByVal tItalic As x1TriConstants = x1TriConstants.e1False, _
        Optional ByVal tColor As Integer = 1, _
        Optional ByVal tFontName As String = "")

            '---- 셀범위지정하기

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()

            With txls.Selection.Font

                .Size = tSize              '글자크기

                .Bold = tBold              '굵기
                .Italic = tItalic          '이텔릭체
                .ColorIndex = tColor       '글자색상


                '폰트설정
                If tFontName <> "" Then
                    .Name = tFontName
                End If

            End With

        End Sub

        ''' <summary>
        ''' 셀전체 -> 컴럼크기 자동설정
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <remarks>셀전체 -> 컴럼크기 자동설정</remarks>
        Public Sub xlsCellsAutoFit(ByVal txls As Object)

            txls.Columns("A:AZ").Select()
            txls.Selection.Columns.AutoFit()

            'txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()
            'With txls.Selection
            '    '.Cells.Select()
            '    '.Cells.Select.Cells.EntireColumn.AutoFit()
            '    .AutoFit()
            'End With

        End Sub


        ''' <summary>
        ''' 셀전체 -> 가로,세로 좌우정렬
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tHAlign"></param>
        ''' <param name="tVAlign"></param>
        ''' <remarks>셀전체 -> 가로,세로 좌우정렬</remarks>
        Public Sub xlsCellsAlign(ByVal txls As Object, _
            ByVal tHAlign As eAlignConstants, _
            ByVal tVAlign As eAlignConstants)

            txls.Cells.Select()
            With txls.Cells
                .HorizontalAlignment = tHAlign       '수평정렬
                .VerticalAlignment = tVAlign         '수직정렬
                .WrapText = False
                .Orientation = 0
                .AddIndent = False
                .ShrinkToFit = False
            End With

        End Sub


        ''' <summary>
        ''' 셀범위 -> 가로,세로 좌우정렬
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tCol1"></param>
        ''' <param name="tRow1"></param>
        ''' <param name="tCol2"></param>
        ''' <param name="tRow2"></param>
        ''' <param name="tHAlign"></param>
        ''' <param name="tVAlign"></param>
        ''' <remarks>셀범위 -> 가로,세로 좌우정렬</remarks>
        Public Sub xlsCellAlign(ByVal txls As Object, _
                    ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long, _
                    ByVal tHAlign As eAlignConstants, _
                    ByVal tVAlign As eAlignConstants)

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()

            With txls.Selection
                .HorizontalAlignment = tHAlign       '수평정렬
                .VerticalAlignment = tVAlign         '수직정렬
                .WrapText = False
                .Orientation = 0
                .AddIndent = False
                .ShrinkToFit = False
            End With

        End Sub

        Public Sub xlsCellComma(ByVal txls As Object, _
                            ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long)

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()
            txls.Selection.NumberFormatLocal = "#,##0_ "

        End Sub


        ''' <summary>
        ''' 셀 -> 색상 지정하기 범위지정하기(col1,row1,col2,row2)
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tCol1"></param>
        ''' <param name="tRow1"></param>
        ''' <param name="tCol2"></param>
        ''' <param name="tRow2"></param>
        ''' <param name="tindex"></param>
        ''' <remarks>셀 -> 색상 지정하기 범위지정하기(col1,row1,col2,row2)</remarks>
        Public Sub xlsCellColor(ByVal txls As Object, _
            ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long, _
            ByVal tindex As Integer)

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()

            With txls.Selection.Interior
                .ColorIndex = tindex
                .Pattern = Excel.Constants.xlSolid
            End With

        End Sub


        ''' <summary>
        ''' 셀 -> 셀병합하기(Col1,Row1,Col2,Row2)
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tCol1"></param>
        ''' <param name="tRow1"></param>
        ''' <param name="tCol2"></param>
        ''' <param name="tRow2"></param>
        ''' <param name="tHAlign"></param>
        ''' <param name="tVAlign"></param>
        ''' <remarks>셀 -> 셀병합하기(Col1,Row1,Col2,Row2)</remarks>
        Public Sub xlsCellMerge(ByVal txls As Object, _
            ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long, _
            ByVal tHAlign As eAlignConstants, _
            ByVal tVAlign As eAlignConstants)

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()

            With txls.Selection
                .HorizontalAlignment = tHAlign
                .VerticalAlignment = tVAlign
                .WrapText = False
                .Orientation = 0
                .AddIndent = False
                .ShrinkToFit = False
                .MergeCells = False
            End With

            txls.Selection.Merge()

        End Sub


        ''' <summary>
        ''' 셀 -> 범위지정 보더표현(Col1,Row1,Col2,Row2)
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tCol1"></param>
        ''' <param name="tRow1"></param>
        ''' <param name="tCol2"></param>
        ''' <param name="tRow2"></param>
        ''' <remarks>셀 -> 범위지정 보더표현(Col1,Row1,Col2,Row2)</remarks>
        Public Sub xlsCellBorder(ByVal txls As Object, _
                ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long)

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()
            txls.Selection.Borders(xlDiagonalDown).LineStyle = xlNone
            txls.Selection.Borders(xlDiagonalUp).LineStyle = xlNone


            With txls.Selection.Borders(xlEdgeLeft)
                .LineStyle = xlContinuous
                .Weight = xlThin
                .ColorIndex = xlAutomatic
            End With


            With txls.Selection.Borders(xlEdgeTop)
                .LineStyle = xlContinuous
                .Weight = xlThin
                .ColorIndex = xlAutomatic
            End With


            With txls.Selection.Borders(xlEdgeBottom)
                .LineStyle = xlContinuous
                .Weight = xlThin
                .ColorIndex = xlAutomatic
            End With


            With txls.Selection.Borders(xlEdgeRight)
                .LineStyle = xlContinuous
                .Weight = xlThin
                .ColorIndex = xlAutomatic
            End With


            '---- 수직 COL1개인경우제외
            If tCol1 <> tCol2 Then
                With txls.Selection.Borders(xlInsideVertical)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With
            End If

            '---- 수평 ROW1개인경우 제외
            If tRow1 <> tRow2 Then
                With txls.Selection.Borders(xlInsideHorizontal)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With
            End If

        End Sub

        ''' <summary>
        ''' 셀 -> 범위지정 보더표현(Col1,Row1,Col2,Row2)
        ''' </summary>
        ''' <param name="txls"></param>
        ''' <param name="tCol1"></param>
        ''' <param name="tRow1"></param>
        ''' <param name="tCol2"></param>
        ''' <param name="tRow2"></param>
        ''' <param name="sbTop"></param>
        ''' <param name="sbButtom"></param>
        ''' <param name="sbLeft"></param>
        ''' <param name="sbRight"></param>
        ''' <remarks>셀 -> 범위지정 보더표현(Col1,Row1,Col2,Row2)</remarks>
        Public Sub xlsCellBorder01(ByVal txls As Object, _
        ByVal tCol1 As Long, ByVal tRow1 As Long, ByVal tCol2 As Long, ByVal tRow2 As Long, _
        Optional ByVal sbTop As Boolean = False, Optional ByVal sbButtom As Boolean = False, _
        Optional ByVal sbLeft As Boolean = False, Optional ByVal sbRight As Boolean = False)

            txls.Range(txls.Cells(tRow1, tCol1), txls.Cells(tRow2, tCol2)).Select()
            txls.Selection.Borders(xlDiagonalDown).LineStyle = xlNone
            txls.Selection.Borders(xlDiagonalUp).LineStyle = xlNone

            If sbLeft = True Then

                With txls.Selection.Borders(xlEdgeLeft)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With

            End If


            If sbTop = True Then

                With txls.Selection.Borders(xlEdgeTop)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With

            End If


            If sbButtom = True Then

                With txls.Selection.Borders(xlEdgeBottom)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With

            End If


            If sbRight = True Then

                With txls.Selection.Borders(xlEdgeRight)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With

            End If


            '---- 수직 COL1개인경우제외
            If tCol1 <> tCol2 Then
                With txls.Selection.Borders(xlInsideVertical)
                    .LineStyle = xlContinuous
                    .Weight = xlThin
                    .ColorIndex = xlAutomatic
                End With
            End If

            '    '---- 수평 ROW1개인경우 제외
            '    If tRow1 <> tRow2 Then
            '        With txls.Selection.Borders(xlInsideHorizontal)
            '            .LineStyle = xlContinuous
            '            .Weight = xlThin
            '            .ColorIndex = xlAutomatic
            '        End With
            '    End If

        End Sub


        ''' <summary>
        ''' 셀 -> 범위지정 보더표현(Col1,Row1,Col2,Row2)
        ''' </summary>
        ''' <param name="oXls"></param>
        ''' <param name="iCol1"></param>
        ''' <param name="iRow1"></param>
        ''' <param name="iCol2"></param>
        ''' <param name="iRow2"></param>
        ''' <param name="WLeft"></param>
        ''' <param name="WTop"></param>
        ''' <param name="Img"></param>
        ''' <remarks>셀 -> 범위지정 보더표현(Col1,Row1,Col2,Row2)</remarks>
        Public Sub xlsImage(ByVal oXls As Excel.Application, ByVal iCol1 As Long, ByVal iRow1 As Long, ByVal iCol2 As Long, ByVal iRow2 As Long, ByVal WLeft As Integer, ByVal WTop As Integer, ByVal Img As String)

            '---- 파일 존재 유무
            Dim sbFilePath As String
            sbFilePath = My.Application.Info.DirectoryPath & "\" & Img

            If Dir(sbFilePath) <> "" Then

                oXls.Range(oXls.Cells(iRow1, iCol1), oXls.Cells(iRow2, iCol2)).Select()

                '----- 그림삽입
                With oXls
                    .ActiveSheet.Pictures.Insert(My.Application.Info.DirectoryPath & "\" & Img).Select()
                    .Selection.ShapeRange.IncrementLeft(WLeft)
                    .Selection.ShapeRange.IncrementTop(WTop)
                End With

            End If

        End Sub

    End Class
#End Region

#Region "WJS_ZZ_Defined"

    Public Const SYSTEMNAME As String = "SAP Business ONE"
    Public Const ODBC_LIST As String = "Software\ODBC\ODBC.INI\ODBC Data Sources"
    Public Const ODBC_LIST_INI As String = "Software\ODBC\ODBCINST.INI\ODBC Drivers"
    Public Const ODBC_LIST_INI_SQL As String = "Software\ODBC\ODBCINST.INI\SQL Server"
    Public Const ODBC_LIST_NEW As String = "Software\ODBC\ODBC.INI\"
    Public Const ODBC_RPT_PASS As String = "SOFTWARE\SAP\SAP MANAGE\SAP Business One\AddOn"
    Public Const ODBC_RPT_NAME As String = "DBS_CRSS"

    Public Const CAPTION_CLEAR As String = "제거"
    Public Const CAPTION_ADD As String = "추가"
    Public Const CAPTION_OK As String = "확인"
    Public Const CAPTION_UPDATE As String = "갱신"
    Public Const CAPTION_FIND As String = "찾기"
    Public Const CAPTION_DELETE As String = "삭제"
    Public Const CAPTION_ERROR As String = "에러"
    Public Const CAPTION_CANCEL As String = "취소"
    Public Const CAPTION_ABORT As String = "멈춤"
    Public Const CAPTION_RETRY As String = "재시도"
    Public Const CAPTION_IGNORE As String = "무시"
    Public Const CAPTION_YES As String = "예"
    Public Const CAPTION_NO As String = "아니오"

    Public Const CLASS_TOP As Byte = 0
    Public Const CLASS_ONE As Byte = 1
    Public Const CLASS_TWO As Byte = 2
    Public Const CLASS_THREE As Byte = 3
    Public Const CLASS_FOUR As Byte = 4
    Public Const CLASS_FIVE As Byte = 5

    Public Const TRUE_VALUE As Byte = 1
    Public Const FALSE_VALUE As Byte = 0

    Public Const RTN_TRUE As String = "success"
    Public Const RTN_FALSE As String = "exist"
    Public Const RTN_FAIL As String = "fail"
    Public Const RTN_ERROR As String = "error"
    Public Const YES_KOR_TEXT As String = "예"
    Public Const NO_KOR_TEXT As String = "아니오"
    Public Const YES_ENG_TEXT As String = "Y"
    Public Const NO_ENG_TEXT As String = "N"

    Public Const SPACE_ONE As String = "　"                'SBO의 스페이스 처리 상수

    Public Const SPC_MARK As String = "  "
    Public Const LIK_MARK As String = "%"
    Public Const ALL_MARK As String = "*"
    Public Const YES_MARK As String = "Y"
    Public Const NO_MARK As String = "N"
    Public Const INS_FLAG As String = "I"
    Public Const UPT_FLAG As String = "U"
    Public Const QUE_FLAG As String = "Q"
    Public Const SEL_FLAG As String = "F"
    Public Const DEL_FLAG As String = "D"

    Public oApplication As SAPbouiCOM.Application
    Public oCompany As SAPbobsCOM.Company

    'Public oCrxReport As CRAXDDRT.Report
    'Public oCrxApplication As New CRAXDDRT.ApplicationClass

    Public gFormCnt As Long                      '로드된 Form의 갯수
    Public gODBCName As String
    Public gODBCPath As String
    Public gRptDrv As String
    Public gPFormUID As String                    '부모창의 FormUID
    Public gCFormUID As String                    '자식창의 FormUID
    Public gv_Modal_b As Boolean
    Public gv_ModalID_i As String
    Public gMSGUID As String                    '메시지 화면 컨트롤을 위한 전역변수

    Public gAPPROVAL As String                    '승인권한요청을 위한 전역변수

    Public gAPPROVALCHK As Boolean                   '승인결정리포트에서 하나만 선택해서 체크되도록

    Public pv_No As String
    Public pv_Nm As String

    Public Const vbKeyTab As Integer = 9

    'Global Variable-----------------------------------------------------------------------

    Enum Enum_MsgType
        m_Message = 1
        m_Caption = 2
    End Enum

    Enum Enum_ActionMode
        m_Add = 1
        m_addline = 2
        m_Find = 3
        m_Save = 4
        m_copy = 5
        m_CopyLine = 6
        m_Update = 7
        m_Delete = 8
        m_DelLine = 9
        m_Cancel = 10
        m_Close = 11
    End Enum

    Enum Enum_PrintMode
        m_Printer = 1
        m_Monitor = 2
    End Enum

    Enum Enum_LockCase
        m_Rate = 1
        m_Minors = 2
        m_Single = 3
        m_Qty = 9
    End Enum

    Enum Enum_TextCase
        m_Normal = 1
        m_LCase = 2
        m_UCase = 3
    End Enum

    Enum Enum_FormItemType
        it_ACTIVE_X = 102
        it_BUTTON = 4
        it_CHECK_BOX = 121
        it_COMBO_BOX = 113
        it_EDIT = 16
        it_EXTEDIT = 118
        it_FOLDER = 99
        it_LINKED_BUTTON = 116
        it_MATRIX = 127
        it_OPTION_BUTTON = 122
        it_PANE_COMBO_BOX = 104
        it_PICTURE = 117
        it_RECTANGLE = 100
        it_STATIC = 8
    End Enum

    Enum Enum_FindFlag
        m_NormalClick = 1
        m_MenuClick = 2
        m_TopClick = 3
        m_LeftClick = 4
        m_RightClick = 5
        m_BottomClick = 6
    End Enum

    Public Structure uEvent
        Dim ItEvent As SAPbouiCOM.ItemEvent
        Dim DtEvent As SAPbouiCOM.IBusinessObjectInfo
        Dim MuEvent As SAPbouiCOM.IMenuEvent
    End Structure

#End Region

#Region "WJS_ZZ_XMLForm"
    Class WJS_ZZ_XMLForm
        'Dim clsWJS_ZZ_CommFunc As WJS_ZZ_CommFunc

        Public Sub XMLMenu(ByVal pFileName As String, ByVal pAction As Boolean)

            Try
                Dim oXMLDoc As Xml.XmlDocument
                Dim Language As String

                oXMLDoc = New Xml.XmlDocument

                Language = LanguageToString()

                If pAction Then '메뉴추가
                    'pFileName = App.Path + "\MNU\" & Language & "\" & pFileName & "_" & Language & ".xml"
                    pFileName = My.Application.Info.DirectoryPath + "\MNU\" & pFileName & ".xml"
                Else '메뉴삭제
                    'pFileName = App.Path + "\MNU\" & Language & "\" & pFileName & "_REMOVE_" & Language & ".xml"
                    pFileName = My.Application.Info.DirectoryPath + "\MNU\" & pFileName & "_REMOVE_" & ".xml"
                End If

                '// load the content of the XML File
                Call oXMLDoc.Load(pFileName)

                '한국어를 다른 언어로 바꾼다.
                If Language <> "KOR" Then
                    Call MenuXml(Language, oXMLDoc)
                End If

                '// load the form to the SBO application in one batch
                B1Connections.theAppl.LoadBatchActions(oXMLDoc.ToString)

                oXMLDoc = Nothing

                Exit Sub
            Catch ex As Exception

            End Try
        End Sub


        Public Function XMLForm(ByVal pFileName As String) As Xml.XmlDocument
            Dim oXMLDoc As New Xml.XmlDocument
            Dim Language As String
            Dim Height As Integer
            Dim Width As Integer

            Try
                Language = LanguageToString()

                'pFileName = App.Path + "\SRF\" & Language & "\" & pFileName & "_" & Language & ".srf"
                pFileName = My.Application.Info.DirectoryPath + "\SRF\" & pFileName & ".srf"

                Call oXMLDoc.Load(pFileName)            'load the content of the XML File

                gFormCnt = gFormCnt + 1                 '여래개의 폼을 Load할 경우 폼의 UID로 사용함.

                Height = oXMLDoc.SelectSingleNode("Application/forms/action/form/@height").Value
                Width = oXMLDoc.SelectSingleNode("Application/forms/action/form/@width").Value

                oXMLDoc.SelectSingleNode("Application/forms/action/form/@uid").Value = _
                    oXMLDoc.SelectSingleNode("Application/forms/action/form/@uid").Value & gFormCnt

                oXMLDoc.SelectSingleNode("Application/forms/action/form/@top").Value = _
                       (oApplication.Desktop.Height - Height - 130) / 2

                oXMLDoc.SelectSingleNode("Application/forms/action/form/@left").Value = _
                       (oApplication.Desktop.Width - Width) / 2


                If Language <> "KOR" Then
                    Call CaptionXml(Language, oXMLDoc)
                End If

                oApplication.LoadBatchActions(oXMLDoc.ToString)       'now you may load the form to the application

                XMLForm = oXMLDoc
                oXMLDoc = Nothing

                Exit Function

            Catch ex As Exception
                XMLForm = oXMLDoc
            End Try

        End Function


        Private Sub MenuXml(ByVal cv_language_s As String, ByVal oXMLDoc As System.Xml.XmlDocument)

            Try
                Dim i, j As Integer

                Dim sarKey() As String
                Dim sarValue() As String
                Dim nodelist As Xml.XmlNodeList
                Dim xSQL As String
                Dim strQuery As String
                Dim Rs As SAPbobsCOM.Recordset
                Dim cv_cnt_i As Integer

                xSQL = "select  '' as MsgValue " & vbCrLf

                nodelist = oXMLDoc.GetElementsByTagName("@String")


                For i = 0 To nodelist.Count - 1
                    xSQL = xSQL & " UNION ALL " & vbCrLf
                    xSQL = xSQL & "select  N'" & nodelist.Item(i).Value & "' as MsgValue " & vbCrLf
                Next i
                nodelist = Nothing


                strQuery = " select  distinct C.MsgValue as MsgKey , A.MsgValue as MsgValue " & vbCrLf
                strQuery = strQuery & " from " & vbCrLf
                strQuery = strQuery & "(" & xSQL & vbCrLf
                strQuery = strQuery & ") C " & vbCrLf
                strQuery = strQuery & "inner join " & vbCrLf
                strQuery = strQuery & "( " & vbCrLf
                strQuery = strQuery & "  select max(usetp) as usetp, max(MsgCd) as MsgCd , MsgValue " & vbCrLf
                strQuery = strQuery & "  from [RepDB].dbo.messagemr  " & vbCrLf
                strQuery = strQuery & " where  usetp = '2' and LangCd = 'KOR' " & vbCrLf
                strQuery = strQuery & "  group by MsgValue " & vbCrLf
                strQuery = strQuery & ") B on C.MsgValue = B.MsgValue " & vbCrLf
                strQuery = strQuery & "Inner join  " & vbCrLf
                strQuery = strQuery & "( " & vbCrLf
                strQuery = strQuery & "  select usetp, MsgCd, MsgValue " & vbCrLf
                strQuery = strQuery & "  from [RepDB].dbo.messagemr " & vbCrLf
                strQuery = strQuery & "  where  usetp = '2' and LangCd = '" & cv_language_s & "' " & vbCrLf
                strQuery = strQuery & ") A  on A.MsgCd = B.MsgCd and A.usetp = B.usetp " & vbCrLf
                strQuery = strQuery & " where Rtrim(C.msgvalue) <> '' and A.MsgValue <> '' " & vbCrLf
                strQuery = strQuery & " and c.msgvalue <> '#' " & vbCrLf
                Rs = oCompany.GetBusinessObject(BoObjectTypes.BoRecordset)

                Rs.DoQuery(strQuery)
                cv_cnt_i = Rs.RecordCount

                ReDim sarKey(cv_cnt_i)
                ReDim sarValue(cv_cnt_i)

                For i = 0 To cv_cnt_i - 1
                    sarKey(i) = Rs.Fields.Item(0).Value
                    sarValue(i) = Rs.Fields.Item(1).Value
                    Rs.MoveNext()
                Next

                If (Not (Rs) Is Nothing) Then Marshal.ReleaseComObject(Rs)
                Rs = Nothing

                '컨트롤

                'Set nodelist = oXMLDoc.selectNodes("Application/Menus/action/Menu/@String")
                nodelist = oXMLDoc.GetElementsByTagName("@String")
                For i = 0 To nodelist.Count - 1
                    For j = 0 To UBound(sarKey) - 1
                        If sarKey(j) = nodelist.Item(i).Value Then
                            nodelist.Item(i).Value = sarValue(j)
                            Exit For
                        End If
                    Next j
                Next i
                nodelist = Nothing

                ReDim sarKey(0)
                ReDim sarValue(0)
            Catch ex As Exception
                CFL.COMMON_MESSAGE("!", ex.Message)
            End Try
        End Sub

        Private Sub CaptionXml(ByVal cv_language_s As String, ByVal oXMLDoc As System.Xml.XmlDocument)

            Try
                Dim i, j As Integer
                Dim sarKey() As String
                Dim sarValue() As String
                Dim cv_msgvalue_s As String
                Dim nodelist As Xml.XmlNodeList
                Dim xSQL As String
                Dim strQuery As String
                Dim Rs As SAPbobsCOM.Recordset
                Dim cv_cnt_i As Integer

                '폼 제목
                cv_msgvalue_s = oXMLDoc.SelectSingleNode("Application/forms/action/form/@title").Value

                xSQL = "select  N'" & cv_msgvalue_s & "' as MsgValue " & vbCrLf

                '컨트롤

                nodelist = oXMLDoc.SelectNodes("Application/forms/action/form/items/action/item/specific/@caption")
                For i = 0 To nodelist.Count - 1
                    xSQL = xSQL & " UNION ALL " & vbCrLf
                    xSQL = xSQL & "select  N'" & nodelist.Item(i).Value & "' as MsgValue " & vbCrLf
                Next i
                nodelist = Nothing

                '칼럼

                nodelist = oXMLDoc.SelectNodes("Application/forms/action/form/items/action/item/specific/columns/action/column/@title")
                For i = 0 To nodelist.Count - 1
                    xSQL = xSQL & " UNION ALL " & vbCrLf
                    xSQL = xSQL & "select  N'" & nodelist.Item(i).Value & "' as MsgValue " & vbCrLf
                Next i
                nodelist = Nothing

                strQuery = " select  distinct C.MsgValue as MsgKey , A.MsgValue as MsgValue " & vbCrLf
                strQuery = strQuery & " from " & vbCrLf
                strQuery = strQuery & "(" & xSQL & vbCrLf
                strQuery = strQuery & ") C " & vbCrLf
                strQuery = strQuery & "inner join " & vbCrLf
                strQuery = strQuery & "( " & vbCrLf
                strQuery = strQuery & "  select max(usetp) as usetp, max(MsgCd) as MsgCd , MsgValue " & vbCrLf
                strQuery = strQuery & "  from [RepDB].dbo.messagemr  " & vbCrLf
                strQuery = strQuery & " where  usetp = '2' and LangCd = 'KOR' " & vbCrLf
                strQuery = strQuery & "  group by MsgValue " & vbCrLf
                strQuery = strQuery & ") B on C.MsgValue = B.MsgValue " & vbCrLf
                strQuery = strQuery & "Inner join  " & vbCrLf
                strQuery = strQuery & "( " & vbCrLf
                strQuery = strQuery & "  select usetp, MsgCd, MsgValue " & vbCrLf
                strQuery = strQuery & "  from [RepDB].dbo.messagemr " & vbCrLf
                strQuery = strQuery & "  where  usetp = '2' and LangCd = '" & cv_language_s & "' " & vbCrLf
                strQuery = strQuery & ") A  on A.MsgCd = B.MsgCd and A.usetp = B.usetp " & vbCrLf
                strQuery = strQuery & " where Rtrim(C.msgvalue) <> '' and A.MsgValue <> '' " & vbCrLf
                strQuery = strQuery & " and c.msgvalue <> '#' " & vbCrLf
                Rs = oCompany.GetBusinessObject(BoObjectTypes.BoRecordset)

                Rs.DoQuery(strQuery)
                cv_cnt_i = Rs.RecordCount

                ReDim sarKey(cv_cnt_i)
                ReDim sarValue(cv_cnt_i)

                For i = 0 To cv_cnt_i - 1
                    sarKey(i) = Rs.Fields.Item(0).Value
                    sarValue(i) = Rs.Fields.Item(1).Value
                    Rs.MoveNext()
                Next

                If (Not (Rs) Is Nothing) Then Marshal.ReleaseComObject(Rs)
                Rs = Nothing


                '폼 제목
                cv_msgvalue_s = oXMLDoc.SelectSingleNode("Application/forms/action/form/@title").Value

                For i = 0 To UBound(sarKey) - 1
                    If sarKey(i) = cv_msgvalue_s Then
                        oXMLDoc.SelectSingleNode("Application/forms/action/form/@title").Value = sarValue(i)
                        Exit For
                    End If
                Next i

                '컨트롤

                nodelist = oXMLDoc.SelectNodes("Application/forms/action/form/items/action/item/specific/@caption")
                For i = 0 To nodelist.Count - 1
                    For j = 0 To UBound(sarKey) - 1
                        If sarKey(j) = nodelist.Item(i).Value Then
                            nodelist.Item(i).Value = sarValue(j)
                            Exit For
                        End If
                    Next j
                Next i
                nodelist = Nothing

                '칼럼
                nodelist = oXMLDoc.SelectNodes("Application/forms/action/form/items/action/item/specific/columns/action/column/@title")
                For i = 0 To nodelist.Count - 1
                    For j = 0 To UBound(sarKey) - 1
                        If sarKey(j) = nodelist.Item(i).Value Then
                            nodelist.Item(i).Value = sarValue(j)
                            Exit For
                        End If
                    Next j
                Next i
                nodelist = Nothing

                ReDim sarKey(0)
                ReDim sarValue(0)
            Catch ex As Exception
                CFL.COMMON_MESSAGE("!", ex.Message)
            End Try
        End Sub


    End Class
#End Region


    Public Function LanguageToString() As String
        LanguageToString = String.Empty
        Select Case B1Connections.diCompany.language
            Case SAPbobsCOM.BoSuppLangs.ln_Korean_Kr : LanguageToString = "KOR"
            Case SAPbobsCOM.BoSuppLangs.ln_Japanese_Jp : LanguageToString = "JPN"
            Case SAPbobsCOM.BoSuppLangs.ln_French : LanguageToString = "FRN"
            Case SAPbobsCOM.BoSuppLangs.ln_English : LanguageToString = "ENG"
            Case SAPbobsCOM.BoSuppLangs.ln_Chinese : LanguageToString = "CHN"
        End Select
        Return LanguageToString
    End Function


    ''' <summary>
    ''' 링크화면 오픈
    ''' </summary>
    ''' <param name="oForm">Form</param>
    ''' <param name="strObject">Link Object</param>
    ''' <param name="strDocEntry">DocEntry</param>
    ''' <remarks></remarks>
    Public Sub ShowDocEntLinkForm(ByVal oForm As SAPbouiCOM.Form, ByVal strObject As String, ByVal strDocEntry As String)
        Dim isHidEditItem1 As Boolean = False
        Dim isHidEditItem2 As Boolean = False
        Dim isHidLnkBtn As Boolean = False
        Dim oHidEditItem1 As SAPbouiCOM.Item
        Dim oHidEditItem2 As SAPbouiCOM.Item
        Dim oHidLnkBtn As SAPbouiCOM.Item
        Dim xmlAtt As Xml.XmlAttribute
        Dim xmlDoc As Xml.XmlDocument = New Xml.XmlDocument()

        Try

            If Not IsNothing(oForm) Then
                oForm.Freeze(True)
            Else
                Exit Try
            End If

            ''종근당 건강 에만 추가(생산오더 링크버튼일경우)
            'If strObject = "202" Then
            '    Dim strDocNum As String
            '    strDocNum = CFL.GetValue("SELECT ""DocNum"" FROM OWOR WHERE ""DocEntry"" = " & strDocEntry)
            '    CKH_COMMON.ShowProductionOrder(oForm, strDocNum)
            '    Exit Try
            'End If

            '폼 XML로드
            xmlDoc.LoadXml(oForm.GetAsXML())

            '링크버튼 호출에 필요한 Item 존재여부 확인
            For Each node As XmlNode In xmlDoc.SelectNodes("Application/forms/action/form/items/action/item")

                xmlAtt = node.Attributes.ItemOf("uid")

                If (Not xmlAtt Is Nothing) Then

                    If (xmlAtt.InnerText = "edtHIDZ9Z8") Then

                        isHidEditItem1 = True

                        If isHidEditItem1 And isHidEditItem2 And isHidLnkBtn Then Exit For

                    ElseIf (xmlAtt.InnerText = "edtHIDZ9Z9") Then

                        isHidEditItem2 = True

                        If isHidEditItem1 And isHidEditItem2 And isHidLnkBtn Then Exit For

                    ElseIf (xmlAtt.InnerText = "lnkHIDZ9Z9") Then

                        isHidLnkBtn = True

                        If isHidEditItem1 And isHidEditItem2 And isHidLnkBtn Then Exit For

                    End If

                End If

            Next

            '링크버튼 호출에 필요한 Item이 없으면 생성
            If Not isHidEditItem1 Then
                oHidEditItem1 = oForm.Items.Add("edtHIDZ9Z8", BoFormItemTypes.it_EDIT)
                oHidEditItem1.Left = -335
                oHidEditItem1.Top = 486
                oForm.Items.Item("edtHIDZ9Z8").AffectsFormMode = False
            End If

            '링크버튼 호출에 필요한 Item이 없으면 생성
            If Not isHidEditItem2 Then
                oHidEditItem2 = oForm.Items.Add("edtHIDZ9Z9", BoFormItemTypes.it_EDIT)
                oHidEditItem2.Left = -435
                oHidEditItem2.Top = 486
                oForm.Items.Item("edtHIDZ9Z9").AffectsFormMode = False
            End If

            '링크버튼 호출에 필요한 Item이 없으면 생성
            If Not isHidLnkBtn Then
                oHidLnkBtn = oForm.Items.Add("lnkHIDZ9Z9", BoFormItemTypes.it_LINKED_BUTTON)
                oHidLnkBtn.Left = -315
                oHidLnkBtn.LinkTo = "edtHIDZ9Z8"
                oHidLnkBtn.Top = 486
            End If

            '링크 버튼 오브젝트 처리
            oForm.Items.Item("lnkHIDZ9Z9").Specific.LinkedObject = Trim(strObject)
            oForm.Items.Item("lnkHIDZ9Z9").Specific.LinkedObjectType = Trim(strObject)
            oForm.Items.Item("edtHIDZ9Z8").Specific.Value = Trim(strDocEntry)
            oForm.Items.Item("edtHIDZ9Z9").Click()

            '링크버튼 클릭
            oForm.Items.Item("lnkHIDZ9Z9").Click()

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ShowDocEntLinkForm " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            If Not IsNothing(oForm) Then oForm.Freeze(False)
            oHidEditItem1 = Nothing
            oHidEditItem2 = Nothing
            oHidLnkBtn = Nothing
            xmlAtt = Nothing
            xmlDoc = Nothing
        End Try

    End Sub


    ''' <summary>
    ''' 링크화면 오픈
    ''' </summary>
    ''' <param name="oForm">Form</param>
    ''' <param name="strObject">Link Object</param>
    ''' <param name="strDocNum">DocNum</param>
    ''' <param name="strSeries">Series</param>
    ''' <remarks></remarks>
    Public Sub ShowDocNumLinkForm(ByVal oForm As SAPbouiCOM.Form, ByVal strObject As String, ByVal strDocNum As String, Optional ByVal strSeries As String = "")
        Dim isHidEditItem1 As Boolean = False
        Dim isHidEditItem2 As Boolean = False
        Dim isHidLnkBtn As Boolean = False
        Dim oHidEditItem1 As SAPbouiCOM.Item
        Dim oHidEditItem2 As SAPbouiCOM.Item
        Dim oHidLnkBtn As SAPbouiCOM.Item
        Dim xmlAtt As Xml.XmlAttribute
        Dim xmlDoc As Xml.XmlDocument = New Xml.XmlDocument()
        Dim oRS As SAPbobsCOM.Recordset
        Dim strDocEntry As String = "-1"
        Dim xSQL As String = ""

        Try

            If Not IsNothing(oForm) Then
                oForm.Freeze(True)
            Else
                Exit Try
            End If

            ''종근당 건강 에만 추가(생산오더 링크버튼일경우)
            'If strObject = "202" Then
            '    CKH_COMMON.ShowProductionOrder(oForm, strDocNum)
            '    Exit Try
            'End If

            '폼 XML로드
            xmlDoc.LoadXml(oForm.GetAsXML())

            '링크버튼 호출에 필요한 Item 존재여부 확인
            For Each node As XmlNode In xmlDoc.SelectNodes("Application/forms/action/form/items/action/item")

                xmlAtt = node.Attributes.ItemOf("uid")

                If (Not xmlAtt Is Nothing) Then

                    If (xmlAtt.InnerText = "edtHIDZ9Z8") Then

                        isHidEditItem1 = True

                        If isHidEditItem1 And isHidEditItem2 And isHidLnkBtn Then Exit For

                    ElseIf (xmlAtt.InnerText = "edtHIDZ9Z9") Then

                        isHidEditItem2 = True

                        If isHidEditItem1 And isHidEditItem2 And isHidLnkBtn Then Exit For

                    ElseIf (xmlAtt.InnerText = "lnkHIDZ9Z9") Then

                        isHidLnkBtn = True

                        If isHidEditItem1 And isHidEditItem2 And isHidLnkBtn Then Exit For

                    End If

                End If

            Next

            '링크버튼 호출에 필요한 Item이 없으면 생성
            If Not isHidEditItem1 Then
                oHidEditItem1 = oForm.Items.Add("edtHIDZ9Z8", BoFormItemTypes.it_EDIT)
                oHidEditItem1.Left = -335
                oHidEditItem1.Top = 486
                oForm.Items.Item("edtHIDZ9Z8").AffectsFormMode = False
            End If

            '링크버튼 호출에 필요한 Item이 없으면 생성
            If Not isHidEditItem2 Then
                oHidEditItem2 = oForm.Items.Add("edtHIDZ9Z9", BoFormItemTypes.it_EDIT)
                oHidEditItem2.Left = -435
                oHidEditItem2.Top = 486
                oForm.Items.Item("edtHIDZ9Z9").AffectsFormMode = False
            End If

            '링크버튼 호출에 필요한 Item이 없으면 생성
            If Not isHidLnkBtn Then
                oHidLnkBtn = oForm.Items.Add("lnkHIDZ9Z9", BoFormItemTypes.it_LINKED_BUTTON)
                oHidLnkBtn.Left = -315
                oHidLnkBtn.LinkTo = "edtHIDZ9Z8"
                oHidLnkBtn.Top = 486
            End If

            'DocEntry 번호를 조회
            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            'oRS.DoQuery(" CALL WJS_SP_AD_GETDOCENT('" & strObject & "', '" & strDocNum & "', '" & strSeries & "') ")
            oRS.DoQuery(" EXEC WJS_SP_AD_GETDOCENT '" & strObject & "', '" & strDocNum & "', '" & strSeries & "' ")
            If Not oRS.EoF Then strDocEntry = Trim(oRS.Fields.Item("DOCENT").Value)

            '링크 버튼 오브젝트 처리
            oForm.Items.Item("lnkHIDZ9Z9").Specific.LinkedObject = Trim(strObject)
            oForm.Items.Item("lnkHIDZ9Z9").Specific.LinkedObjectType = Trim(strObject)
            oForm.Items.Item("edtHIDZ9Z8").Specific.Value = Trim(strDocEntry)
            oForm.Items.Item("edtHIDZ9Z9").Click()

            '링크버튼 클릭
            oForm.Items.Item("lnkHIDZ9Z9").Click()

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ShowDocNumLinkForm " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            If Not IsNothing(oForm) Then oForm.Freeze(False)
            oHidEditItem1 = Nothing
            oHidEditItem2 = Nothing
            oHidLnkBtn = Nothing
            xmlAtt = Nothing
            xmlDoc = Nothing
            oRS = Nothing
        End Try

    End Sub


    ''' <summary>
    ''' ShowProductionOrder
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="strDocNum"></param>
    ''' <remarks></remarks>
    Public Sub ShowProductionOrder(ByVal oForm As SAPbouiCOM.Form, ByVal strDocNum As String)

        Try

            '링크화면 Open
            If (B1Connections.theAppl.Menus.Exists("4369")) Then

                B1Connections.theAppl.ActivateMenuItem("4369")

                Dim cForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.ActiveForm

                Try

                    cForm.Freeze(True)

                    cForm.Mode = BoFormMode.fm_FIND_MODE
                    cForm.Items.Item("18").Specific.Value = strDocNum

                    cForm.Items.Item("1").Click(BoCellClickType.ct_Regular)

                Catch ex As Exception
                    B1Connections.theAppl.StatusBar.SetText("ShowProductionOrder " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                Finally
                    cForm.Freeze(False)
                End Try

            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ShowProductionOrder " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub


    ''' <summary>
    ''' GetUDOKey
    ''' </summary>
    ''' <param name="strTableNM">UDO 테이블 명</param>
    ''' <returns>DocEntry, DocNum 리턴</returns>
    ''' <remarks>신규로 생성될 DocEntry, DocNum 조회</remarks>
    Public Function GetUDOKey(ByVal strTableNM As String) As Hashtable
        Dim hsTable As Hashtable = New Hashtable()
        Dim oRS As SAPbobsCOM.Recordset
        Dim xSQL As String = ""

        Try
            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            xSQL = ""
            xSQL = xSQL & vbCrLf & " DO "
            xSQL = xSQL & vbCrLf & " BEGIN "
            xSQL = xSQL & vbCrLf & "    DECLARE IN_TABLENM   NVARCHAR(20) := '" & strTableNM & "'; "
            xSQL = xSQL & vbCrLf & "    DECLARE OUT_DOCENT   NVARCHAR(20) := ''; "
            xSQL = xSQL & vbCrLf & "    DECLARE OUT_DOCNUM   NVARCHAR(50) := ''; "
            xSQL = xSQL & vbCrLf & "    CALL WJS_SP_AD_GETUDOKEY(IN_TABLENM, :OUT_DOCENT, :OUT_DOCNUM); "
            xSQL = xSQL & vbCrLf & "    SELECT :OUT_DOCENT AS ""DocEntry"", :OUT_DOCNUM AS ""DocNum"" FROM DUMMY; "
            xSQL = xSQL & vbCrLf & " END "

            oRS.DoQuery(xSQL)

            If Not oRS.EoF Then
                hsTable.Add("DocEntry", Trim(oRS.Fields.Item("DocEntry").Value.ToString))
                hsTable.Add("DocNum", Trim(oRS.Fields.Item("DocNum").Value.ToString))
            Else
                hsTable.Add("DocEntry", "")
                hsTable.Add("DocNum", "")
            End If

        Catch ex As Exception
            If (Not hsTable.ContainsKey("DocEntry")) Then
                hsTable.Add("DocEntry", "")
            End If
            If (Not hsTable.ContainsKey("DocNum")) Then
                hsTable.Add("DocNum", "")
            End If
        Finally
            oRS = Nothing
        End Try

        Return hsTable
    End Function


    ''' <summary>
    ''' GetUDOKey
    ''' </summary>
    ''' <param name="strTableNM">UDO 테이블 명</param>
    ''' <param name="ObjType">SAPbobsCOM.BoUDOObjType</param>
    ''' <returns>DocEntry, DocNum(Code) 리턴</returns>
    ''' <remarks>신규로 생성될 DocEntry, DocNum(Code) 조회</remarks>
    Public Function GetUDOKey(ByVal strTableNM As String, ByVal ObjType As SAPbobsCOM.BoUDOObjType) As Hashtable
        Dim strDocEnt As String = ""
        Dim hsTable As Hashtable = New Hashtable()
        Dim xSQL As String = ""

        Try

            hsTable = LMS_COMMON.GetUDOKey(strTableNM)

            If ObjType = BoUDOObjType.boud_MasterData Then
                hsTable.Remove("DocNum")
                hsTable.Add("DocNum", LMS_COMMON.GetMaxCode(strTableNM))
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetUDOKey " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

        Return hsTable
    End Function


    ''' <summary>
    ''' GetUDOKey
    ''' </summary>
    ''' <param name="strTableNM">UDO 테이블 명</param>
    ''' <param name="ObjType">SAPbobsCOM.BoUDOObjType</param>
    ''' <param name="strDocNum">DocNum 또는 Code</param>
    ''' <returns>DocEntry</returns>
    ''' <remarks>신규로 생성될 DocEntry, DocNum(Code) 조회</remarks>
    Public Function GetUDOKey(ByVal strTableNM As String, ByVal ObjType As SAPbobsCOM.BoUDOObjType, ByRef strDocNum As String) As String
        Dim strDocEnt As String = ""
        Dim hsTable As Hashtable = New Hashtable()
        Dim oRS As SAPbobsCOM.Recordset
        Dim xSQL As String = ""

        Try

            hsTable = LMS_COMMON.GetUDOKey(strTableNM, ObjType)

            strDocEnt = hsTable.Item("DocEntry").ToString()
            strDocNum = hsTable.Item("DocNum").ToString()

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetUDOKey " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return strDocEnt
    End Function


    ''' <summary>
    ''' SetColorMenuItem
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetColorMenuItem()
        Dim xSQL As String = ""
        Dim strColorMenu As String = ""

        Try

            '애드온 색상값 설정(조합과 클레식은 처리하지 않음.)
            xSQL = "  "
            xSQL = xSQL & " SELECT ISNULL(MAX(CAST(B.U_RMK1 AS NVARCHAR(10))), '') AS COLOR "
            xSQL = xSQL & " FROM OADM A "
            xSQL = xSQL & " LEFT OUTER JOIN [@WJS_SAD021] B ON B.Code = 'LMS-AD00' AND A.Color = CAST(B.U_CD AS SMALLINT) "
            xSQL = xSQL & " WHERE A.Color NOT IN (0, 1) "

            strColorMenu = CFL.GetValue(xSQL)

            If strColorMenu <> "" Then
                '컬러메뉴 활성화
                B1Connections.theAppl.ActivateMenuItem(strColorMenu)
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("SetColorMenuItem " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub


    '****************************************************************************************************
    '   함수명      :   SetGridTitle
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   그리드 타이틀 지정

    '   인수        :   '// 사용
    '****************************************************************************************************
    Public Function SetGridTitle(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As String, ByVal pColNms As String, Optional ByVal pEdCols As String = "", _
                                 Optional ByVal pViCols As String = "", Optional ByVal pAffCols As String = "", Optional ByVal pAlignCols As String = "", _
                                 Optional ByVal pColor1Cols As String = "", Optional ByVal pColor2Cols As String = "") As Boolean

        Dim cols() As String
        Dim colNms() As String
        'Dim affCols() As String
        'Dim edCols() As String
        'Dim viCols() As String
        'Dim alignCols() As String
        Dim affCols As ArrayList = New ArrayList()
        Dim edCols As ArrayList = New ArrayList()
        Dim viCols As ArrayList = New ArrayList()
        Dim alignCols As ArrayList = New ArrayList()
        Dim Color1Cols As ArrayList = New ArrayList()
        Dim Color2Cols As ArrayList = New ArrayList()

        Dim xSQL As String = ""
        Dim i As Integer = 0

        Try

            SetGridTitle = False

            cols = Split(pCols, ",")
            colNms = Split(pColNms, ",")

            If (UBound(cols) - LBound(cols) <> UBound(colNms) - LBound(colNms)) Then
                Exit Function
            End If

            'For i = 0 To UBound(cols)

            '    If String.Compare(cols(i).ToString(), cols(i).ToUpper(), False) <> 0 Then
            '        xSQL = xSQL & IIf(xSQL = "", "", ",") & "'' AS """ & cols(i) & """"
            '    Else
            '        xSQL = xSQL & IIf(xSQL = "", "", ",") & "'' AS " & cols(i)

            '    End If
            'Next

            'xSQL = IIf(xSQL = "", "", "SELECT ") & xSQL

            pCols = " '' AS """ & pCols.Replace(" ", "").Replace(",", """,'' AS """) & """ "

            xSQL = "SELECT " & pCols

#If HANA = "Y" Then
                xSQL = xSQL & " FROM DUMMY;"
#End If
            'End If

            If xSQL <> "" Then
                Call oGrid.DataTable.ExecuteQuery(xSQL)
                Call oGrid.DataTable.Rows.Remove(0)
            End If

            If pEdCols.ToString.Trim.Length > 0 Then edCols.AddRange(Split(pEdCols.Replace(" ", ""), ","))

            If pViCols.ToString.Trim.Length > 0 Then viCols.AddRange(Split(pViCols.Replace(" ", ""), ","))

            If pAffCols.ToString.Trim.Length > 0 Then affCols.AddRange(Split(pAffCols.Replace(" ", ""), ","))

            If pAlignCols.ToString.Trim.Length > 0 Then alignCols.AddRange(Split(pAlignCols.Replace(" ", ""), ","))

            If pColor1Cols.ToString.Trim.Length > 0 Then Color1Cols.AddRange(Split(pColor1Cols.Replace(" ", ""), ","))

            If pColor2Cols.ToString.Trim.Length > 0 Then Color2Cols.AddRange(Split(pColor2Cols.Replace(" ", ""), ","))

            For i = LBound(cols) To UBound(cols)

                oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)))

                If edCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Editable = False
                End If

                If viCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Visible = False
                End If

                If affCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = False
                End If

                If alignCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = True
                End If

                If Color1Cols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).BackColor = 12777465
                End If

                If Color2Cols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).BackColor = 13624308
                End If

            Next i

            'For i = LBound(cols) To UBound(cols)
            '    oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)))
            'Next i

            'If pEdCols.ToString.Trim.Length > 0 Then
            '    edCols = Split(pEdCols, ",")
            '    For i = LBound(edCols) To UBound(edCols)
            '        oGrid.Columns.Item(edCols(i)).Editable = False
            '    Next i
            'End If

            'If pViCols.ToString.Trim.Length > 0 Then
            '    viCols = Split(pViCols, ",")
            '    For i = LBound(viCols) To UBound(viCols)
            '        oGrid.Columns.Item(viCols(i)).Visible = False
            '    Next i
            'End If

            'If pAffCols.ToString.Trim.Length > 0 Then
            '    affCols = Split(pAffCols, ",")
            '    For i = LBound(affCols) To UBound(affCols)
            '        oGrid.Columns.Item(affCols(i)).AffectsFormMode = False
            '    Next i
            'End If

            'If pAlignCols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pAlignCols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).RightJustified = True
            '    Next i
            'End If

            'If pColor1Cols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pColor1Cols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).BackColor = 12777465
            '    Next i
            'End If

            'If pColor2Cols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pColor2Cols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).BackColor = 13624308
            '    Next i
            'End If

            oGrid.AutoResizeColumns()

            SetGridTitle = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("SetGridTitle " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            cols = Nothing
            colNms = Nothing
            affCols = Nothing
            edCols = Nothing
            viCols = Nothing
            alignCols = Nothing

        End Try

    End Function


    '****************************************************************************************************
    '   함수명      :   SetGridTitle
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   그리드 타이틀 지정

    '   인수        :   
    '****************************************************************************************************
    Public Function SetGridTitle(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As String, ByVal pColNms As String, ByVal moduleini As ModuleIni, _
                                 Optional ByVal pEdCols As String = "", Optional ByVal pViCols As String = "", Optional ByVal pAffCols As String = "", _
                                 Optional ByVal pAlignCols As String = "") As Boolean

        Dim cols() As String
        Dim colNms() As String
        'Dim affCols() As String
        'Dim edCols() As String
        'Dim viCols() As String
        'Dim alignCols() As String
        Dim affCols As ArrayList = New ArrayList()
        Dim edCols As ArrayList = New ArrayList()
        Dim viCols As ArrayList = New ArrayList()
        Dim alignCols As ArrayList = New ArrayList()

        Dim xSQL As String = ""
        Dim i As Integer = 0

        Try

            SetGridTitle = False

            cols = Split(pCols, ",")
            colNms = Split(pColNms, ",")

            If (UBound(cols) - LBound(cols) <> UBound(colNms) - LBound(colNms)) Then
                Exit Function
            End If

            'For i = 0 To UBound(cols)
            '    xSQL = xSQL & IIf(xSQL = "", "", ",") & "'' AS '" & cols(i) & "'"
            'Next

            'xSQL = IIf(xSQL = "", "", "SELECT ") & xSQL

            pCols = " '' AS """ & pCols.Replace(" ", "").Replace(",", """,'' AS """) & """ "

            xSQL = "SELECT " & pCols

#If HANA = "Y" Then
                xSQL = xSQL & " FROM DUMMY;"
#End If

            If xSQL <> "" Then
                Call oGrid.DataTable.ExecuteQuery(xSQL)
                Call oGrid.DataTable.Rows.Remove(0)
            End If

            If pEdCols.ToString.Trim.Length > 0 Then edCols.AddRange(Split(pEdCols.Replace(" ", ""), ","))

            If pViCols.ToString.Trim.Length > 0 Then viCols.AddRange(Split(pViCols.Replace(" ", ""), ","))

            If pAffCols.ToString.Trim.Length > 0 Then affCols.AddRange(Split(pAffCols.Replace(" ", ""), ","))

            If pAlignCols.ToString.Trim.Length > 0 Then alignCols.AddRange(Split(pAlignCols.Replace(" ", ""), ","))

            For i = LBound(cols) To UBound(cols)

                oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)), moduleini)

                If edCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Editable = False
                End If

                If viCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Visible = False
                End If

                If affCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = False
                End If

                If alignCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = True
                End If

            Next i

            'For i = LBound(cols) To UBound(cols)
            '    oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)), moduleini)
            'Next i

            'If pEdCols.ToString.Trim.Length > 0 Then
            '    edCols = Split(pEdCols, ",")
            '    For i = LBound(edCols) To UBound(edCols)
            '        oGrid.Columns.Item(edCols(i)).Editable = False
            '    Next i
            'End If

            'If pViCols.ToString.Trim.Length > 0 Then
            '    viCols = Split(pViCols, ",")
            '    For i = LBound(viCols) To UBound(viCols)
            '        oGrid.Columns.Item(viCols(i)).Visible = False
            '    Next i
            'End If

            'If pAffCols.ToString.Trim.Length > 0 Then
            '    affCols = Split(pAffCols, ",")
            '    For i = LBound(affCols) To UBound(affCols)
            '        oGrid.Columns.Item(affCols(i)).AffectsFormMode = False
            '    Next i
            'End If

            'If pAlignCols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pAlignCols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).RightJustified = True
            '    Next i
            'End If

            oGrid.AutoResizeColumns()

            SetGridTitle = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("SetGridTitle " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            cols = Nothing
            colNms = Nothing
            affCols = Nothing
            edCols = Nothing
            viCols = Nothing
            alignCols = Nothing

        End Try

    End Function



    '****************************************************************************************************
    '   함수명      :   BindGridData
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   그리드셋팅

    '   인수        :   
    '****************************************************************************************************
    Public Function BindGridData(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As String, ByVal pColNms As String, Optional ByVal pEdCols As String = "", Optional ByVal pViCols As String = "", _
                                 Optional ByVal strColQty As String = "", Optional ByVal strColAmt As String = "", Optional ByVal strColPrc As String = "", Optional ByVal strColRate As String = "", _
                                 Optional ByVal strColPercent As String = "") As Boolean

        BindGridData = False

        Dim cols() As String
        Dim colNms() As String
        Dim edCols As ArrayList = New ArrayList()
        Dim viCols As ArrayList = New ArrayList()
        Dim pAlignCols As ArrayList = New ArrayList()

        Dim i As Integer

        Try

            '숫자컬럼에 대한처리.
            SetGrdColumnNumber(oGrid, strColQty, strColAmt, strColPrc, strColRate, strColPercent)

            cols = Split(pCols, ",")
            colNms = Split(pColNms, ",")

            If (UBound(cols) - LBound(cols) <> UBound(colNms) - LBound(colNms)) Then
                Exit Function
            End If

            If pEdCols.ToString.Trim.Length > 0 Then edCols.AddRange(Split(pEdCols.Replace(" ", ""), ","))

            If pViCols.ToString.Trim.Length > 0 Then viCols.AddRange(Split(pViCols.Replace(" ", ""), ","))

            pAlignCols.AddRange(Split((strColQty & "," & strColAmt & "," & strColPrc & "," & strColRate & "," & strColPercent).Replace(" ", ""), ","))

            For i = LBound(cols) To UBound(cols)
                oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)))

                If edCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Editable = False
                End If

                If viCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Visible = False
                End If

                If pAlignCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = True
                End If

            Next i

            BindGridData = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("BindGrid " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            cols = Nothing
            colNms = Nothing
            edCols = Nothing
            viCols = Nothing

        End Try

    End Function


    ''****************************************************************************************************
    ''   함수명      :   BindGrid
    ''   작성자      :   
    ''   작성일      :   
    ''   간략한 설명 :   그리드셋팅

    ''   인수        :   
    ''****************************************************************************************************
    'Public Function BindGrid(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As String, ByVal pColNms As String, ByVal moduleini As ModuleIni, Optional ByVal pEdCols As String = "", Optional ByVal pViCols As String = "", Optional ByVal pAffCols As String = "", Optional ByVal pAlignCols As String = "" _
    '                        , Optional ByVal pColor1Cols As String = "", Optional ByVal pcolor2Cols As String = "") As Boolean
    '    BindGrid = False

    '    Dim cols() As String
    '    Dim colNms() As String
    '    Dim affCols() As String
    '    Dim edCols() As String
    '    Dim viCols() As String
    '    Dim alignCols() As String
    '    Dim i As Integer

    '    Try

    '        cols = Split(pCols, ",")
    '        colNms = Split(pColNms, ",")

    '        If (UBound(cols) - LBound(cols) <> UBound(colNms) - LBound(colNms)) Then
    '            Exit Function
    '        End If


    '        For i = LBound(cols) To UBound(cols)
    '            oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)), moduleini)
    '        Next i

    '        If pEdCols.ToString.Trim.Length > 0 Then
    '            edCols = Split(pEdCols, ",")
    '            For i = LBound(edCols) To UBound(edCols)
    '                oGrid.Columns.Item(edCols(i)).Editable = False
    '            Next i
    '        End If

    '        If pViCols.ToString.Trim.Length > 0 Then
    '            viCols = Split(pViCols, ",")
    '            For i = LBound(viCols) To UBound(viCols)
    '                oGrid.Columns.Item(viCols(i)).Visible = False
    '            Next i
    '        End If

    '        If pAffCols.ToString.Trim.Length > 0 Then
    '            affCols = Split(pAffCols, ",")
    '            For i = LBound(affCols) To UBound(affCols)
    '                oGrid.Columns.Item(affCols(i)).AffectsFormMode = False
    '            Next i
    '        End If

    '        If pAlignCols.ToString.Trim.Length > 0 Then
    '            alignCols = Split(pAlignCols, ",")
    '            For i = LBound(alignCols) To UBound(alignCols)
    '                oGrid.Columns.Item(alignCols(i)).RightJustified = True
    '            Next i
    '        End If


    '        If pColor1Cols.ToString.Trim.Length > 0 Then
    '            alignCols = Split(pColor1Cols, ",")
    '            For i = LBound(alignCols) To UBound(alignCols)
    '                oGrid.Columns.Item(alignCols(i)).BackColor = 12777465
    '            Next i
    '        End If

    '        If pcolor2Cols.ToString.Trim.Length > 0 Then
    '            alignCols = Split(pcolor2Cols, ",")
    '            For i = LBound(alignCols) To UBound(alignCols)
    '                oGrid.Columns.Item(alignCols(i)).BackColor = 13624308
    '            Next i
    '        End If

    '        BindGrid = True

    '        For i = 0 To oGrid.Columns.Count - 1
    '            oGrid.Columns.Item(i).TitleObject.Sortable = True
    '        Next

    '    Catch ex As Exception

    '        B1Connections.theAppl.StatusBar.SetText("BindGrid " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

    '    Finally

    '        cols = Nothing
    '        colNms = Nothing
    '        affCols = Nothing
    '        edCols = Nothing
    '        viCols = Nothing
    '        alignCols = Nothing

    '    End Try

    'End Function


    '****************************************************************************************************
    '   함수명      :   BindGrid
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   그리드셋팅

    '   인수        :   
    '****************************************************************************************************
    Public Function BindGrid(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As String, ByVal pColNms As String, Optional ByVal pEdCols As String = "", _
                             Optional ByVal pViCols As String = "", Optional ByVal pAffCols As String = "", Optional ByVal pAlignCols As String = "", _
                             Optional ByVal pColor1Cols As String = "", Optional ByVal pColor2Cols As String = "") As Boolean
        BindGrid = False

        Dim cols() As String
        Dim colNms() As String
        'Dim affCols() As String
        'Dim edCols() As String
        'Dim viCols() As String
        'Dim alignCols() As String
        Dim affCols As ArrayList = New ArrayList()
        Dim edCols As ArrayList = New ArrayList()
        Dim viCols As ArrayList = New ArrayList()
        Dim alignCols As ArrayList = New ArrayList()
        Dim Color1Cols As ArrayList = New ArrayList()
        Dim Color2Cols As ArrayList = New ArrayList()
        Dim i As Integer

        Try

            cols = Split(pCols, ",")
            colNms = Split(pColNms, ",")

            If (UBound(cols) - LBound(cols) <> UBound(colNms) - LBound(colNms)) Then
                Exit Function
            End If

            If pEdCols.ToString.Trim.Length > 0 Then edCols.AddRange(Split(pEdCols.Replace(" ", ""), ","))

            If pViCols.ToString.Trim.Length > 0 Then viCols.AddRange(Split(pViCols.Replace(" ", ""), ","))

            If pAffCols.ToString.Trim.Length > 0 Then affCols.AddRange(Split(pAffCols.Replace(" ", ""), ","))

            If pAlignCols.ToString.Trim.Length > 0 Then alignCols.AddRange(Split(pAlignCols.Replace(" ", ""), ","))

            If pColor1Cols.ToString.Trim.Length > 0 Then Color1Cols.AddRange(Split(pColor1Cols.Replace(" ", ""), ","))

            If pColor2Cols.ToString.Trim.Length > 0 Then Color2Cols.AddRange(Split(pColor2Cols.Replace(" ", ""), ","))

            For i = LBound(cols) To UBound(cols)

                oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)))

                If edCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Editable = False
                End If

                If viCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Visible = False
                End If

                If affCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = False
                End If

                If alignCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = True
                End If

                If Color1Cols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).BackColor = 12777465
                End If

                If Color2Cols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).BackColor = 13624308
                End If

            Next i

            'For i = LBound(cols) To UBound(cols)
            '    If Trim(cols(i).ToString) <> "" Then oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)), ModuleIni.CO)
            'Next i

            'If pEdCols.ToString.Trim.Length > 0 Then
            '    edCols = Split(pEdCols, ",")
            '    For i = LBound(edCols) To UBound(edCols)
            '        If Trim(edCols(i).ToString) <> "" Then oGrid.Columns.Item(edCols(i)).Editable = False
            '    Next i
            'End If

            'If pViCols.ToString.Trim.Length > 0 Then
            '    viCols = Split(pViCols, ",")
            '    For i = LBound(viCols) To UBound(viCols)
            '        If Trim(viCols(i).ToString) <> "" Then oGrid.Columns.Item(viCols(i)).Visible = False
            '    Next i
            'End If

            'If pAffCols.ToString.Trim.Length > 0 Then
            '    affCols = Split(pAffCols, ",")
            '    For i = LBound(affCols) To UBound(affCols)
            '        If Trim(affCols(i).ToString) <> "" Then oGrid.Columns.Item(affCols(i)).AffectsFormMode = False
            '    Next i
            'End If

            'If pAlignCols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pAlignCols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        If Trim(alignCols(i).ToString) <> "" Then oGrid.Columns.Item(alignCols(i)).RightJustified = True
            '    Next i
            'End If

            'If pColor1Cols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pColor1Cols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        If Trim(alignCols(i).ToString) <> "" Then oGrid.Columns.Item(alignCols(i)).BackColor = 12777465
            '    Next i
            'End If

            'If pColor2Cols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pColor2Cols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        If Trim(alignCols(i).ToString) <> "" Then oGrid.Columns.Item(alignCols(i)).BackColor = 13624308
            '    Next i
            'End If

            BindGrid = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("BindGrid " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            cols = Nothing
            colNms = Nothing
            affCols = Nothing
            edCols = Nothing
            viCols = Nothing
            alignCols = Nothing

        End Try

    End Function


    '****************************************************************************************************
    '   함수명      :   BindGrid
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   그리드셋팅

    '   인수        :   
    '****************************************************************************************************   
    Public Function BindGrid(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As String, ByVal pColNms As String, ByVal moduleini As ModuleIni, _
                             Optional ByVal pEdCols As String = "", Optional ByVal pViCols As String = "", Optional ByVal pAffCols As String = "", _
                             Optional ByVal pAlignCols As String = "") As Boolean
        BindGrid = False

        Dim cols() As String
        Dim colNms() As String
        'Dim affCols() As String
        'Dim edCols() As String
        'Dim viCols() As String
        'Dim alignCols() As String
        Dim affCols As ArrayList = New ArrayList()
        Dim edCols As ArrayList = New ArrayList()
        Dim viCols As ArrayList = New ArrayList()
        Dim alignCols As ArrayList = New ArrayList()
        Dim i As Integer

        Try

            cols = Split(pCols, ",")
            colNms = Split(pColNms, ",")

            If (UBound(cols) - LBound(cols) <> UBound(colNms) - LBound(colNms)) Then
                Exit Function
            End If

            If pEdCols.ToString.Trim.Length > 0 Then edCols.AddRange(Split(pEdCols.Replace(" ", ""), ","))

            If pViCols.ToString.Trim.Length > 0 Then viCols.AddRange(Split(pViCols.Replace(" ", ""), ","))

            If pAffCols.ToString.Trim.Length > 0 Then affCols.AddRange(Split(pAffCols.Replace(" ", ""), ","))

            If pAlignCols.ToString.Trim.Length > 0 Then alignCols.AddRange(Split(pAlignCols.Replace(" ", ""), ","))

            For i = LBound(cols) To UBound(cols)

                oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)), moduleini)
                oGrid.Columns.Item(i).TitleObject.Sortable = True

                If edCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Editable = False
                End If

                If viCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).Visible = False
                End If

                If affCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = False
                End If

                If alignCols.Contains(Trim(cols(i))) Then
                    oGrid.Columns.Item(Trim(cols(i))).RightJustified = True
                End If

            Next i

            'For i = LBound(cols) To UBound(cols)
            '    oGrid.Columns.Item(Trim(cols(i))).TitleObject.Caption = CFL.GetCaption(Trim(colNms(i)), moduleini)
            'Next i

            'If pEdCols.ToString.Trim.Length > 0 Then
            '    edCols = Split(pEdCols, ",")
            '    For i = LBound(edCols) To UBound(edCols)
            '        oGrid.Columns.Item(edCols(i)).Editable = False
            '    Next i
            'End If

            'If pViCols.ToString.Trim.Length > 0 Then
            '    viCols = Split(pViCols, ",")
            '    For i = LBound(viCols) To UBound(viCols)
            '        oGrid.Columns.Item(viCols(i)).Visible = False
            '    Next i
            'End If

            'If pAffCols.ToString.Trim.Length > 0 Then
            '    affCols = Split(pAffCols, ",")
            '    For i = LBound(affCols) To UBound(affCols)
            '        oGrid.Columns.Item(affCols(i)).AffectsFormMode = False
            '    Next i
            'End If

            'If pAlignCols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pAlignCols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).RightJustified = True
            '    Next i
            'End If

            BindGrid = True

            'For i = 0 To oGrid.Columns.Count - 1
            '    oGrid.Columns.Item(i).TitleObject.Sortable = True
            'Next

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("BindGrid " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            cols = Nothing
            colNms = Nothing
            affCols = Nothing
            edCols = Nothing
            viCols = Nothing
            alignCols = Nothing

        End Try

    End Function


    ''' <summary>
    ''' GetQD
    ''' </summary>
    ''' <param name="strVal"></param>
    ''' <param name="strDefaultVal"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetQD(ByVal strVal As String, ByVal strDefaultVal As String) As String

        If strVal.Trim = "" Then
            GetQD = strDefaultVal
        Else
            GetQD = "N'" & strVal.Replace("'", "''").Trim & "'"
        End If

    End Function


    ''' <summary>
    ''' GetNextDocEntry
    ''' </summary>
    ''' <param name="strTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetNextDocEntry(ByVal strTable As String) As String
        Dim strTemp As String = ""

        Try

            strTable = strTable.Replace("@", "").Replace("""", "").Replace("[", "").Replace("]", "")
            strTemp = CFL.GetValue(" SELECT  ""U_" & strTable & "_S"".NEXTVAL FROM DUMMY ").ToString()

        Catch ex As Exception
            strTemp = ""
        End Try

        Return strTemp
    End Function


    ''' <summary>
    ''' GetMaxCode
    ''' </summary>
    ''' <param name="strTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMaxCode(Optional ByVal strTable As String = "") As String
        Dim strTemp As String = ""

        Try

            If strTable = "" Then

                strTemp = CFL.GetValue("SELECT REPLACE(REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(50), GETDATE(), 25), '-', ''), ':', ''), '.', ''), ' ', '')")

            Else

                strTable = "[@" & strTable.Replace("@", "").Replace("""", "").Replace("[", "").Replace("]", "") & "]"

                strTemp = "00000000000000000000" + (Integer.Parse(CFL.GetValue("SELECT ISNULL((SELECT MAX(CONVERT(INT,Code)) FROM " & strTable & "), 0 )")) + 1).ToString()
                strTemp = strTemp.Substring(strTemp.Length - 20, 20)
                'strTemp = CFL.GetMaxCode(strTable)

            End If

        Catch ex As Exception
            strTemp = ""
        End Try

        Return strTemp
    End Function


    ''' <summary>
    ''' GetMaxLineId 
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>LineId MAX값 가지고 온다.</remarks>
    ''' 
    Public Function GetMaxLineId(ByVal DbSrc As SAPbouiCOM.DBDataSource) As Integer
        Dim intMaxLineId As Integer = 0, iLooper As Integer = 0

        Try
            If DbSrc.Size > 0 Then
                For iLooper = 0 To DbSrc.Size - 1
                    If Val(DbSrc.GetValue("LineId", iLooper)) > intMaxLineId Then
                        intMaxLineId = Val(DbSrc.GetValue("LineId", iLooper))
                    End If
                Next
            End If
        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetMaxLineId Error : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
        Return intMaxLineId
    End Function

    ''' <summary>
    ''' 크리스탈 리포트 팝업
    ''' </summary>
    ''' <param name="rpt"></param>
    ''' <remarks></remarks>
    Public Sub RptShow(ByRef rpt As WJS.COMM.Report)

        Dim strStartPath As String = System.Reflection.Assembly.GetExecutingAssembly.Location
        Dim strReportPath As String
        Dim strExportPath As String
        Dim strViewerExe As String = "\CrystalViewer.exe"
        Dim proc As Process

        Try
            strStartPath = strStartPath.Substring(0, strStartPath.LastIndexOf("\"))

            'Try
            '    If System.Environment.Is64BitProcess = True Then strViewerExe = "\CrystalViewer_x64.exe"
            'Catch ex As Exception
            '    strViewerExe = "\CrystalViewer.exe"
            'End Try

            If (System.IO.File.Exists(strStartPath + strViewerExe)) Then

                strReportPath = rpt.crxReport.FileName

                'My.Computer.FileSystem.SpecialDirectories.Temp

                strExportPath = My.Computer.FileSystem.SpecialDirectories.Temp + strReportPath.Substring(strReportPath.LastIndexOf("\"), strReportPath.Length - strReportPath.LastIndexOf("\"))

                rpt.crxReport.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.CrystalReport, strExportPath)

                proc = New System.Diagnostics.Process
                proc.StartInfo.FileName = strStartPath + strViewerExe
                proc.StartInfo.Arguments = " """ & strExportPath & """"
                proc.Start()

            Else
                'Report Viewer 실행
                rpt.ShowDialog(CFL.GetSBOWindow())
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("RptShow Error : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            proc = Nothing

            If IsNothing(rpt) = False Then
                rpt.crxReport.Close()
                rpt.crxReport.Dispose()
                rpt.Close()
                rpt.Dispose()
                rpt = Nothing
                GC.Collect()
            End If

        End Try

    End Sub


    ''' <summary>
    ''' GridCheckAll
    ''' </summary>
    ''' <param name="oGrid"></param>
    ''' <param name="strColumnID"></param>
    ''' <remarks></remarks>
    Public Sub GridCheckAll(ByRef oGrid As SAPbouiCOM.Grid, ByVal strColumnID As String)
        Dim i As Integer = 0
        Dim boolSelected As Boolean = False

        For i = 0 To oGrid.Rows.Count - 1
            If i = 0 Then
                If oGrid.DataTable.GetValue(strColumnID, 0) = "Y" Then
                    boolSelected = True
                Else
                    boolSelected = False
                End If
            End If
            If boolSelected Then
                oGrid.DataTable.SetValue(strColumnID, i, "N")
            Else
                oGrid.DataTable.SetValue(strColumnID, i, "Y")
            End If
        Next
    End Sub


    ''' <summary>
    ''' 전표번호 채번로직
    ''' </summary>
    ''' <param name="strPLANT">공장</param>
    ''' <param name="strNumGroup">채번그룹오브잭트(공통코드정의)</param>
    ''' <param name="strRegDt">채번일자</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMaxNum(ByVal strPLANT As String, ByVal strNumGroup As String, ByVal strRegDt As String) As String
        GetMaxNum = ""

        Dim strReturnNum As String = ""

        Try

            '추가문서번호 채번로직 호출
            strReturnNum = CFL.GetValue("EXEC [WJS_SP_MAXNUM] '" + strNumGroup + "','" + strPLANT + "','" + strRegDt + "'")
            GetMaxNum = strReturnNum

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

        Return GetMaxNum

    End Function


    ''' <summary>
    ''' 전표번호 채번로직
    ''' </summary>
    ''' <param name="strPLANT">공장</param>
    ''' <param name="strNumGroup">채번그룹오브잭트(공통코드정의)</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMaxNum(ByVal strPLANT As String, ByVal strNumGroup As String) As String
        GetMaxNum = ""

        Dim strRegDt As String = ""
        Dim strReturnNum As String = ""

        Try

            '추가문서번호 채번로직 호출
            strRegDt = CFL.GetValue("SELECT CONVERT(NVARCHAR(10), GETDATE(), 112) AS DT")
            strReturnNum = CFL.GetValue("EXEC [WJS_SP_MAXNUM] '" + strNumGroup + "','" + strPLANT + "','" + strRegDt + "'")

            GetMaxNum = strReturnNum

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

        Return GetMaxNum

    End Function


    ''' <summary>
    ''' 전표번호 채번로직
    ''' </summary>
    ''' <param name="strNumGroup">채번그룹오브잭트(공통코드정의)</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetMaxNum(ByVal strNumGroup As String) As String
        GetMaxNum = ""

        Dim strRegDt As String = ""
        Dim strReturnNum As String = ""

        Try

            strRegDt = CFL.GetValue("SELECT CONVERT(NVARCHAR(10),GETDATE(),112) AS DT")
            strReturnNum = CFL.GetValue("EXEC [WJS_SP_MAXNUM] '" + strNumGroup + "','','" + strRegDt + "'")

            GetMaxNum = strReturnNum

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

        Return GetMaxNum

    End Function


    ''' <summary>
    ''' GetTODAY
    ''' </summary>
    ''' <param name="oDBDataH"></param>
    ''' <param name="DBField"></param>
    ''' <remarks></remarks>
    Public Sub GetTODAY(ByVal oDBDataH As SAPbouiCOM.DBDataSource, ByVal DBField As String)

        Dim dtInfo As System.Globalization.DateTimeFormatInfo = New System.Globalization.CultureInfo(System.Globalization.CultureInfo.CurrentCulture.ToString(), False).DateTimeFormat
        Try

            'oDBDataH.SetValue("U_DOCDT", 0, Left(Date.Parse(CFL.GetSystemDate).ToString(dtInfo.ShortDatePattern).Replace(dtInfo.DateSeparator, ""), 8)) '& "01")
            'oDBDataH.SetValue("U_TAXDT", 0, Left(Date.Parse(CFL.GetSystemDate).ToString(dtInfo.ShortDatePattern).Replace(dtInfo.DateSeparator, ""), 8)) '& "01")
            'oDBDataH.SetValue("U_DUEDT", 0, Left(Date.Parse(CFL.GetSystemDate).ToString(dtInfo.ShortDatePattern).Replace(dtInfo.DateSeparator, ""), 8)) '& "01")

            oDBDataH.SetValue(DBField, 0, Left(Date.Parse(CFL.GetSystemDate).ToString(dtInfo.ShortDatePattern).Replace(dtInfo.DateSeparator, ""), 8)) '& "01")

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("GetTODAY Error : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            dtInfo = Nothing
        End Try
    End Sub


    ''' <summary>
    ''' GetDateStringYMD
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetDateStringYMD(ByVal dt As Object) As String

        Try
            Dim strDate As String = ""

            If (dt Is Nothing) Then

            ElseIf dt.GetType().Name = "String" Then
                If IsDate(dt) Then
                    strDate = DateTime.Parse(CDate(dt)).ToString("yyyyMMdd")
                Else
                    strDate = dt
                End If
            ElseIf dt.GetType().Name = "DateTime" Then
                strDate = DateTime.Parse(dt).ToString("yyyyMMdd")
            End If

            Return strDate

        Catch ex As Exception
            Return ""
        End Try



    End Function


    ''' <summary>
    ''' GetDateStringYMD
    ''' </summary>
    ''' <param name="strDt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetDateStringYMD(ByVal strDt As String) As String

        Try
            Dim strDate As String = ""

            If strDt.GetType().Name = "String" Then
                If IsDate(strDt) Then
                    strDate = DateTime.Parse(CDate(strDt)).ToString("yyyyMMdd")
                Else
                    strDate = strDt
                End If

            End If

            Return strDate

        Catch ex As Exception
            Return ""
        End Try



    End Function


    ''' <summary>
    ''' GetNowDateString
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetNowDateString() As String

        Dim dt As DateTime = DateTime.Now

        Dim strYear As String = dt.Year.ToString()
        Dim strMonth As String = dt.Month.ToString()
        Dim strDate As String = dt.Day.ToString()

        If (strMonth.Length = 1) Then
            strMonth = "0" + strMonth
        End If

        If (strDate.Length = 1) Then
            strDate = "0" + strDate
        End If

        Return strYear + strMonth + strDate

    End Function


    ''' <summary>
    ''' 영업사원 정보
    ''' </summary>
    ''' <param name="strSalesCode"></param>
    ''' <param name="refDeptCd"></param>
    ''' <param name="refDeptNm"></param>
    ''' <param name="refEmpCd"></param>
    ''' <param name="refEmpNm"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSalesManInfo(ByVal strSalesCode As String, ByRef refDeptCd As String, ByRef refDeptNm As String, ByRef refEmpCd As String, ByRef refEmpNm As String) As String
        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String

        Try

            refDeptCd = ""
            refDeptNm = ""
            refEmpCd = ""
            refEmpNm = ""

            xSQL = ""
            xSQL = xSQL & vbCrLf & " SELECT T2.U_DEPTCD "
            xSQL = xSQL & vbCrLf & "       ,T2.U_DEPTNM "
            xSQL = xSQL & vbCrLf & " 	   ,T1.U_EMPNO "
            xSQL = xSQL & vbCrLf & " 	   ,T1.U_EMPNM "
            xSQL = xSQL & vbCrLf & " FROM       [@WJS_SHR11M] T1 "
            xSQL = xSQL & vbCrLf & " INNER JOIN [@WJS_SHR112] T2 ON T1.Code = T2.Code AND ISNULL(T2.U_IDEPTYN, 'N') = 'Y' "
            xSQL = xSQL & vbCrLf & " WHERE T1.U_SALEMAN = " & strSalesCode

            oRS.DoQuery(xSQL)

            If Not oRS.EoF Then
                refDeptCd = oRS.Fields.Item("U_DEPTCD").Value
                refDeptNm = oRS.Fields.Item("U_DEPTNM").Value
                refEmpCd = oRS.Fields.Item("U_EMPNO").Value
                refEmpNm = oRS.Fields.Item("U_EMPNM").Value
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetSalesManInfo " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return strSalesCode
    End Function


    ''' <summary>
    ''' Mode_Change
    ''' </summary>
    ''' <param name="Gubun"></param>
    ''' <param name="oForm"></param>
    ''' <remarks></remarks>
    Public Sub Mode_Change(ByVal Gubun As String, ByVal oForm As SAPbouiCOM.Form)

        Try
            Select Case Gubun
                Case "1282", "1287" ''추가  '복제
                    oForm.EnableMenu("1287", False) '복제
                    oForm.EnableMenu("1292", True) '행추가
                    oForm.EnableMenu("1293", True) '행삭제
                    oForm.EnableMenu("1281", True) '찾기
                    oForm.EnableMenu("1283", False) '제거
                    oForm.EnableMenu("1282", False) '추가
                Case "1281" ''찾기
                    oForm.EnableMenu("1287", False) '복제
                    oForm.EnableMenu("1292", False) '행추가
                    oForm.EnableMenu("1293", False) '행삭제
                    oForm.EnableMenu("1282", True) '추가
                    oForm.EnableMenu("1283", False) '제거
                    oForm.EnableMenu("1281", False) '찾기
                Case Else
                    oForm.EnableMenu("1287", True) '복제
                    oForm.EnableMenu("1292", True) '행추가
                    oForm.EnableMenu("1293", True) '행삭제
                    oForm.EnableMenu("1282", True) '추가
                    oForm.EnableMenu("1281", True) '찾기
                    oForm.EnableMenu("1283", True) '제거
            End Select


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("Mode Change Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
        Finally

        End Try

    End Sub


    ''' <summary>
    ''' RemoveLastSplit
    ''' </summary>
    ''' <param name="str"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RemoveLastSplit(ByRef str As String) As String

        Try

            If str.Length > 0 Then
                str = str.Substring(0, str.Length - 1)
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

        Return str
    End Function

    Public Sub SetGrdColumnNumber(ByRef oGrid As SAPbouiCOM.Grid, ByVal strColQty As String, ByVal strColAmt As String, ByVal strColPrc As String, ByVal strColRate As String)

        Dim xMLDoc As Xml.XmlDocument = New Xml.XmlDocument()
        xMLDoc.LoadXml(oGrid.DataTable.SerializeAsXML(BoDataTableXmlSelect.dxs_All))
        Dim arrColQty As ArrayList = New ArrayList()
        If (Not strColQty Is Nothing) Then arrColQty.AddRange(strColQty.Replace(" ", "").Split(",")) '수량
        Dim arrColAmt As ArrayList = New ArrayList()
        If (Not strColAmt Is Nothing) Then arrColAmt.AddRange(strColAmt.Replace(" ", "").Split(",")) '금액
        Dim arrColPrc As ArrayList = New ArrayList()
        If (Not strColPrc Is Nothing) Then arrColPrc.AddRange(strColPrc.Replace(" ", "").Split(",")) '단가
        Dim arrColRate As ArrayList = New ArrayList()
        If (Not strColRate Is Nothing) Then arrColRate.AddRange(strColRate.Replace(" ", "").Split(",")) '비율


        For Each node As XmlNode In xMLDoc.GetElementsByTagName("Column")
            If (arrColQty.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Quantity
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColAmt.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Sum
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColPrc.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Price
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColRate.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Rate
                node.Attributes("MaxLength").InnerText = "0"
            End If

        Next
        oGrid.DataTable.LoadSerializedXML(BoDataTableXmlSelect.dxs_All, xMLDoc.InnerXml)

        If (ExistsColGrid(oGrid, "RowsHeader")) Then
            oGrid.Columns.Item("RowsHeader").Width = 20
        End If

        xMLDoc = Nothing

    End Sub


    ''' <summary>
    ''' Custom 화면에서 Serial/Batch 관리를 하기위한 임시테이블 추가
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <remarks></remarks>
    Public Sub CreateTempSNTB(ByRef oForm As SAPbouiCOM.Form)

        'OITL 임시 테이블 추가
        Dim oDT As SAPbouiCOM.DataTable

        'ITL1 임시 테이블 추가
        oDT = oForm.DataSources.DataTables.Add("ITL1")
        oDT.Columns.Add("ManagedBy", BoFieldsType.ft_Integer)
        oDT.Columns.Add("LogEntry", BoFieldsType.ft_Integer)
        oDT.Columns.Add("ItemCode", BoFieldsType.ft_AlphaNumeric, 20)
        oDT.Columns.Add("SysNumber", BoFieldsType.ft_Integer)
        oDT.Columns.Add("Quantity", BoFieldsType.ft_Quantity)
        oDT.Columns.Add("DocEntry", BoFieldsType.ft_Integer)
        oDT.Columns.Add("DocLine", BoFieldsType.ft_Integer)
        oDT.Columns.Add("DocType", BoFieldsType.ft_Integer)

    End Sub


    ''' <summary>
    ''' 일련번호 생성을 위한 템프 테이블
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <remarks></remarks>
    Public Sub CreateTempOSRN(ByRef oForm As SAPbouiCOM.Form)

        'OSRN 임시 테이블 추가
        Dim oDT As SAPbouiCOM.DataTable
        oDT = oForm.DataSources.DataTables.Add("OSRN")

        oDT.Columns.Add("DocLine", BoFieldsType.ft_AlphaNumeric, 20)    '전표라인번호
        oDT.Columns.Add("ItemCode", BoFieldsType.ft_AlphaNumeric, 20)   '품목 번호
        oDT.Columns.Add("SysNumber", BoFieldsType.ft_AlphaNumeric, 11)  '시스템 번호
        oDT.Columns.Add("DistNumber", BoFieldsType.ft_AlphaNumeric, 32) '일련번호
        oDT.Columns.Add("MnfSerial", BoFieldsType.ft_AlphaNumeric, 32)  '제조업체 일련번호
        oDT.Columns.Add("LotNumber", BoFieldsType.ft_AlphaNumeric, 32)  '로트 번호
        oDT.Columns.Add("ExpDate", BoFieldsType.ft_Date, 8)             '만료일
        oDT.Columns.Add("MnfDate", BoFieldsType.ft_Date, 8)             '제조일
        oDT.Columns.Add("InDate", BoFieldsType.ft_Date, 8)              '입력일
        oDT.Columns.Add("GrntStart", BoFieldsType.ft_Date, 8)           '제조업체 보증 시작일
        oDT.Columns.Add("GrntExp", BoFieldsType.ft_Date, 8)             '제조업체 보증 종료일
        oDT.Columns.Add("CreateDate", BoFieldsType.ft_Date, 8)          '생성일
        oDT.Columns.Add("Location", BoFieldsType.ft_AlphaNumeric, 100)  '위치
        oDT.Columns.Add("Status", BoFieldsType.ft_AlphaNumeric, 1)      '상태
        oDT.Columns.Add("Notes", BoFieldsType.ft_Text, 64000)           '세부사항
        oDT.Columns.Add("DataSource", BoFieldsType.ft_AlphaNumeric, 1)  '데이터 소스
        oDT.Columns.Add("UserSign", BoFieldsType.ft_AlphaNumeric, 6)    '사용자 서명
        oDT.Columns.Add("Transfered", BoFieldsType.ft_AlphaNumeric, 1)  '전송
        oDT.Columns.Add("Instance", BoFieldsType.ft_AlphaNumeric, 6)    '인스턴스
        oDT.Columns.Add("AbsEntry", BoFieldsType.ft_AlphaNumeric, 11)   'abs entry
        oDT.Columns.Add("ObjType", BoFieldsType.ft_AlphaNumeric, 20)    'object type
        oDT.Columns.Add("itemName", BoFieldsType.ft_AlphaNumeric, 100)  '품목 내역
        oDT.Columns.Add("U_VARIANT", BoFieldsType.ft_AlphaNumeric, 20)  '가변품목번호
        oDT.Columns.Add("KeyCode", BoFieldsType.ft_AlphaNumeric, 1000)  '구분자를 위한 Key값
        oDT.Columns.Add("GBN1", BoFieldsType.ft_AlphaNumeric, 100)      '구분자1
        oDT.Columns.Add("GBN2", BoFieldsType.ft_AlphaNumeric, 100)      '구분자2
        oDT.Columns.Add("GBN3", BoFieldsType.ft_AlphaNumeric, 100)      '구분자3

    End Sub


    ''' <summary>
    ''' 배치품목여부
    ''' </summary>
    ''' <param name="strItemCode"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function bBatchItem(ByVal strItemCode As String) As Boolean

        If CFL.GetValue("SELECT ISNULL(A.ManBtchNum, 'N') FROM OITM A WHERE A.ItemCode = '" & Trim(strItemCode) & "'") = "Y" Then
            Return True
        Else
            Return False
        End If

    End Function


    ''' <summary>
    ''' 배치번호 생성을 위한 템프 테이블
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <remarks></remarks>
    Public Sub CreateTempOBTN(ByRef oForm As SAPbouiCOM.Form)

        'OSRN 임시 테이블 추가
        Dim oDT As SAPbouiCOM.DataTable
        oDT = oForm.DataSources.DataTables.Add("OBTN")

        oDT.Columns.Add("DocLine", BoFieldsType.ft_AlphaNumeric, 20)    '전표라인번호
        oDT.Columns.Add("ItemCode", BoFieldsType.ft_AlphaNumeric, 20)   '품목 번호
        oDT.Columns.Add("SysNumber", BoFieldsType.ft_AlphaNumeric, 11)  '시스템 번호
        oDT.Columns.Add("DistNumber", BoFieldsType.ft_AlphaNumeric, 32) '배치 번호
        oDT.Columns.Add("MnfSerial", BoFieldsType.ft_AlphaNumeric, 32)  '배치 속성 1
        oDT.Columns.Add("LotNumber", BoFieldsType.ft_AlphaNumeric, 32)  '배치 속성 2
        oDT.Columns.Add("ExpDate", BoFieldsType.ft_Date, 8)             '만료일
        oDT.Columns.Add("MnfDate", BoFieldsType.ft_Date, 8)             '제조일
        oDT.Columns.Add("InDate", BoFieldsType.ft_Date, 8)              '입력일
        oDT.Columns.Add("GrntStart", BoFieldsType.ft_Date, 8)           '보증 시작일
        oDT.Columns.Add("GrntExp", BoFieldsType.ft_Date, 8)             '보증 종료일
        oDT.Columns.Add("CreateDate", BoFieldsType.ft_Date, 8)          '생성일
        oDT.Columns.Add("Location", BoFieldsType.ft_AlphaNumeric, 100)  '위치
        oDT.Columns.Add("Status", BoFieldsType.ft_AlphaNumeric, 1)      '상태
        oDT.Columns.Add("Notes", BoFieldsType.ft_Text, 64000)           '세부사항
        oDT.Columns.Add("DataSource", BoFieldsType.ft_AlphaNumeric, 1)  '데이터 소스
        oDT.Columns.Add("UserSign", BoFieldsType.ft_AlphaNumeric, 6)    '사용자 서명
        oDT.Columns.Add("Transfered", BoFieldsType.ft_AlphaNumeric, 1)  '전송
        oDT.Columns.Add("Instance", BoFieldsType.ft_AlphaNumeric, 6)    '인스턴스
        oDT.Columns.Add("AbsEntry", BoFieldsType.ft_AlphaNumeric, 11)   'abs entry
        oDT.Columns.Add("ObjType", BoFieldsType.ft_AlphaNumeric, 20)    'object type
        oDT.Columns.Add("itemName", BoFieldsType.ft_AlphaNumeric, 100)  '품목 내역
        oDT.Columns.Add("U_VARIANT", BoFieldsType.ft_AlphaNumeric, 20)  '가변품목번호
        oDT.Columns.Add("QTY", BoFieldsType.ft_AlphaNumeric, 20)        '수량
        oDT.Columns.Add("KeyCode", BoFieldsType.ft_AlphaNumeric, 1000)  '구분자를 위한 Key값
        oDT.Columns.Add("GBN1", BoFieldsType.ft_AlphaNumeric, 100)      '구분자1
        oDT.Columns.Add("GBN2", BoFieldsType.ft_AlphaNumeric, 100)      '구분자2
        oDT.Columns.Add("GBN3", BoFieldsType.ft_AlphaNumeric, 100)      '구분자3

    End Sub


    ''' <summary>
    ''' Custom 화면에서 Bin 위치 관리를 하기위한 임시테이블 추가
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <remarks></remarks>
    Public Sub CreateTempOBTL(ByRef oForm As SAPbouiCOM.Form)

        'OBTL 임시 테이블 추가
        Dim oDT As SAPbouiCOM.DataTable

        'OBTL 임시 테이블 추가 
        oDT = oForm.DataSources.DataTables.Add("OBTL")
        oDT.Columns.Add("AbsEntry", BoFieldsType.ft_Integer)
        oDT.Columns.Add("ManagedBy", BoFieldsType.ft_Integer)
        oDT.Columns.Add("BinAbs", BoFieldsType.ft_Integer)
        oDT.Columns.Add("BinCode", BoFieldsType.ft_AlphaNumeric, 228)
        oDT.Columns.Add("SnBMDAbs", BoFieldsType.ft_Integer)
        oDT.Columns.Add("Quantity", BoFieldsType.ft_Quantity)
        oDT.Columns.Add("ITLEntry", BoFieldsType.ft_Integer)
        oDT.Columns.Add("DocEntry", BoFieldsType.ft_AlphaNumeric, 100)
        oDT.Columns.Add("DocLine", BoFieldsType.ft_Integer)
        oDT.Columns.Add("DocType", BoFieldsType.ft_Integer)

    End Sub

    ''' <summary>
    ''' 공장권한에 따른 Plant Combo 셋팅
    ''' </summary>
    ''' <param name="strUserId"></param>
    ''' <param name="oCombo"></param>
    ''' <remarks></remarks>
    Public Sub SetPLANTCombo(ByVal strUserId As String, ByRef oCombo As SAPbouiCOM.ComboBox, ByRef DbSrc As SAPbouiCOM.DBDataSource, ByVal strFieldNm As String)
        Dim Rs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String = ""
        xSQL = ""

        xSQL = " select U_PLANT, (select U_PLNM From [@WJS_SAD63M] where U_PLCD = a.U_PLANT) as U_PLANTNM, U_DFTYN "
        xSQL = xSQL & vbCrLf & "  from [@WJS_SAD511] a "
        xSQL = xSQL & vbCrLf & " where U_USERID = " + CFL.GetQD(strUserId)
        xSQL = xSQL & vbCrLf & " and (U_PLANTRL = 'S01' or U_PLANTRL = 'S02') and isnull(U_USEYN,'N') = 'Y'"

        Rs.DoQuery(xSQL)

        Dim i As Integer
        For i = 0 To Rs.RecordCount - 1
            oCombo.ValidValues.Add(Rs.Fields.Item("U_PLANT").Value.ToString.Trim(), Rs.Fields.Item("U_PLANTNM").Value.ToString().Trim())
            Rs.MoveNext()
        Next

        xSQL = " select U_PLANT "
        xSQL = xSQL & vbCrLf & "  from [@WJS_SAD511]  "
        xSQL = xSQL & vbCrLf & " where U_USERID = " + CFL.GetQD(strUserId)
        xSQL = xSQL & vbCrLf & " and (U_PLANTRL = 'S01' or U_PLANTRL = 'S02') and isnull(U_USEYN,'N') = 'Y' and isnull(U_DFTYN,'N') = 'Y' "

        Dim strDfltPlant As String = CFL.GetValue(xSQL)

        If (strDfltPlant <> "") Then
            DbSrc.SetValue(strFieldNm, 0, strDfltPlant)
        End If

    End Sub

    ''' <summary>
    ''' 공장권한에 따른 Plant Combo 셋팅
    ''' </summary>
    ''' <param name="strUserId"></param>
    ''' <param name="oCombo"></param>
    ''' <remarks></remarks>
    Public Sub SetPLANTCombo(ByVal strUserId As String, ByRef oCombo As SAPbouiCOM.ComboBox)
        Dim Rs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String = ""
        xSQL = ""

        xSQL = " select U_PLANT, (select U_PLNM From [@WJS_SAD63M] where U_PLCD = a.U_PLANT) as U_PLANTNM, U_DFTYN "
        xSQL = xSQL & vbCrLf & "  from [@WJS_SAD511] a "
        xSQL = xSQL & vbCrLf & " where U_USERID = " + CFL.GetQD(strUserId)
        xSQL = xSQL & vbCrLf & " and (U_PLANTRL = 'S01' or U_PLANTRL = 'S02') and isnull(U_USEYN,'N') = 'Y'"

        Rs.DoQuery(xSQL)

        Dim i As Integer
        For i = 0 To Rs.RecordCount - 1
            oCombo.ValidValues.Add(Rs.Fields.Item("U_PLANT").Value.ToString.Trim(), Rs.Fields.Item("U_PLANTNM").Value.ToString().Trim())
            Rs.MoveNext()
        Next

        xSQL = " select U_PLANT "
        xSQL = xSQL & vbCrLf & "  from [@WJS_SAD511]  "
        xSQL = xSQL & vbCrLf & " where U_USERID = " + CFL.GetQD(strUserId)
        xSQL = xSQL & vbCrLf & " and (U_PLANTRL = 'S01' or U_PLANTRL = 'S02') and isnull(U_USEYN,'N') = 'Y' and isnull(U_DFTYN,'N') = 'Y' "

        Dim strDfltPlant As String = CFL.GetValue(xSQL)

        If (strDfltPlant <> "") Then
            oCombo.Select(strDfltPlant, BoSearchKey.psk_ByValue)
        End If

    End Sub

    ''' <summary>
    ''' 공장콤보세팅
    ''' </summary>
    ''' <param name="oCombo"></param>
    ''' <remarks></remarks>
    Public Function SetPLANTCombo(ByRef oCombo As SAPbouiCOM.ComboBox, Optional ByVal bDefault As Boolean = True) As String
        Dim rValue As String = ""

        Dim oRS As SAPbobsCOM.Recordset
        Dim i As Integer
        Dim xSQL As String = ""
        Dim strDfltPlant As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            xSQL = ""
            xSQL = xSQL & vbCrLf & " SELECT ISNULL(U_PLCD, '')		AS U_PLCD "
            xSQL = xSQL & vbCrLf & "       ,ISNULL(U_PLNM, '')		AS U_PLNM "
            xSQL = xSQL & vbCrLf & "       ,ISNULL(U_DFLTPLT, N'N')	AS U_DFLTPLT "
            xSQL = xSQL & vbCrLf & " FROM [@WJS_SAD63M] "

#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If

            oRS.DoQuery(xSQL)

            For i = 0 To oRS.RecordCount - 1
                oCombo.ValidValues.Add(oRS.Fields.Item("U_PLCD").Value.ToString.Trim(), oRS.Fields.Item("U_PLNM").Value.ToString().Trim())

                If Trim(oRS.Fields.Item("U_DFLTPLT").Value) = "Y" Then
                    strDfltPlant = Trim(oRS.Fields.Item("U_PLCD").Value)
                    rValue = strDfltPlant
                End If

                oRS.MoveNext()
            Next

            If (oCombo.ValidValues.Count > 0 And bDefault = True) Then

                If (strDfltPlant <> "") Then
                    oCombo.Select(strDfltPlant, BoSearchKey.psk_ByValue)
                End If

            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return rValue
    End Function



    ''' <summary>
    ''' 공장콤보세팅
    ''' </summary>
    ''' <param name="oComboColumn"></param>
    ''' <remarks></remarks>
    Public Function SetPLANTCombo(ByRef oComboColumn As SAPbouiCOM.ComboBoxColumn, Optional ByVal bDefault As Boolean = True) As String
        Dim rValue As String = ""

        Dim oRS As SAPbobsCOM.Recordset
        Dim i As Integer
        Dim xSQL As String = ""
        Dim strDfltPlant As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            xSQL = ""
            xSQL = xSQL & vbCrLf & " SELECT ISNULL(U_PLCD, '')		AS U_PLCD "
            xSQL = xSQL & vbCrLf & "       ,ISNULL(U_PLNM, '')		AS U_PLNM "
            xSQL = xSQL & vbCrLf & "       ,ISNULL(U_DFLTPLT, N'N')	AS U_DFLTPLT "
            xSQL = xSQL & vbCrLf & " FROM [@WJS_SAD63M] "

#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If

            oRS.DoQuery(xSQL)

            For i = 0 To oRS.RecordCount - 1
                oComboColumn.ValidValues.Add(oRS.Fields.Item("U_PLCD").Value.ToString.Trim(), oRS.Fields.Item("U_PLNM").Value.ToString().Trim())

                If Trim(oRS.Fields.Item("U_DFLTPLT").Value) = "Y" Then
                    strDfltPlant = Trim(oRS.Fields.Item("U_PLCD").Value)
                    rValue = strDfltPlant
                End If

                oRS.MoveNext()
            Next

            'If (oComboColumn.ValidValues.Count > 0 And bDefault = True) Then

            '    If (strDfltPlant <> "") Then
            '        oComboColumn.
            '    End If

            'End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return rValue
    End Function




    ''' <summary>
    ''' 통화콤보세팅
    ''' </summary>
    ''' <param name="oComboBox"></param>
    ''' <remarks></remarks>
    Public Function SetCurrencyCombo(ByRef oComboBox As SAPbouiCOM.ComboBox, Optional ByVal bDefault As Boolean = True) As String
        Dim rValue As String = ""

        Dim oRS As SAPbobsCOM.Recordset
        Dim i As Integer
        Dim xSQL As String = ""
        Dim strDfltPlant As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            xSQL = ""
            xSQL = xSQL & vbCrLf & " SELECT     ""CurrCode"" AS CODE	 "
            xSQL = xSQL & vbCrLf & "       ,	""CurrName"" AS NAME "
            xSQL = xSQL & vbCrLf & " FROM OCRN "

#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If

            oRS.DoQuery(xSQL)

            For i = 0 To oRS.RecordCount - 1
                oComboBox.ValidValues.Add(oRS.Fields.Item("CODE").Value.ToString.Trim(), oRS.Fields.Item("NAME").Value.ToString().Trim())
                strDfltPlant = Trim(oRS.Fields.Item("CODE").Value)
                rValue = strDfltPlant
                oRS.MoveNext()
            Next

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return rValue
    End Function




    ''' <summary>
    ''' 세금그룹콤보세팅
    ''' </summary>
    ''' <param name="oComboBox"></param>
    ''' <remarks></remarks>
    Public Function SetVATGCombo(ByRef oComboBox As SAPbouiCOM.ComboBox, Optional ByVal bDefault As Boolean = True) As String
        Dim rValue As String = ""

        Dim oRS As SAPbobsCOM.Recordset
        Dim i As Integer
        Dim xSQL As String = ""
        Dim strDfltPlant As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            xSQL = ""
            xSQL = xSQL & vbCrLf & " SELECT ""Code"" AS CODE	 "
            xSQL = xSQL & vbCrLf & "       ,""Name"" AS NAME "
            xSQL = xSQL & vbCrLf & " FROM OVTG "

#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If

            oRS.DoQuery(xSQL)

            For i = 0 To oRS.RecordCount - 1
                oComboBox.ValidValues.Add(oRS.Fields.Item("CODE").Value.ToString.Trim(), oRS.Fields.Item("NAME").Value.ToString().Trim())
                strDfltPlant = Trim(oRS.Fields.Item("CODE").Value)
                rValue = strDfltPlant
                oRS.MoveNext()
            Next

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return rValue
    End Function


    ''' <summary>
    ''' QDs
    ''' </summary>
    ''' <param name="values"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function QDs(ByVal ParamArray values() As String) As String
        Dim strReturn As String = ""

        For icnt As Integer = 0 To UBound(values)
            If icnt > 0 Then
                strReturn = strReturn + ", "
            End If

            If values(icnt) Is Nothing Then
                strReturn = strReturn + "N''"
            Else
                strReturn = strReturn + "N'" & values(icnt).Replace("'", "''") & "'"
            End If

        Next
        Return strReturn
    End Function


    ''' <summary>
    ''' QDs
    ''' </summary>
    ''' <param name="oUserData"></param>
    ''' <param name="userField"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function QDs(ByVal oUserData As SAPbouiCOM.UserDataSources, ByVal ParamArray userField() As String) As String
        Dim strReturn As String = ""

        For icnt As Integer = 0 To UBound(userField)
            If icnt > 0 Then
                strReturn = strReturn + ", "
            End If

            If userField(icnt) Is Nothing Then
                strReturn = strReturn + "N''"
            Else
                strReturn = strReturn + "N'" & oUserData.Item(userField(icnt)).Value.Replace("'", "''") & "'"
            End If

        Next
        Return strReturn
    End Function


    '*********************************************
    ' Created : 2013.04.15 HMK
    ' Comment : 금액 끝전처리 방법
    ' 
    '*********************************************
    Public Function GetRoundFormat(ByVal RndAmt As Double, ByVal RndRule As String, Optional ByVal UnitRule As Integer = 0) As Double
        '// RndAmt : 끝전처리할 대상금액
        '// RndRule : 반올림규칙 (R=반올림, F=올림, C=버림)
        '// UnitRule : 몇째자리 적용인지여부 (1, 10,100,1000,10000 원)

        '--10원단위(대상금액 * 10원단위)  
        'Select Case ROUND(ROUND((105.0 + (10 * 0.5)) / 10, 0, -1) * 10, 0) - -R반올림
        'SELECT  ROUND(ROUND((105.5 + (10 * 0.9999999)) / 10 ,0,-1) * 10 ,0)  --C올림
        'SELECT  ROUND(ROUND(105.5 /10 ,0,-1) * 10,0)					--F버림

        '--100원단위(대상금액 * 100원단위)  
        'SELECT  ROUND(ROUND((1020.5 + (100 * 0.5)) / 100 ,0,-1) * 100 ,0) --R반올림
        'SELECT  ROUND(ROUND((1020.5 + (100 * 0.9999999)) / 100 ,0,-1) * 100 ,0)  --C올림
        'SELECT  ROUND(ROUND(1020.5 /100 ,0,-1) * 100,0)					--F버림

        '---소숫점자리 1째자리까지
        '        SELECT  ROUND(1498.474,1)
        '        SELECT  ROUND((1498.474 + 0.09)/0.1 ,0,-1) *0.1  --올림
        '        SELECT  ROUND(1498.474 /0.1 ,0,-1) *0.1  --버림

        Dim RoundAmt As Double
        Dim CValue As Double
        Dim DecUnit As Double

        Try
            RoundAmt = Math.Round(RndAmt, 6)

            '// 끝전처리 단위(소숫점자리 없음) 표시단위(10: 10원단위, 100: 100원단위, 1000:1000원단위)
            If UnitRule > 6 Then
                CValue = 0.999999
                Select Case RndRule
                    Case "R"    '/ 반올림
                        RoundAmt = Math.Round(Math.Truncate((RoundAmt + (UnitRule * 0.5)) / UnitRule) * UnitRule, 0)
                    Case "C"    '/ 올림
                        RoundAmt = Math.Round(Math.Truncate((RoundAmt + (UnitRule * CValue)) / UnitRule) * UnitRule, 0)
                    Case "F"    '/ 버림
                        RoundAmt = Math.Round(Math.Truncate(RoundAmt / UnitRule) * UnitRule, 0)
                End Select
            Else
                '// OADM의 금액 소숫점자릿수 표시단위(1: 0.0, 2:0.00, 3:0.000, 4:0.0000, 5:0.00000, 6:0.000000)
                Select Case UnitRule
                    Case 0
                        CValue = 0.9 : DecUnit = 1
                    Case 1
                        CValue = 0.09 : DecUnit = 0.1
                    Case 2
                        CValue = 0.009 : DecUnit = 0.01
                    Case 3
                        CValue = 0.0009 : DecUnit = 0.001
                    Case 4
                        CValue = 0.00009 : DecUnit = 0.0001
                    Case 5
                        CValue = 0.000009 : DecUnit = 0.00001
                    Case 6
                        CValue = 0.0000009 : DecUnit = 0.000001
                End Select
                Select Case RndRule
                    Case "R"    '/ 반올림
                        RoundAmt = Math.Round(RoundAmt, UnitRule)
                    Case "C"    '/ 올림
                        RoundAmt = Math.Truncate((RoundAmt + CValue) / DecUnit) * DecUnit
                    Case "F"    '/ 버림
                        RoundAmt = Math.Truncate(RoundAmt / DecUnit) * DecUnit
                End Select
            End If
            Return RoundAmt
        Catch ex As Exception
            Return RndAmt
        End Try
    End Function


    ''' <summary>
    ''' ReCalTotAmt
    ''' </summary>
    ''' <param name="oMatrix"></param>
    ''' <param name="oDBDataD"></param>
    ''' <param name="oUserData"></param>
    ''' <remarks></remarks>
    Public Sub ReCalTotAmt(ByVal oMatrix As SAPbouiCOM.Matrix, ByVal oDBDataD As SAPbouiCOM.DBDataSource, ByVal oUserData As SAPbouiCOM.UserDataSources)

        ''수량,금액(FC),금액,세액 합계 계산
        Dim i As Integer = 0, dblTotCnt As Double = 0, dblTotMnyFC As Double = 0, dblTotMny As Double = 0, dblTotTax As Double = 0

        Try

            For i = 0 To oDBDataD.Size - 1
                dblTotCnt = dblTotCnt + oDBDataD.GetValue("U_QTY", i)
                dblTotMnyFC = dblTotMnyFC + oDBDataD.GetValue("U_FCAMT", i)
                dblTotMny = dblTotMny + oDBDataD.GetValue("U_AMT", i)
                dblTotTax = dblTotTax + oDBDataD.GetValue("U_VAT", i)

            Next

            oUserData.Item("edtCNT").ValueEx = dblTotCnt
            oUserData.Item("edtMNYFC").ValueEx = dblTotMnyFC
            oUserData.Item("edtMNY").ValueEx = dblTotMny + dblTotTax
            oUserData.Item("edtTAX").ValueEx = dblTotTax

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("FA0196", ModuleIni.FA) & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error) '합계계산도중 에러가 발생하였습니다. 메세지 : 
        End Try
    End Sub


    ''' <summary>
    ''' colValidate
    ''' </summary>
    ''' <param name="pval"></param>
    ''' <param name="cDBDataH"></param>
    ''' <param name="cDBDataD"></param>
    ''' <param name="oMatrix"></param>
    ''' <remarks></remarks>
    Public Sub colValidate(ByVal pval As SAPbouiCOM.ItemEvent, ByVal cDBDataH As SAPbouiCOM.DBDataSource, ByVal cDBDataD As SAPbouiCOM.DBDataSource, ByVal oMatrix As SAPbouiCOM.Matrix)

        ''수량,단가,단가(FC),금액,금액(FC)

        Dim cv_Rate As Double = cDBDataH.GetValue("U_EXRT", 0)
        Dim cForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.Item(pval.FormUID)

        Dim cv_Qty As Double = 0            ''수량
        Dim cv_Prc As Double = 0            ''단가
        Dim cv_FCPrc As Double = 0          ''단가(FC)
        Dim cv_VatRate As Double = 0        ''부가세율
        Dim cv_TaxRndRule As String = "R"     ''세금반올림규칙
        Dim cv_Round As Integer = CDbl(CFL.GetValue("SELECT ISNULL(SUMDEC,0) FROM OADM")) '통화
        Dim cv_RoundFc As Integer = CDbl(CFL.GetValue("SELECT ISNULL(PRICEDEC,0) FROM OADM")) '외화
        Try

            oMatrix.FlushToDataSource()
            'cDBDataD.Offset = pval.Row - 1

            cv_Qty = cDBDataD.GetValue("U_QTY", pval.Row - 1)

            If pval.FormType <> "2104000012" Then
                cv_Prc = cDBDataD.GetValue("U_PRC", pval.Row - 1)
                cv_FCPrc = cDBDataD.GetValue("U_FCPRC", pval.Row - 1)
            End If

            cv_VatRate = CDbl(Val(CFL.GetValue("SELECT Rate FROM OVTG WHERE Code='" & cDBDataD.GetValue("U_VATGRP", pval.Row - 1) & "' ")) / 100)
            cv_TaxRndRule = CFL.GetValue("SELECT TaxRndRule FROM OADM ")

            Select Case pval.ColUID
                Case "colQTY"   '수량* 단가(FC) = 금액(FC) , 수량 *단가 = 금액 ,세액 = 금액 * 부가세율

                    If pval.FormType = "2104000009" Then        ''자산금액 = 수량 * 매각자산단가 , 상각누계액 = 수량 * 상각누계액단가
                        cDBDataD.SetValue("U_SALAMT", pval.Row - 1, CDbl(cv_Qty * cDBDataD.GetValue("U_SALPRC", pval.Row - 1)))
                        cDBDataD.GetValue("U_SDEPAMT", pval.Row - 1)
                        cDBDataD.SetValue("U_SDEPAMT", pval.Row - 1, CDbl(cv_Qty * cDBDataD.GetValue("U_SDEPPRC", pval.Row - 1)))
                        cDBDataD.SetValue("U_FCAMT", pval.Row - 1, Math.Round(CDbl(cv_Qty * cv_FCPrc), cv_RoundFc))
                        cDBDataD.SetValue("U_AMT", pval.Row - 1, Math.Round(CDbl(cv_Prc * cv_Qty), cv_Round))
                        '   cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cv_Prc * cv_Qty * cv_VatRate))
                        cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cv_Prc * cv_Qty * cv_VatRate), cv_TaxRndRule, 0))

                    ElseIf pval.FormType = "2104000012" Then        ''자산금액 = 수량 * 폐기자산단가 , 상각누계액 = 수량 * 상각누계액단가

                        cDBDataD.SetValue("U_DDEPAMT", pval.Row - 1, CDbl(cv_Qty * cDBDataD.GetValue("U_DDEPPRC", pval.Row - 1)))
                        cDBDataD.SetValue("U_DISAMT", pval.Row - 1, CDbl(cv_Qty * cDBDataD.GetValue("U_DISPRC", pval.Row - 1)))

                    Else
                        cDBDataD.SetValue("U_FCAMT", pval.Row - 1, Math.Round(CDbl(cv_Qty * cv_FCPrc), cv_RoundFc))
                        cDBDataD.SetValue("U_AMT", pval.Row - 1, Math.Round(CDbl(cv_Prc * cv_Qty), cv_Round))
                        ' cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cv_Prc * cv_Qty * cv_VatRate))
                        cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cv_Prc * cv_Qty * cv_VatRate), cv_TaxRndRule, 0))
                    End If

                Case "colAMT"
                    'cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cDBDataD.GetValue("U_AMT", pval.Row - 1)) * CDbl(cv_VatRate))
                    cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cDBDataD.GetValue("U_AMT", pval.Row - 1)) * CDbl(cv_VatRate), cv_TaxRndRule, 0))

                Case "colPRC"
                    cDBDataD.SetValue("U_AMT", pval.Row - 1, Math.Round(CDbl(cv_Prc * cv_Qty), cv_Round))
                    ' cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cv_Prc * cv_Qty * cv_VatRate))
                    cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cv_Prc * cv_Qty * cv_VatRate), cv_TaxRndRule, 0))
                Case "colFCPRC" '단가(FC) *수량 = 금액(FC) , 
                    If checkCUR(cDBDataH) Then
                        cDBDataD.SetValue("U_FCAMT", pval.Row - 1, Math.Round(CDbl(cv_Qty * cv_FCPrc), cv_RoundFc))
                        cDBDataD.SetValue("U_PRC", pval.Row - 1, cv_FCPrc * cv_Rate)
                        cDBDataD.SetValue("U_AMT", pval.Row - 1, Math.Round(CDbl(cv_Qty * cv_FCPrc * cv_Rate), cv_Round))
                        ' cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cv_Qty * cv_FCPrc * cv_Rate * cv_VatRate))
                        cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cv_Qty * cv_FCPrc * cv_Rate * cv_VatRate), cv_TaxRndRule, 0))
                    End If

                Case "colFCAMT"
                    If checkCUR(cDBDataH) Then
                        If pval.FormType = "2104000012" Then

                            cDBDataD.SetValue("U_AMT", pval.Row - 1, Math.Round(CDbl(cv_Rate * cDBDataD.GetValue("U_FCAMT", pval.Row - 1)), cv_Round))
                            'cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cv_VatRate * cv_Rate * cDBDataD.GetValue("U_FCAMT", pval.Row - 1)))
                            cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cv_VatRate * cv_Rate * cDBDataD.GetValue("U_FCAMT", pval.Row - 1)), cv_TaxRndRule, 0))
                        Else
                            cDBDataD.SetValue("U_AMT", pval.Row - 1, Math.Round(CDbl(cv_Qty * cv_FCPrc * cv_Rate), cv_Round))
                            ' cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cv_Qty * cv_FCPrc * cv_Rate * cv_VatRate))
                            cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cv_Qty * cv_FCPrc * cv_Rate * cv_VatRate), cv_TaxRndRule, 0))
                        End If
                    End If

                Case "colDDEPPRC"
                    cDBDataD.SetValue("U_DDEPAMT", pval.Row - 1, CDbl(cv_Qty * cDBDataD.GetValue("U_DDEPPRC", pval.Row - 1)))

                Case "colDISPRC"

                    cDBDataD.SetValue("U_DISAMT", pval.Row - 1, CDbl(cv_Qty * cDBDataD.GetValue("U_DISPRC", pval.Row - 1)))
                Case "colVATGRP"
                    'cDBDataD.SetValue("U_VAT", pval.Row - 1, CDbl(cDBDataD.GetValue("U_AMT", pval.Row - 1)) * CDbl(cv_VatRate))
                    cDBDataD.SetValue("U_VAT", pval.Row - 1, GetRoundFormat(CDbl(cDBDataD.GetValue("U_AMT", pval.Row - 1)) * CDbl(cv_VatRate), cv_TaxRndRule, 0))
            End Select

            cDBDataD.Offset = pval.Row - 1
            oMatrix.SetLineData(pval.Row)
            'oMatrix.LoadFromDataSource()
            ReCalTotAmt(oMatrix, cDBDataD, cForm.DataSources.UserDataSources)

        Catch ex As Exception

            cForm = Nothing
            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("FA0198", ModuleIni.FA) & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error) '계산도중 에러가 발생했습니다.메세지 : 
        Finally

            cForm = Nothing

        End Try
    End Sub


    ''' <summary>
    ''' checkCUR
    ''' </summary>
    ''' <param name="cDBDataH"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function checkCUR(ByVal cDBDataH As SAPbouiCOM.DBDataSource) As Boolean

        ''통화 
        Dim Cur As String = cDBDataH.GetValue("U_CURR", 0)
        Dim LCur As String = CFL.GetValue("SELECT MAinCurncy FROM OADM")

        Try
            checkCUR = False

            If Cur = "" Then
                Return False
            End If

            If LCur <> Cur Then
                Return True
            End If

            Return checkCUR

        Catch ex As Exception
            checkCUR = False
            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("FA0197", ModuleIni.FA) & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error) '통화체크도중 발생했습니다.메세지 : 
        Finally
        End Try
    End Function


    ''' <summary>
    ''' SetRowNum
    ''' </summary>
    ''' <param name="oGrid"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SetRowNum(ByVal oGrid As SAPbouiCOM.Grid) As Boolean

        Try

            If oGrid.DataTable Is Nothing Then Return True

            For iRow As Integer = 0 To oGrid.Rows.Count - 1

                oGrid.RowHeaders.SetText(iRow, CStr(iRow + 1))

            Next

            Return True
        Catch ex As Exception
            oApplication.StatusBar.SetText("Common Function Error(SetRowNum) : " & ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning)
            Return False

        End Try
    End Function


    ''' <summary>
    ''' RowAdd
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="oMatrix"></param>
    ''' <param name="DbSrc"></param>
    ''' <remarks></remarks>
    Public Sub RowAdd(ByVal oForm As SAPbouiCOM.Form, ByVal oMatrix As SAPbouiCOM.Matrix, ByVal DbSrc As SAPbouiCOM.DBDataSource)

        Try
            oForm.Freeze(True)

            DbSrc.Clear()
            oMatrix.AddRow(1)
            oMatrix.FlushToDataSource()

            Dim i As Integer
            For i = 0 To DbSrc.Fields.Count - 1
                If (Left(DbSrc.Fields.Item(i).Name, 2) = "U_" Or DbSrc.Fields.Item(i).Name = "LineId") Then
                    DbSrc.SetValue(i, oMatrix.VisualRowCount - 1, "")
                End If

            Next

            DbSrc.Offset = oMatrix.VisualRowCount - 1
            oMatrix.SetLineData(oMatrix.VisualRowCount)

            'oMatrix.LoadFromDataSource()
            oMatrix.SelectRow(oMatrix.VisualRowCount, True, False)

            If oForm.Mode = BoFormMode.fm_OK_MODE Then
                oForm.Mode = BoFormMode.fm_UPDATE_MODE
            End If

            oForm.Freeze(False)

        Catch
            oForm.Freeze(False)
            B1Connections.theAppl.StatusBar.SetText("OnAfterRowDataMenu_Add " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try


    End Sub


    ''' <summary>
    ''' RowDelete
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="oMatrix"></param>
    ''' <remarks></remarks>
    Public Sub RowDelete(ByVal oForm As SAPbouiCOM.Form, ByVal oMatrix As SAPbouiCOM.Matrix)

        Dim i As Integer

        Try

            '제거를 눌러도 화면에서만 사라지고 실제 메트릭스에서는 사라지지 않음. 
            '강제로 한 줄 추가 후 제거하면 반영되어 루틴을 추가함.
            oForm.Freeze(True)

            oMatrix.AddRow()
            i = oMatrix.VisualRowCount

            Call oMatrix.DeleteRow(i)
            oMatrix.FlushToDataSource()

            oForm.Freeze(False)


        Catch ex As Exception
            oForm.Freeze(False)
            B1Connections.theAppl.StatusBar.SetText("OnAfterRowDataMenu_Delete " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try


    End Sub


    '****************************************************************************************************
    '   함수명      :   gfnSeGridCombo
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   그리드 콤보셋팅
    '   인수        :   
    '****************************************************************************************************
    Public Function gfnSeGridCombo(ByVal oColumn As SAPbouiCOM.ComboBoxColumn, ByVal strGroupCd As String, ByVal strSql As String) As Boolean

        Dim i As Integer
        Dim icnt As Integer
        Dim otempRS As SAPbobsCOM.Recordset
        Dim xSql As String

        gfnSeGridCombo = False

        Try

            otempRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)


            icnt = oColumn.ValidValues.Count

            If icnt > 0 Then
                For i = 0 To icnt - 1
                    oColumn.ValidValues.Remove(0, BoSearchKey.psk_Index)
                Next

            End If

            If strGroupCd <> "" Then
                xSql = "select U_SMLCD, U_SMLNM from [@WJS_SAD011] where CODE = '" & strGroupCd & "' "
                otempRS.DoQuery(xSql)
            ElseIf strSql <> " Then" Then
                otempRS.DoQuery(strSql)
            Else
                B1Connections.theAppl.StatusBar.SetText("There is no paramiter ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                If Not otempRS Is Nothing Then otempRS = Nothing
                Exit Function
            End If


            If Not otempRS.EoF Then
                otempRS.MoveFirst()
                For i = 1 To otempRS.RecordCount

                    oColumn.ValidValues.Add(otempRS.Fields.Item(0).Value, otempRS.Fields.Item(1).Value)

                    otempRS.MoveNext()
                Next
            Else
                oColumn.ValidValues.Add("", "")
            End If

            If Not otempRS Is Nothing Then otempRS = Nothing

            gfnSeGridCombo = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("gfnSeGridCombo " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            otempRS = Nothing

        End Try

    End Function

    Public Sub SetDefaultPlantUserFild(ByRef oForm As SAPbouiCOM.Form, ByVal strPLCD_FLDNM As String, ByVal strPLNM_FLDNM As String)

        ' Default 공장셋팅을 위해. 사용자정의 필드화면이 띄워 졌는지 확인한다.
        If (Not B1Connections.theAppl.Menus.Item("6913").Checked) Then
            B1Connections.theAppl.Menus.Item("6913").Activate()
        End If

        Dim cForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(oForm.TypeEx _
                                                    , oForm.TypeCount)

        If (cForm Is Nothing) Then '사용자정의 필드화면을 가져와서 없으면 리턴함.
            Return
        ElseIf (Not LMS_COMMON.ChkExtItemEnable(cForm, strPLCD_FLDNM)) Then
            Return
        Else
            Dim hs As Hashtable = LMS_COMMON.GetDfltPlant()
            cForm.Items.Item(strPLCD_FLDNM).Specific.Value = hs.Item("U_PLCD").ToString()
            cForm.Items.Item(strPLNM_FLDNM).Specific.Value = hs.Item("U_PLNM").ToString()
        End If

    End Sub

    Public Function ChkExtItemEnable(ByRef oForm As SAPbouiCOM.Form, ByVal strUid As String) As Boolean

        Dim i As Integer = 0
        Dim xmlAtt As Xml.XmlAttribute
        Dim xmlDoc As Xml.XmlDocument = New Xml.XmlDocument()
        xmlDoc.LoadXml(oForm.GetAsXML())

        For Each node As Xml.XmlNode In xmlDoc.SelectNodes("Application/forms/action/form/items/action/item")
            xmlAtt = node.Attributes.ItemOf("uid") '아이템 아이디
            If (Not xmlAtt Is Nothing) Then
                If (xmlAtt.InnerText = strUid) Then
                    xmlAtt = node.Attributes.ItemOf("visible") '활성화
                    If (Not xmlAtt Is Nothing) Then
                        If (xmlAtt.InnerText = "1") Then
                            xmlAtt = node.Attributes.ItemOf("enabled") '편집가능
                            If (Not xmlAtt Is Nothing) Then
                                If (xmlAtt.InnerText = "1") Then
                                    Return True
                                End If
                            End If
                        End If
                    End If
                End If
            End If

        Next

        Return False

    End Function

    '****************************************************************************************************
    '   함수명      :   SetBplidCombo
    '   작성자      :   최양규
    '   작성일      :   
    '   간략한 설명 :   세그먼트 설정에 따른 사업장 콤보 조회
    '   인수        :   ComboObj- 콤보객체명

    '                   AllYN   - TRUE    : 전체추가 
    '                             FALSE   : 전체없음
    '                   UseYN   - TRUE    : 사용중인 사업장만
    '                             FALSE   : 모든 사업장

    '****************************************************************************************************
    Public Sub SetBplidCombo(ByVal ComboObj As SAPbouiCOM.ComboBox, ByVal AllYN As Boolean, ByVal UseYN As Boolean)

        Dim oRS As SAPbobsCOM.Recordset
        Dim xSql As String
        Dim cv_BplTP As String
        Dim i As Integer

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            For i = 1 To ComboObj.ValidValues.Count
                ComboObj.ValidValues.Remove(0, BoSearchKey.psk_Index)
            Next

#If HANA = "Y" Then
            oRS.DoQuery(CFL.GetConvertHANA("SELECT ISNULL(U_BPLTP, 'N') AS U_BPLTP FROM [@WJS_SAD00M] "))
#Else
            oRS.DoQuery("SELECT ISNULL(U_BPLTP, 'N') AS U_BPLTP FROM [@WJS_SAD00M] ")
#End If
            cv_BplTP = oRS.Fields.Item("U_BPLTP").Value

            If cv_BplTP = "Y" Then

                If UseYN Then
                    xSql = "SELECT BPLID, BPLNAME FROM OBPL WHERE DISABLED = N'N' ORDER BY BPLID"
                Else
                    xSql = "SELECT BPLID, BPLNAME FROM OBPL ORDER BY BPLID"
                End If
            Else

                xSql = "SELECT Code, Name FROM OASC WHERE SegmentId = '1' "

            End If
#If HANA = "Y" Then
            xSql = CFL.GetConvertHANA(xSql)
#End If

            oRS.DoQuery(xSql)

            If AllYN Then
                ComboObj.ValidValues.Add("", CFL.GetCaption("전체", ModuleIni.FI))
            End If

            'If Not oRS.EoF Then
            For i = 0 To oRS.RecordCount - 1
                ComboObj.ValidValues.Add(oRS.Fields.Item(0).Value.ToString, oRS.Fields.Item(1).Value.ToString)
                oRS.MoveNext()
            Next
            'End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            oRS = Nothing

        End Try

    End Sub

    Public Function EDU_CHK_AD(Optional ByVal strCode As String = "") As Boolean

        EDU_CHK_AD = False

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD01M") = False Then
            ' 테이블이 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD01M" + CFL.GetMSG("FI0249", ModuleIni.FI))
            Exit Function
        End If

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD001") = False Then
            ' 테이블이 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD001" + CFL.GetMSG("FI0249", ModuleIni.FI))
            Exit Function
        End If

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD001", "U_PRTTP") = False Then
            ' 테이블의 필드가 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD001" + CFL.GetMSG("FI0250", ModuleIni.FI) + "U_PRTTP" + CFL.GetMSG("FI0251", ModuleIni.FI))
            Exit Function
        End If

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD001", "U_PRTFILE") = False Then
            ' 테이블의 필드가 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD001" + CFL.GetMSG("FI0250", ModuleIni.FI) + "U_PRTFILE" + CFL.GetMSG("FI0251", ModuleIni.FI))
            Exit Function
        End If

        If CFL.GetValue("SELECT 1 FROM [@WJS_SAD00M]") = "" Then
            '운영>>설정>>추가설정>>환경설정을 먼저 설정바랍니다.
            CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0188", ModuleIni.FI))
            Exit Function
        End If

        If strCode <> "" Then
            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE ISNULL(U_PRTTP,'') = '" & strCode & "' AND ISNULL(U_PRTFILE,'') <> ''") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 레포트파일를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0189", ModuleIni.FI) + " (" + strCode + ")")
                Exit Function
            End If

            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE ISNULL(U_PRTTP,'') = '" & strCode & "' AND ISNULL(U_PRTPROC,'') <> ''") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 프로시저를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0190", ModuleIni.FI) + " (" + strCode + ")")
                Exit Function
            End If

        Else
            '건별, 그룹별 체크
            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE (ISNULL(U_PRTTP,'') = 'S01' AND ISNULL(U_PRTFILE,'') <> '') OR (ISNULL(U_PRTTP,'') = 'S02' AND ISNULL(U_PRTFILE,'') <> '')") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 레포트파일를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0189", ModuleIni.FI))
                Exit Function
            End If

            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE (ISNULL(U_PRTTP,'') = 'S01' AND ISNULL(U_PRTPROC,'') <> '') OR (ISNULL(U_PRTTP,'') = 'S02' AND ISNULL(U_PRTPROC,'') <> '')") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 프로시저를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0190", ModuleIni.FI))
                Exit Function
            End If
        End If

        EDU_CHK_AD = True

    End Function

    Public Function Chk_TableonDB(ByVal cv_TableName As String, Optional ByVal cv_Field1 As String = "") As Boolean

        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSql As String = ""

        Chk_TableonDB = True

        Try


            If cv_Field1 = "" Then
                xSql = "SELECT COUNT(*) FROM SYSOBJECTS WHERE XTYPE = 'U' AND NAME = '" & cv_TableName & "' "
            Else
                xSql = "select COUNT(*) from INFORMATION_SCHEMA.COLUMNS where table_name = '" & cv_TableName & "' and column_name= '" & cv_Field1 & "'"
            End If
#If HANA = "Y" Then
            xSql = CFL.GetConvertHANA(xSql)
#End If
            oRS.DoQuery(xSql)

            If Not oRS.EoF Then

                If oRS.Fields.Item(0).Value <= 0 Then
                    Chk_TableonDB = False
                    Exit Try
                End If
            Else
                Chk_TableonDB = False
            End If


        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("Chk_TableonDB " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            oRS = Nothing

        End Try

    End Function

    Public Function GetDfltPlant() As Hashtable
        Dim hs As Hashtable = New Hashtable()
        Dim RS As SAPbobsCOM.Recordset
        Dim xSQL As String = ""

        Try
            RS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            xSQL = " select U_PLCD, U_PLNM "
            xSQL = xSQL & vbCrLf & "  from [@WJS_SAD63M]  "
            xSQL = xSQL & vbCrLf & " where isnull(U_DFLTPLT,'N') = 'Y' "
#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If
            RS.DoQuery(xSQL)
            RS.MoveFirst()
            hs.Add("U_PLCD", RS.Fields.Item("U_PLCD").Value.ToString.Trim())
            hs.Add("U_PLNM", RS.Fields.Item("U_PLNM").Value.ToString.Trim())
        Catch ex As Exception
            If (Not hs.ContainsKey("U_PLCD")) Then
                hs.Add("U_PLCD", "")
            End If
            If (Not hs.ContainsKey("U_PLNM")) Then
                hs.Add("U_PLNM", "")
            End If
        Finally
            RS = Nothing
        End Try

        Return hs

    End Function

    Public Function GetLangCode() As String

        Dim v_RTNVAL As String = ""

        Try

            If B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_English Then
                v_RTNVAL = "ENG"
            ElseIf B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_English_Cy Then
                v_RTNVAL = "ENG"
            ElseIf B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_English_Gb Then
                v_RTNVAL = "ENG"
            ElseIf B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_English_Sg Then
                v_RTNVAL = "ENG"
            ElseIf B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_Chinese Then
                v_RTNVAL = "CHN"
            ElseIf B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_Korean_Kr Then
                v_RTNVAL = "KOR"
            ElseIf B1Connections.diCompany.language = SAPbobsCOM.BoSuppLangs.ln_Japanese_Jp Then
                v_RTNVAL = "JPN"
            End If


        Catch ex As Exception

        End Try

        Return v_RTNVAL

    End Function

    Public Function FI_CHK_AD(Optional ByVal strCode As String = "") As Boolean

        FI_CHK_AD = False

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD01M") = False Then
            ' 테이블이 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD01M" + CFL.GetMSG("FI0249", ModuleIni.FI))
            Exit Function
        End If

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD001") = False Then
            ' 테이블이 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD001" + CFL.GetMSG("FI0249", ModuleIni.FI))
            Exit Function
        End If

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD001", "U_PRTTP") = False Then
            ' 테이블의 필드가 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD001" + CFL.GetMSG("FI0250", ModuleIni.FI) + "U_PRTTP" + CFL.GetMSG("FI0251", ModuleIni.FI))
            Exit Function
        End If

        If LMS_COMMON.Chk_TableonDB("@WJS_SAD001", "U_PRTFILE") = False Then
            ' 테이블의 필드가 존재하지 않습니다.
            CFL.COMMON_MESSAGE("!", "@WJS_SAD001" + CFL.GetMSG("FI0250", ModuleIni.FI) + "U_PRTFILE" + CFL.GetMSG("FI0251", ModuleIni.FI))
            Exit Function
        End If

        If CFL.GetValue("SELECT 1 FROM [@WJS_SAD00M]") = "" Then
            '운영>>설정>>추가설정>>환경설정을 먼저 설정바랍니다.
            CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0188", ModuleIni.FI))
            Exit Function
        End If

        If strCode <> "" Then
            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE ISNULL(U_PRTTP,'') = '" & strCode & "' AND ISNULL(U_PRTFILE,'') <> ''") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 레포트파일를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0189", ModuleIni.FI) + " (" + strCode + ")")
                Exit Function
            End If

            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE ISNULL(U_PRTTP,'') = '" & strCode & "' AND ISNULL(U_PRTPROC,'') <> ''") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 프로시저를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0190", ModuleIni.FI) + " (" + strCode + ")")
                Exit Function
            End If

        Else
            '건별, 그룹별 체크
            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE (ISNULL(U_PRTTP,'') = 'S01' AND ISNULL(U_PRTFILE,'') <> '') OR (ISNULL(U_PRTTP,'') = 'S02' AND ISNULL(U_PRTFILE,'') <> '')") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 레포트파일를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0189", ModuleIni.FI))
                Exit Function
            End If

            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SAD001] WHERE (ISNULL(U_PRTTP,'') = 'S01' AND ISNULL(U_PRTPROC,'') <> '') OR (ISNULL(U_PRTTP,'') = 'S02' AND ISNULL(U_PRTPROC,'') <> '')") = "" Then
                '운영>>설정>>추가설정>>환경설정에서 전표인쇄 프로시저를 설정바랍니다.
                CFL.COMMON_MESSAGE("!", CFL.GetMSG("FI0190", ModuleIni.FI))
                Exit Function
            End If
        End If

        FI_CHK_AD = True

    End Function

    Public Function ChkYYYYMM(ByVal agDate As String, Optional ByVal DateForm As Integer = 1) As String
        Dim v_DateSp_s As String = GetDateSplit()
        Dim v_ChkDate_s As String = Replace(agDate, v_DateSp_s, "")           '체크할 일자
        '날짜유형이 일.월.년 과 같은 형태로 세팅되어 있을시 에러
        '날짜유형에 관계없이 처리 가능하도록 변경 2013.03.04 - SBO 김정환
        'Dim v_CurDate_s As String = Replace(GetDateFormat("", CFL.GetSystemDate), v_DateSp_s, "")
        Dim v_CurDate_s As String = Replace(CFL.GetNowDate(AddOnBase.Enum_Date.m_Ccyymmdd), ".", "")
        Dim v_RetDate_s As String
        Dim v_RTNVAL As String = ""

        Try

            If agDate <> "" Then
                Select Case DateForm
                    Case 1
                        If IsNumeric(agDate) Then                           '입력한 값이 13보다 작은 현재 년의 입력한 숫자를 월로 셋팅한다.
                            If CLng(agDate) < 13 And CLng(agDate) <> 0 Then
                                Return (Mid(v_CurDate_s, 1, 4) & Right(CStr(CLng(agDate) + 100), 2))
                            Else
                                If Len(agDate) = 6 Then
                                    v_ChkDate_s = v_ChkDate_s + "01"
                                Else
                                    v_ChkDate_s = v_CurDate_s
                                End If

                            End If
                        End If

                    Case 2
                        v_ChkDate_s = Mid(Mid(v_CurDate_s, 1, 4), 1, 4 - Len(v_ChkDate_s)) + v_ChkDate_s + "0101" '년

                End Select

                v_RetDate_s = GetCheckDate(v_ChkDate_s)

                Select Case DateForm
                    Case 1 : v_RTNVAL = (Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 1, 4) & _
                                                 Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 5, 2))                  'YYYYMM
                    Case 2 : v_RTNVAL = (Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 1, 4))                  'YYYY
                End Select
            End If

        Catch ex As Exception

        End Try

        Return v_RTNVAL
    End Function

    Public Function GetDateSplit(Optional ByVal agDate As String = "") As String
        Dim oRS As SAPbobsCOM.Recordset
        Dim xSQL As String
        Dim rValue As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            GetDateSplit = ""

            xSQL = "SELECT DateSep FROM OADM"
#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If
            oRS.DoQuery(xSQL)

            If Not oRS.EoF Then

                If agDate <> "" Then
                    GetDateSplit = Replace(agDate, oRS.Fields.Item(0).Value, "")
                Else
                    GetDateSplit = oRS.Fields.Item(0).Value
                End If

            End If

            rValue = GetDateSplit

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetDateSplit" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return rValue
    End Function

    Public Function GetChangeDate(ByVal agDate As String, Optional ByVal DateForm As Integer = 0) As String
        Dim dtInfo As System.Globalization.DateTimeFormatInfo = New System.Globalization.CultureInfo(System.Globalization.CultureInfo.CurrentCulture.ToString(), False).DateTimeFormat

        Dim v_DateSp_s As String
        Dim v_ChkDate_s As String
        Dim v_CurDate_s As String
        Dim v_RetDate_s As String
        Dim rValue As String = ""


        Try

            GetChangeDate = ""

            If agDate <> "" Then

                '// 수정  GetDateSplit(agDate) 날짜값 넘겨주는거 삭제
                v_DateSp_s = GetDateSplit("")                           '일자의 구분값을 가져온다.
                v_ChkDate_s = Replace(agDate, v_DateSp_s, "")           '체크할 일자
                v_CurDate_s = Replace(GetDateFormat("", B1Connections.theAppl.Company.ServerDate), v_DateSp_s, "") '시스템 일자

                Select Case DateForm
                    Case 1
                        v_ChkDate_s = Mid(Mid(v_CurDate_s, 1, 4), 1, 8 - Len(v_ChkDate_s)) + v_ChkDate_s '년월일 포맷으로 완성

                    Case 2
                        If IsNumeric(agDate) Then                           '입력한 값이 13보다 작은 현재 년의 입력한 숫자를 월로 셋팅한다.
                            If CLng(agDate) < 13 Then
                                GetChangeDate = Mid(v_CurDate_s, 1, 4) & v_DateSp_s & Right(CStr(CLng(agDate) + 100), 2)

                                Exit Try
                            Else
                                If Len(agDate) = 6 Then
                                    v_ChkDate_s = v_ChkDate_s + "01"
                                Else
                                    v_ChkDate_s = v_CurDate_s
                                End If

                            End If
                        End If

                    Case 3
                        v_ChkDate_s = Mid(Mid(v_CurDate_s, 1, 4), 1, 4 - Len(v_ChkDate_s)) + v_ChkDate_s + "0101" '년


                End Select

                v_RetDate_s = GetCheckDate(v_ChkDate_s)

                Select Case DateForm
                    Case 1 : GetChangeDate = Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 1, 4) & v_DateSp_s & _
                                                 Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 5, 2) & v_DateSp_s & _
                                                 Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 7, 2)                  'YYYYMMDD
                    Case 2 : GetChangeDate = Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 1, 4) & v_DateSp_s & _
                                                 Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 5, 2)                  'YYYYMM
                    Case 3 : GetChangeDate = Mid(IIf(v_RetDate_s = 1, v_ChkDate_s, v_CurDate_s), 1, 4)                  'YYYY
                End Select

            End If

            rValue = GetChangeDate

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetChangeDate" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally

        End Try


        Return rValue
    End Function

    Enum DateType
        m_Ddmmyy = 0
        m_Ddmmccyy = 1
        m_Mmddyy = 2
        m_Mmddccyy = 3
        m_Ccyymmdd = 4
        M_YYYYMondd = 5
        m_Yymmdd = 6
    End Enum

    Public Function GetDateFormat(ByVal agDbDate As String, Optional ByVal agDate1 As String = "", Optional ByVal agDate2 As String = "") As String

        Dim oRS As SAPbobsCOM.Recordset
        Dim AryField
        Dim v_DateFormat_s As String
        Dim v_DateSep_s As String
        Dim xSql As String

        Dim rValue As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            GetDateFormat = ""

            xSql = "SELECT DateFormat, DateSep FROM OADM"
#If HANA = "Y" Then
            xSql = CFL.GetConvertHANA(xSql)
#End If
            oRS.DoQuery(xSql)

            If Not oRS.EoF Then

                v_DateFormat_s = Trim(oRS.Fields.Item(0).Value)
                v_DateSep_s = Trim(oRS.Fields.Item(1).Value)

                GetDateFormat = ""
                If agDbDate <> "" Then                                    'DB에 DATE 값 넘겨줄때

                    AryField = Split(agDbDate, Trim(oRS.Fields.Item(1).Value))

                    Select Case v_DateFormat_s
                        Case DateType.m_Ddmmyy : GetDateFormat = AryField(2) & "-" & AryField(1) & "-" & AryField(0)
                        Case DateType.m_Ddmmccyy : GetDateFormat = AryField(2) & " - " & AryField(1) & " - " & AryField(0)
                        Case DateType.m_Mmddyy : GetDateFormat = AryField(2) & " - " & AryField(0) & " - " & AryField(1)
                        Case DateType.m_Mmddccyy : GetDateFormat = AryField(2) & " - " & AryField(0) & " - " & AryField(1)
                        Case DateType.m_Yymmdd : GetDateFormat = AryField(0) & " - " & AryField(1) & " - " & AryField(2)
                        Case DateType.m_Ccyymmdd : GetDateFormat = AryField(0) & " - " & AryField(1) & " - " & AryField(2)
                            'Case DateType.m_Ddmmyyyy : GetDateFormat = AryField(2) & "-" & AryField(1) & "-" & AryField(0)
                    End Select

                ElseIf agDbDate = "" And agDate1 <> "" Then             '리스트에 DATE값 뿌려줄때

                    If agDate1 Like "*-*" Then
                        AryField = Split(agDate1, "-")
                    Else
                        AryField = Split(agDate1, ".")
                    End If

                    'AryField = Split(agDate1, "-")
                    Select Case v_DateFormat_s
                        Case DateType.m_Ddmmyy : GetDateFormat = AryField(2) & v_DateSep_s & AryField(1) & v_DateSep_s & Mid(AryField(0), 3, 2)
                        Case DateType.m_Ddmmccyy : GetDateFormat = AryField(2) & v_DateSep_s & AryField(1) & v_DateSep_s & AryField(0)
                        Case DateType.m_Mmddyy : GetDateFormat = AryField(1) & v_DateSep_s & AryField(2) & v_DateSep_s & Mid(AryField(0), 3, 2)
                        Case DateType.m_Mmddccyy : GetDateFormat = AryField(2) & v_DateSep_s & AryField(0) & v_DateSep_s & AryField(1)
                        Case DateType.m_Yymmdd : GetDateFormat = Mid(AryField(0), 3, 2) & v_DateSep_s & AryField(1) & v_DateSep_s & AryField(2)
                        Case DateType.m_Ccyymmdd : GetDateFormat = AryField(0) & v_DateSep_s & AryField(1) & v_DateSep_s & AryField(2)
                            'Case DateType.m_Ddmmyyyy : GetDateFormat = AryField(2) & v_DateSep_s & AryField(1) & v_DateSep_s & AryField(0)
                    End Select

                ElseIf agDate2 <> "" Then
                    v_DateSep_s = ""
                    'yyyymmdd
                    'yyyy LEFT(agDate2,4)
                    'yy Left(agDate2,2)
                    ''mm Mid(agDate2,3,2)
                    'dd Right(agDate2,2)
                    Select Case v_DateFormat_s
                        Case DateType.m_Ddmmyy : GetDateFormat = Right(agDate2, 2)
                        Case DateType.m_Ddmmccyy : GetDateFormat = Right(agDate2, 4)
                        Case DateType.m_Mmddyy : GetDateFormat = Right(agDate2, 2)
                        Case DateType.m_Mmddccyy : GetDateFormat = Right(agDate2, 4)

                        Case DateType.m_Yymmdd : GetDateFormat = Left(agDate2, 2)
                        Case DateType.m_Ccyymmdd : GetDateFormat = Left(agDate2, 4)
                            'Case DateType.m_Ddmmyyyy : GetDateFormat = Right(agDate2, 4) & v_DateSep_s & Mid(agDate2, 3, 2) & v_DateSep_s & Left(agDate2, 2)
                    End Select

                End If

            End If

            rValue = GetDateFormat

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("GetDateFormat" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            oRS = Nothing

        End Try

        Return rValue

    End Function

    Public Function GetCheckDate(ByVal agDate As String) As Integer

        Dim oRS As SAPbobsCOM.Recordset

        Try
            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
#If HANA = "Y" Then
            oRS.DoQuery("CALL ""WJS_SP_ADCM_ISDATETIME"" ('" & agDate & "') ")
#Else
            oRS.DoQuery("SELECT * FROM (SELECT ISDATE('" & agDate & "') a) as a")
#End If

            GetCheckDate = 0
            GetCheckDate = oRS.Fields.Item(0).Value

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("GetCheckDate" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            oRS = Nothing

        End Try

    End Function

    ''' <summary>
    ''' 콤보 셋팅
    ''' </summary>
    ''' <param name="ComboObj">콤보객체명</param>
    ''' <param name="xSql">쿼리 구문</param>
    ''' <param name="AddEmpty">공백 추가 여부</param>
    ''' <remarks>사업장 콤보 셋팅</remarks>
    Public Sub SetCOMBO(ByVal ComboObj As SAPbouiCOM.ComboBox, ByVal xSql As String, ByVal AddEmpty As Boolean)

        Dim oRS As SAPbobsCOM.Recordset
        Dim i As Integer
        oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Try



            For i = 1 To ComboObj.ValidValues.Count
                ComboObj.ValidValues.Remove(0, BoSearchKey.psk_Index)
            Next

            oRS.DoQuery(xSql)

            If AddEmpty Then
                ComboObj.ValidValues.Add("", "")
            End If

            'If Not oRS.EoF Then
            For i = 0 To oRS.RecordCount - 1
                ComboObj.ValidValues.Add(oRS.Fields.Item(0).Value.ToString, oRS.Fields.Item(1).Value.ToString)
                oRS.MoveNext()
            Next
            'End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally
            If (Not (oRS) Is Nothing) Then Marshal.ReleaseComObject(oRS)
            oRS = Nothing

        End Try

    End Sub
    Public Sub SetCOMBO(ByVal oForm As SAPbouiCOM.Form, ByVal ComboObjName As String, ByVal xSql As String, ByVal AddEmpty As Boolean)
        Call SetCOMBO(oForm.Items.Item(ComboObjName).Specific, xSql, AddEmpty)
    End Sub


    ''' <summary>
    ''' 그리스 수량,금액,가격,비율 등의 소숫점 SBO기준 셋팅
    ''' </summary>
    ''' <param name="oGrid"></param>
    ''' <param name="strColQty"></param>
    ''' <param name="strColAmt"></param>
    ''' <param name="strColPrc"></param>
    ''' <param name="strColRate"></param>
    ''' <remarks></remarks>
    Public Sub SetGrdColumnNumber(ByRef oGrid As SAPbouiCOM.Grid, ByVal strColQty As String, Optional ByVal strColAmt As String = "", Optional ByVal strColPrc As String = "", Optional ByVal strColRate As String = "", Optional ByVal strColPercent As String = "")

        Call SetDataTableColumnNumber(oGrid.DataTable, strColQty, strColAmt, strColPrc, strColRate, strColPercent)

        If (ExistsColGrid(oGrid, "RowsHeader")) Then
            oGrid.Columns.Item("RowsHeader").Width = 20
        End If


    End Sub


    ''' <summary>
    ''' DataTable 수량,금액,가격,비율 등의 소숫점 SBO기준 셋팅
    ''' </summary>
    ''' <param name="oDataTable"></param>
    ''' <param name="strColQty"></param>
    ''' <param name="strColAmt"></param>
    ''' <param name="strColPrc"></param>
    ''' <param name="strColRate"></param>
    ''' <remarks></remarks>
    Public Sub SetDataTableColumnNumber(ByVal oDataTable As SAPbouiCOM.DataTable, ByVal strColQty As String, Optional ByVal strColAmt As String = "", Optional ByVal strColPrc As String = "", Optional ByVal strColRate As String = "", Optional ByVal strColPercent As String = "")

        Dim xMLDoc As Xml.XmlDocument = New Xml.XmlDocument()
        xMLDoc.LoadXml(oDataTable.SerializeAsXML(BoDataTableXmlSelect.dxs_All))
        Dim arrColQty As ArrayList = New ArrayList()
        If (Not strColQty Is Nothing) Then arrColQty.AddRange(strColQty.Replace(" ", "").Split(",")) '수량
        Dim arrColAmt As ArrayList = New ArrayList()
        If (Not strColAmt Is Nothing) Then arrColAmt.AddRange(strColAmt.Replace(" ", "").Split(",")) '금액
        Dim arrColPrc As ArrayList = New ArrayList()
        If (Not strColPrc Is Nothing) Then arrColPrc.AddRange(strColPrc.Replace(" ", "").Split(",")) '단가
        Dim arrColRate As ArrayList = New ArrayList()
        If (Not strColRate Is Nothing) Then arrColRate.AddRange(strColRate.Replace(" ", "").Split(",")) '비율
        Dim arrColPercent As ArrayList = New ArrayList()
        If (Not strColPercent Is Nothing) Then arrColPercent.AddRange(strColPercent.Replace(" ", "").Split(",")) '%

        For Each node As XmlNode In xMLDoc.GetElementsByTagName("Column")
            If (arrColQty.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Quantity
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColAmt.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Sum
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColPrc.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Price
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColRate.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Rate
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColPercent.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Percent
                node.Attributes("MaxLength").InnerText = "0"
            End If

        Next

        oDataTable.LoadSerializedXML(BoDataTableXmlSelect.dxs_All, xMLDoc.InnerXml)

    End Sub


    ''' <summary>
    ''' 그리드 컬럼 포함여부
    ''' </summary>
    ''' <param name="oGrid"></param>
    ''' <param name="strCol"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ExistsColGrid(ByRef oGrid As SAPbouiCOM.Grid, ByVal strCol As String) As Boolean


        Dim i As Integer
        For i = 0 To oGrid.Columns.Count - 1
            If (oGrid.Columns.Item(i).UniqueID = strCol) Then
                Return True
            End If
        Next

        Return False


    End Function

    Public Function chkExcelExist() As Boolean

        'excel 설치여부 레지스트리 체크(BaseAddon에 있는 체크는 2003,2007버젼을 체크함.2010버젼을 체크하는것을 넣던지. 버전과 상관없이 엑셀설치여부를 체크하는 펑션을 만든후에 대체가능)
        Dim readValue = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe", "Path", "")
        If readValue <> "" Then
            chkExcelExist = True
        Else
            chkExcelExist = False
        End If

    End Function

    '****************************************************************************************************
    '   함수명      :   ExcelImportData
    '   작성자      :   최양규
    '   작성일      :   2012.05.11
    '   간략한 설명 :   조회된 쿼리 내역을 엑셀로 출력한다.
    '   인수        :   
    '****************************************************************************************************

    Public Function ExcelImportData(ByVal xSql As String, ByVal strTitle As String) As Boolean
        '그리드를 받아서 그리드 내용 그대로 엑셀로 찍어준다. 제일 위에 제목 넣어주고

        Dim xlApp As Excel.Application = Nothing
        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim oRs As SAPbobsCOM.Recordset

        Dim xlFileName As String = Nothing
        Dim xlFileNameType As String
        Dim xlFileType As String
        Dim pStartPath As String
        Dim i As Integer
        'Dim j As Integer

        Dim iHandle As Long

        Dim strConnectionString As String
        Dim oleCon As System.Data.OleDb.OleDbConnection = Nothing
        Dim oleAdapter As System.Data.OleDb.OleDbDataAdapter
        Dim oleCommnad As System.Data.OleDb.OleDbCommand
        Dim enumerator As System.Data.OleDb.OleDbEnumerator
        Dim ProviderList As ArrayList = New ArrayList()
        Dim iCnt As Integer
        Dim dts As System.Data.DataTable
        Dim oDtSet As System.Data.DataSet = New System.Data.DataSet
        Dim ExcelCon As String = "Provider="
        Dim cv_OLEDB_s As String = ""
        Dim cv_OLEVR_d As Double
        Dim av_Title_s As String
        Dim cv_SaveFolder_s As String = ""
        Dim c_Return_b As Boolean = False

        Try

            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("FI0052", ModuleIni.FI), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning) '데이터 조회중입니다

            '-------------------------------------------------------------------------------------------
            ' 사용자의 엑셀 환경에 따라 oleDb 접속 Provider 설정 
            enumerator = New OleDbEnumerator()
            '엑셀 Provider 여부에 따라 접속방식변경
            dts = enumerator.GetElements
            For iCnt = 1 To dts.Rows.Count()

                If dts.Rows(iCnt - 1).Item(0).ToString.IndexOf("Microsoft.ACE.OLEDB.") >= 0 Or dts.Rows(iCnt - 1).Item(0).ToString.IndexOf("Microsoft.Jet.OLEDB.") >= 0 Then
                    ProviderList.Add(dts.Rows(iCnt - 1).Item(0).ToString)
                End If
            Next

            ProviderList.Sort()

            cv_OLEVR_d = 0

            For iCnt = 1 To ProviderList.Count

                If ProviderList(iCnt - 1).ToString.IndexOf("Microsoft.ACE.OLEDB.") >= 0 Then

                    If cv_OLEVR_d < Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.ACE.OLEDB.", "")) Then
                        cv_OLEDB_s = ProviderList(iCnt - 1).ToString
                        cv_OLEVR_d = Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.ACE.OLEDB.", ""))
                    End If
                End If

            Next

            cv_OLEVR_d = 0

            If cv_OLEDB_s = "" Then
                For iCnt = 1 To ProviderList.Count

                    If ProviderList(iCnt - 1).ToString.IndexOf("Microsoft.Jet.OLEDB.") >= 0 Then
                        If cv_OLEVR_d < Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.Jet.OLEDB.", "")) Then
                            cv_OLEDB_s = ProviderList(iCnt - 1).ToString
                            cv_OLEVR_d = Convert.ToDouble(ProviderList(iCnt - 1).ToString.Replace("Microsoft.Jet.OLEDB.", ""))
                        End If
                    End If
                Next
            End If

            ExcelCon = ExcelCon & cv_OLEDB_s & ";"

            dts.Clear()

            '-------------------------------------------------------------------------------------------

            '-------------------------------------------------------------------------------------------
            ' 데이터조회후 데이터테이블로 형태 변환 _ Start  
            oRs = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            oRs.DoQuery(xSql)
            Dim strQryXml As String

            strQryXml = oRs.GetAsXML

            Dim xmlSR As System.IO.StringReader = New System.IO.StringReader(strQryXml)
            Dim theDataSet As DataSet = New DataSet
            Dim RowData As System.Data.DataTable = New System.Data.DataTable

            theDataSet.ReadXml(xmlSR)

            RowData = theDataSet.Tables(3)

            '데이터 테이블 시트용 명칭변경
            RowData.TableName = "Sheet1"
            '-------------------------------------------------------------------------------------------

            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("FI0053", ModuleIni.FI), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success) '조회완료

            '-------------------------------------------------------------------------------------------
            ' 엑셀파일을 읽어온 후에 신규파일로 저장 
            pStartPath = System.Reflection.Assembly.GetExecutingAssembly.Location
            pStartPath = pStartPath.Substring(0, InStrRev(pStartPath, "\"))

            If ExcelCon.IndexOf("Microsoft.Jet.OLEDB.") Then
                xlFileName = "XLS\" & "excelprint.xls"
                xlFileNameType = "Excel files (*.xls)|*.xls"
                xlFileType = ".xlsx"
            Else
                xlFileName = "XLS\" & "excelprint.xlsx"
                xlFileNameType = "Excel files (*.xlsx)|*.xlsx"
                xlFileType = ".xlsx"
            End If

            av_Title_s = DateTime.Parse(CDate(System.DateTime.Now)).ToString("yyyyMMddHHmss")

            If Not IsDir(pStartPath & xlFileName) Then
                Exit Try
            End If

            xlApp = CreateObject("Excel.Application")
            xlBook = xlApp.Workbooks.Open(pStartPath & xlFileName)

            '엑셀 개체Hendle 가져옴.
            iHandle = IntPtr.Zero
            If CInt(xlApp.Version) < "10.0" Then
                iHandle = FindWindow(Nothing, xlApp.Caption)
            Else
                iHandle = xlApp.Parent.Hwnd
            End If

            cv_SaveFolder_s = CFL.FileDialog(eFileDialog.en_SaveFile, xlFileNameType, True)

            If cv_SaveFolder_s = "" Then
                xlFileName = IIf(B1Connections.diCompany.GetCompanyService.GetAdminInfo.ExcelFolderPath = "", System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), B1Connections.diCompany.GetCompanyService.GetAdminInfo.ExcelFolderPath)
                xlFileName = xlFileName + IIf(xlFileName.LastIndexOf("\") = xlFileName.Length - 1, "", "\")
                If Dir(xlFileName, FileAttribute.Directory) = "" Then
                    MkDir(xlFileName)
                End If

                If strTitle = "" Or strTitle = Nothing Then
                    strTitle = "ExcelData"
                End If

                xlFileName = xlFileName + strTitle & "_" & av_Title_s & xlFileType
            Else
                xlFileName = cv_SaveFolder_s
            End If

            xlBook.SaveAs(xlFileName)

            If Not xlApp Is Nothing Then
                xlApp.Quit()
            End If

            'KillExcel(iHandle)
            '-------------------------------------------------------------------------------------------


            '------------------------------------------------------------------------------------------- 

            strConnectionString = ExcelCon + "Data Source=" + xlFileName + ";Extended Properties=" + Convert.ToChar(34).ToString() + "Excel 8.0;HDR=Yes;IMEX=0;" + Convert.ToChar(34).ToString()

            '엑셀 oledb객체생성 후  쿼리문 작성 
            oleCon = New OleDbConnection()
            oleCon.ConnectionString = strConnectionString

            '엑셀 oledb객체 연결
            oleCon.Open()

            Dim colNameField As String()
            Dim colParam As String()
            Dim createTable As String()
            Dim strColumnFieldQry As String
            Dim strCreateQry As String
            Dim strParmQry As String

            ReDim createTable(RowData.Columns.Count - 2)
            ReDim colNameField(RowData.Columns.Count - 2)
            ReDim colParam(RowData.Columns.Count - 2)

            '데이터테이블 컬럼명 및 파라미터 정의
            For i = 0 To RowData.Columns.Count - 2
                colNameField(i) = String.Format("[{0}]", RowData.Columns(i).ColumnName)
                colParam(i) = "?"
                createTable(i) = String.Format("[{0}] NVARCHAR(255)  ", RowData.Columns(i).ColumnName)
                'If RowData.Columns(i).ColumnName <> "QTY" Then
                '    createTable(i) = String.Format("[{0}] NVARCHAR(255)  ", RowData.Columns(i).ColumnName)
                'Else
                '    createTable(i) = String.Format("[{0}] NUMERIC(19,6)  ", RowData.Columns(i).ColumnName)
                'End If

            Next


            strColumnFieldQry = String.Join(",", colNameField)
            strCreateQry = String.Join(",", createTable)
            strParmQry = String.Join(",", colParam)

            oleCommnad = New OleDbCommand
            oleCommnad.Connection = oleCon

            '엑셀 시트테이블 생성
            oleCommnad = New OleDbCommand(" CREATE TABLE [Sheet1$] ( " + strCreateQry.ToString + " ) ", oleCon)
            oleCommnad.ExecuteNonQuery()

            'create the adapter with the select to get 
            oleAdapter = New OleDbDataAdapter("SELECT * FROM [Sheet1$] ", oleCon)

            '데이터테이블과 엑셀 포맷 설정
            oleAdapter.FillSchema(RowData, SchemaType.Source)
            oleAdapter.Fill(RowData)

            '데이터 인서트 쿼리문 작성
            oleAdapter.InsertCommand = New OleDbCommand(String.Format("INSERT INTO [Sheet1$] ( {0} ) VALUES ( {1} )", strColumnFieldQry, strParmQry), oleCon)

            '데이터 인서트 파라미터 정의
            For i = 0 To RowData.Columns.Count - 1
                oleAdapter.InsertCommand.Parameters.Add(String.Format("@[{0}]", RowData.Columns(i).ColumnName), OleDbType.Char, 255).SourceColumn = RowData.Columns(i).ColumnName.ToString
            Next

            '데이터테이블 내역 일괄 생성
            oleAdapter.Update(RowData)

            oleCon.Close()

            c_Return_b = True

            '-------------------------------------------------------------------------------------------


            Return c_Return_b

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

            If Not xlApp Is Nothing Then
                xlApp.Quit()
            End If

            c_Return_b = False

            Return c_Return_b

        Finally

            oleCon.Close()

            If Not xlApp Is Nothing Then
                xlApp.Quit()
            End If
            KillExcel(iHandle)

            xlApp = Nothing
            xlBook = Nothing
            xlSheet = Nothing

            dts = Nothing
            oDtSet = Nothing
            oleAdapter = Nothing
            oleCon = Nothing
            oleCommnad = Nothing
            enumerator = Nothing
            ProviderList = Nothing

            GC.Collect()
            GC.WaitForPendingFinalizers()

            If (xlFileName <> "" And c_Return_b = True) Then
                Dim proc As Process = New System.Diagnostics.Process
                proc.StartInfo.FileName = "EXCEL.EXE"
                proc.StartInfo.Arguments = """" & xlFileName & """"
                proc.StartInfo.WindowStyle = ProcessWindowStyle.Maximized
                proc.Start()
            End If

        End Try
    End Function

    Public Function IsDir(ByVal FileName As String) As Boolean

        If Dir(FileName) = "" Then
            '출력양식이 존재하지 않습니다
            B1Connections.theAppl.MessageBox("출력 양식이 존재하지 않습니다.")
            IsDir = False
            Exit Function
        End If

        IsDir = True

    End Function

    Public Sub MatrixSettingColor(ByVal ParamArray cols() As SAPbouiCOM.Column)

        For Each col As SAPbouiCOM.Column In cols
            col.BackColor = 12777465
        Next
    End Sub

    Public Sub DateEditeSetting(ByVal oForm As SAPbouiCOM.Form, _
                                ByVal type As String, _
                                ByVal ParamArray edtStr() As String)

        If Not oForm.Mode = BoFormMode.fm_ADD_MODE Then Exit Sub

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(BoObjectTypes.BoRecordset)
        Dim oStr As String = String.Empty
        Try
            oForm.Freeze(True)
            oRs = B1Connections.diCompany.GetBusinessObject(BoObjectTypes.BoRecordset)
            oStr = " EXEC [WJS_SP_FIA90903] "
            oStr = oStr & "N'" & type & "' "
            oRs.DoQuery(oStr)

            DirectCast(oForm.Items.Item(edtStr(0)).Specific, SAPbouiCOM.EditText).Value = oRs.Fields.Item(0).Value
            DirectCast(oForm.Items.Item(edtStr(1)).Specific, SAPbouiCOM.EditText).Value = oRs.Fields.Item(1).Value

            If oRs.Fields.Item(2).Value = "Y" Then

                'Dim itms As SAPbouiCOM.Items = oForm.Items

                'For Each itm As SAPbouiCOM.Item In itms
                '    oForm.ActiveItem = itm.UniqueID
                '    Exit For
                'Next

                'oForm.Items.Item(edtStr(0)).Enabled = False
                'oForm.Items.Item(edtStr(1)).Enabled = False

            Else
                oForm.Items.Item(edtStr(0)).Enabled = True
                oForm.Items.Item(edtStr(1)).Enabled = True
            End If
            oForm.Freeze(False)

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("DateEditeSetting " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            oForm.Freeze(False)
        End Try
    End Sub

    Public Function TranSave(ByVal oForm As SAPbouiCOM.Form, _
                             ByVal type As String, _
                             ByVal FTYYMM As String, _
                             ByVal TOYYMM As String, _
                             Optional ByVal YN As String = "Y") As Boolean

        'Dim oDBDataH As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item(datatable)
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(BoObjectTypes.BoRecordset)
        Dim oStr As String = String.Empty

        Try
            oRs = B1Connections.diCompany.GetBusinessObject(BoObjectTypes.BoRecordset)
            ', @U_CLDTCD VARCHAR(16) = ''
            ', @U_CLYN VARCHAR(1)
            ', @U_FICD varchar(16) = ''
            ', @U_FTYYMM varchar(8) = ''
            ', @U_TOYYMM varchar(8) = ''
            oStr = " EXEC [WJS_SP_FIA90901] "
            oStr = oStr & "'" & B1Connections.diCompany.UserSignature.ToString & "', "
            oStr = oStr & "N'" & YN & "', "
            oStr = oStr & "N'" & type & "', "
            oStr = oStr & "'" & FTYYMM & "', "
            oStr = oStr & "'" & TOYYMM & "' "
#If HANA = "Y" Then
            oStr = CFL.GetConvertHANA(oStr)
#End If
            oRs.DoQuery(oStr)

            If oRs.Fields.Item(0).Value = "0" Then

                CFL.COMMON_MESSAGE("!", oRs.Fields.Item(1).Value)


                Return False
            End If
            Return True
        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("TranSave " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Return False
        End Try
    End Function


    Public Function GetCOPLANT(Optional ByVal sCACD As String = "") As String

        Dim xSQL As String
        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim v_RTNVAL As String = ""
        Try
            xSQL = " SELECT COUNT(B.U_PLCD)"
            xSQL = xSQL & vbCrLf & " FROM [@WJS_SCO01M] AS A"
            xSQL = xSQL & vbCrLf & " INNER JOIN [@WJS_SCO011] AS B ON A.Code = B.Code"
            xSQL = xSQL & vbCrLf & " WHERE A.Code = CASE WHEN N'" & sCACD & "' = '' THEN A.Code ELSE '" & sCACD & "' END "
            xSQL = xSQL & vbCrLf & " AND B.U_USEYN = N'Y'"

#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If
            oRS.DoQuery(xSQL)

            If Not (oRS.EoF) Then

                If oRS.Fields.Item(0).Value > 1 Then
                    v_RTNVAL = ""
                Else

                    xSQL = "SELECT TOP 1 U_PLCD FROM [@WJS_SCO011] WHERE U_USEYN = 'Y'"
                    v_RTNVAL = CFL.GetValue(xSQL)
                End If

            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetCheckDate" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

        Return v_RTNVAL

    End Function


    ''' <summary>
    ''' 사업부권한에 따른 사업부 Combo 셋팅
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="oCombo"></param>
    ''' <param name="strComboValue"></param>
    ''' <param name="strUserId"></param>
    ''' <remarks></remarks>
    Public Sub SetBACDCombo(ByVal oForm As SAPbouiCOM.Form, ByVal oCombo As SAPbouiCOM.ComboBox, Optional ByVal strComboValue As String = "", Optional ByVal strUserId As String = "")
        Dim oRS As SAPbobsCOM.Recordset
        Dim xSQL As String = ""
        Dim iRow As Integer = 0
        Dim udfForm As SAPbouiCOM.Form
        Dim bComboEab As Boolean = True '콤보 Enable 값

        Dim xmldoc As Xml.XmlDocument
        Dim xnode As Xml.XmlNode
        Dim nodelist As Xml.XmlNodeList
        Dim strFocusItem As String = ""

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            If strUserId = "" Then strUserId = B1Connections.diCompany.UserSignature.ToString

            '기존에 사업부 콤보값과 사업부 정보의 사업부 수가 다르면 세로 콤보박스를 만든다.
            If (oCombo.ValidValues.Count - 1).ToString <> CFL.GetValue("SELECT COUNT(*) FROM [@WJS_SAD50M]") Then

                '기존콤보값 삭제
                For iRow = oCombo.ValidValues.Count - 1 To 0 Step -1
                    If iRow = 0 Then Exit For
                    oCombo.ValidValues.Remove(iRow, BoSearchKey.psk_Index)
                Next

                '첫행 공백 처리
                If oCombo.ValidValues.Count = 0 Then oCombo.ValidValues.Add("", "")

                '사업부 콤보값 세팅
                xSQL = "SELECT U_BACD, U_BANM FROM [@WJS_SAD50M] ORDER BY U_BACD, U_BANM"
                oRS.DoQuery(xSQL)

                For iRow = 0 To oRS.RecordCount - 1 Step 1
                    oCombo.ValidValues.Add(Trim(oRS.Fields.Item("U_BACD").Value), Trim(oRS.Fields.Item("U_BANM").Value))
                    oRS.MoveNext()
                Next

            End If

            '사업부권한 조회
            xSQL = "SELECT A.U_BACD, ISNULL(A.U_AUTHTP, 'N') AS U_AUTHTP FROM [@WJS_UAD08M_DSB] A LEFT OUTER JOIN [@WJS_SAD50M] B ON A.U_BACD = B.U_BACD WHERE U_USERID = '" & strUserId & "'"
            oRS.DoQuery(xSQL)

            '사업부 권한에 없는 유저는 전체 권한을 준다.
            If Not oRS.EoF Then

                '콤보기본값 세팅
                If Trim(strComboValue) = "" Then strComboValue = Trim(oRS.Fields.Item("U_BACD").Value)

                '콤보를 Disable처리할시 포커스가 콤보에 있으면 오류나는 부분을 처리 하기위해 Enable된 Edit값을 찾는 로직
                If Trim(oRS.Fields.Item("U_AUTHTP").Value) <> "Y" Then

                    '콤보 Enable 값
                    bComboEab = False

                    '폼 XML을 이용하여 포커스를 이동할 Item을 찾는다.
                    xmldoc = New Xml.XmlDocument()
                    xmldoc.LoadXml(oForm.GetAsXML())

                    '포커스를 줄 Item과 관계없는 Xml은 제거 한다.
                    xnode = xmldoc.SelectSingleNode("Application/forms/action/form/datasources")
                    If (Not xnode Is Nothing) Then
                        xnode.RemoveAll()
                    End If

                    xnode = xmldoc.SelectSingleNode("Application/forms/action/form/ChooseFromListCollection")
                    If (Not xnode Is Nothing) Then
                        xnode.RemoveAll()
                    End If

                    xnode = xmldoc.SelectSingleNode("Application/forms/action/form/DataBrowser")
                    If (Not xnode Is Nothing) Then
                        xnode.RemoveAll()
                    End If

                    xnode = xmldoc.SelectSingleNode("Application/forms/action/form/FormMenu")
                    If (Not xnode Is Nothing) Then
                        xnode.RemoveAll()
                    End If

                    nodelist = xmldoc.SelectNodes("Application/forms/action/form")

                    For Each xn As Xml.XmlNode In nodelist

                        '조회 화면은 사업부콤보를 활성화 시킨다.(ObjectType 값이 있는 걸로 구분)
                        If Trim(xn.Attributes("ObjectType").Value.ToString) = "-1" Or Trim(xn.Attributes("ObjectType").Value.ToString) = "" Then

                            '콤보 Enable 값
                            bComboEab = True
                            Exit For

                        End If

                    Next

                    '콤보박스를 비활성화 할때 포커스를 줄 Item을 찾는다.
                    If bComboEab = False Then

                        nodelist = xmldoc.SelectNodes("Application/forms/action/form/items/action/item")

                        For Each xn As Xml.XmlNode In nodelist

                            '타입이 EditBox이고 활성화 되어있는 Item을 찾는다.
                            If xn.Attributes("type").Value.ToString = "16" And xn.Attributes("visible").Value.ToString = "1" And xn.Attributes("enabled").Value.ToString = "1" Then

                                strFocusItem = xn.Attributes("uid").Value.ToString
                                Exit For

                            End If

                        Next

                    End If

                End If

            End If

            '콤보 기본값 선택
            If strComboValue <> "" Then

                oCombo.Select(strComboValue, BoSearchKey.psk_ByValue)

                If Not oForm.UniqueID.StartsWith("WJS_") And oForm.UDFFormUID <> "" Then
                    udfForm = B1Connections.theAppl.Forms.Item(oForm.UDFFormUID)
                    udfForm.Update()
                End If

            End If

            '커서를 옮긴 후 Disable 시킨다.
            If strFocusItem <> "" Then
                oForm.Items.Item(strFocusItem).Click()
            End If

            '콤보 Enable, Disable 처리
            oCombo.Item.Enabled = bComboEab
            oCombo.Item.DisplayDesc = True

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("SetBACDCombo " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
            udfForm = Nothing
        End Try

    End Sub


    Public Function FieldValueList(ByVal TableID As String, ByVal AliasID As String, _
        ByVal av_ip_s As String, ByVal av_dbname_s As String) As SAPbobsCOM.Recordset

        Dim xSQL As String

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        xSQL = "SELECT B.FldValue, B.Descr " & vbCrLf
        If av_ip_s = "" And av_dbname_s = "" Then
            xSQL = xSQL + " FROM CUFD A WITH(NOLOCK)  INNER JOIN UFD1 B  WITH(NOLOCK) ON A.TableId = B.TableID AND A.FieldID = B.FieldID" & vbCrLf
        Else
            xSQL = xSQL + " FROM [" & av_ip_s & "].[" & av_dbname_s & "].dbo.CUFD A  WITH(NOLOCK) "
            xSQL = xSQL & " INNER JOIN [" & av_ip_s & "].[" & av_dbname_s & "].dbo.UFD1 B  WITH(NOLOCK) ON A.TableId = B.TableID AND  A.FieldID = B.FieldID" & vbCrLf
        End If
        xSQL = xSQL + " WHERE A.TableID = N'" & TableID & "' AND A.AliasID = N'" & AliasID & "' " & vbCrLf
        xSQL = xSQL + " ORDER BY B.IndexID "

        oRs.DoQuery(xSQL)

        FieldValueList = oRs

        oRs = Nothing

    End Function

    Public Function GetMTPName(ByVal strMTPCD As String) As String

        Return CFL.GetValue("select U_MTPNM from [@WJS_SAD67M] where U_MTPCD = " + CFL.GetQD(strMTPCD))

    End Function

    Public Function GetMTPAcct(ByVal strMTPCD As String, ByVal strITEMCODE As String) As String

        'Return CFL.GetValue("select U_ACCTCD from [@WJS_SAD67M] where U_MTPCD = " + CFL.GetQD(strMTPCD) + " and U_PRECD = 'U' ")

        Dim xSQL As String
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        xSQL = ""
        xSQL = xSQL & " SELECT CASE WHEN ISNULL(A4.U_GACCTCD, '') <> '' THEN A4.U_GACCTCD "
        xSQL = xSQL & " 			 WHEN ISNULL(A3.U_ACCTCD, '') <> '' THEN A3.U_ACCTCD "
        xSQL = xSQL & " 			 ELSE U_GACCTCD END "
        xSQL = xSQL & " from	OITM AS A1 "
        xSQL = xSQL & " INNER JOIN OITB AS A2 ON A1.ItmsGrpCod = A2.ItmsGrpCod "
        xSQL = xSQL & " LEFT JOIN [@WJS_SAD67M] AS A3 ON A3.U_USEYN = 'Y' and A3.U_PRECD = 'U' AND A3.U_MTPCD = " + CFL.GetQD(strMTPCD)
        xSQL = xSQL & " LEFT JOIN [@WJS_SAD82M] AS A4 ON A3.U_MTPCD = A4.U_MTPCD AND A2.BalInvntAc = A4.U_SACCTCD "
        xSQL = xSQL & " where A1.ItemCode = " + CFL.GetQD(strITEMCODE)
        oRs.DoQuery(xSQL)

        Return oRs.Fields.Item(0).Value

    End Function

    Public Function ChkColumn(ByRef oMatrix As SAPbouiCOM.Matrix, ByVal pv_Col_s As String) As Boolean
        Dim i As Integer

        For i = 0 To oMatrix.Columns.Count - 1
            If (oMatrix.Columns.Item(i).UniqueID = pv_Col_s) Then
                ChkColumn = True
                Exit Function
            End If
        Next
        ChkColumn = False
    End Function
    Public Function ConFirmCHK(ByVal oForm As SAPbouiCOM.Form, _
                               ByVal type As String, _
                               ByVal FTYYMM As String, _
                               ByVal TOYYMM As String, _
                               Optional ByVal YN As String = "Y", _
                               Optional ByVal NoMSG As Boolean = False) As Boolean

        'Dim oDBDataH As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item(datatable)
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(BoObjectTypes.BoRecordset)
        Dim oStr As String = String.Empty
        ' @DOC varchar(max)
        ',@FRMM VARCHAR(6)
        ',@TOMM VARCHAR(6)
        ',@GB VARCHAR(1)
        Try
            oRs = B1Connections.diCompany.GetBusinessObject(BoObjectTypes.BoRecordset)
            oStr = " EXEC [WJS_SP_FIA90902] "
            oStr = oStr & "N'" & type & "', "
            oStr = oStr & "'" & FTYYMM & "', "
            oStr = oStr & "'" & TOYYMM & "', "
            oStr = oStr & "N'" & YN & "' "

            oRs.DoQuery(oStr)

            If oRs.Fields.Item(0).Value = "0" Then
                If Not NoMSG Then
                    CFL.COMMON_MESSAGE("!", oRs.Fields.Item(1).Value)
                End If

                Return False
            End If
            Return True

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ConFirmCHK " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            Return False
        End Try
    End Function
    Public Function ChkIfLive() As Boolean


        Dim xSQL As String = ""
        xSQL = " SELECT ISNULL( " _
                + " 	( " _
                + "     Select LIVE " _
                + " 	FROM WJSSY.dbo.WJSIFINFO  " _
                + " 	WHERE ERPDB = '" + B1Connections.diCompany.CompanyDB + "' " _
                + " ), 'N') AS LIVE "


        Return (CFL.GetValue(xSQL) = "Y")

    End Function


    Public Function GetCheckSelCnt(ByRef oGrid As SAPbouiCOM.Grid, ByVal strColumnID As String) As Integer
        Dim i As Integer = 0
        Dim boolSelected As Boolean = False
        Dim iSelCnt As Integer = 0

        For i = 0 To oGrid.Rows.Count - 1
            If oGrid.DataTable.GetValue(strColumnID, i) = "Y" Then
                iSelCnt = iSelCnt + 1
            End If
        Next

        Return iSelCnt

    End Function

    '암호화 관련 시작
    Public Sub WJSCRYPTO_CHECK_UDF()
        '사용자 정의 필드 Check
        If (Not B1Connections.theAppl.Menus.Item("6913").Checked) Then
            B1Connections.theAppl.Menus.Item("6913").Activate()
        End If
    End Sub

    Public Function WJSCRYPTO_PROCESS_CHECKAUTH() As String
        Dim rValue As String = ""
        '권한 체크 Process'

        Dim xSQL As String = String.Empty
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Try
            xSQL = "SELECT TOP 1"
            xSQL = xSQL & vbCrLf & " U_AUTH FROM [@WJS_SAD13T] "
            xSQL = xSQL & vbCrLf & " WHERE U_USERID = '" & B1Connections.diCompany.UserName & "'"
            oRs.DoQuery(xSQL) '권한 체크 Process 끝'
            rValue = oRs.Fields.Item("U_AUTH").Value
        Catch ex As Exception
            MsgBox(ex.ToString & "권한 체크 실패")
        Finally
            oRs = Nothing
        End Try

        Return rValue
    End Function

    Public Sub WJSCRYPTO_CHECK_Edit(ByVal OriginalFormID As Integer, ByVal FormID As Integer, ByVal CheckFormType As String, ByVal EditColNM As String, ByVal TypeCount As Integer, ByVal BindValue As String)
        '개인정보 취급자 외 개인정보 Data 변경 불가
        'Form, Grid, Matrix 별로 처리 하기 위해 Select Case를 통한 처리 및 Grid, Matrix Binding을 위해 Grid 혹은 Matrix Item 값을 파라미터로 받음
        Dim oForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(OriginalFormID, TypeCount)
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim Auth As String = "Y" '-- 권한부분 제외 'WJSCRYPTO_PROCESS_CHECKAUTH()
        If (Auth = "Y" Or String.IsNullOrEmpty(Auth)) Then
            Select Case CheckFormType
                Case "Form"
                    If (Not OriginalFormID = FormID) Then
                        Dim cForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(FormID, TypeCount)
                        cForm.Items.Item(EditColNM).Enabled = False
                    Else
                        'oForm.Items.Item(EditColNM).Enabled = False
                        Call oForm.Items.Item(EditColNM).SetAutoManagedAttribute(BoAutoManagedAttr.ama_Editable, BoAutoFormMode.afm_All, BoModeVisualBehavior.mvb_False)
                    End If
                Case "Grid"
                    Dim oGrid As SAPbouiCOM.Grid = oForm.Items.Item(BindValue).Specific
                    oGrid.Columns.Item(EditColNM).Editable = False
                Case "Matrix"
                    Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item(BindValue).Specific
                    oMatrix.Columns.Item(EditColNM).Editable = False
            End Select
        End If
    End Sub

    Public Function WJSCRYPTO_PROCESS_Encryption(ByVal OriginalFormID As Integer, ByVal FormID As Integer, ByVal CrytoColNM As String, ByVal TypeCount As Integer, ByVal PlainText As String, ByVal PKValue As String) As String

        '암호화 Process'
        Dim DbSrc As SAPbouiCOM.DBDataSource
        Dim xSQL As String = String.Empty
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(OriginalFormID, TypeCount)
        Dim Auth As String = String.Empty
        Dim rValue As String = ""

        Try
            WJSCRYPTO_PROCESS_Encryption = ""
            Auth = "YN" ' -- 권한제외 WJSCRYPTO_PROCESS_CHECKAUTH() '권한을 체크합니다.

            If (Auth = "YN" Or Auth = "N") Then

                xSQL = "SELECT TOP 1" 'Meta 테이블에서 암호화시 필요한 항목들을 가져 옵니다.
                xSQL = xSQL & vbCrLf & " U_Privacy, U_CrytoColNM, U_FormNM, U_Repo, U_RepoPK FROM [@WJS_SAD15M] "
                xSQL = xSQL & vbCrLf & " WHERE U_FormID = '" & OriginalFormID & "'"
                xSQL = xSQL & vbCrLf & " AND U_CrytoColNM = '" & CrytoColNM & "'"
                oRs.DoQuery(xSQL)
                DbSrc = oForm.DataSources.DBDataSources.Item(oRs.Fields.Item("U_Repo").Value)

                Select Case oRs.Fields.Item("U_Privacy").Value.ToString '개인 정보에 따라 해당 정보 토큰 암호화
                    Case "JMNO"
                        WJSCRYPTO_PROCESS_Encryption = WJSCRYPTO_JMNO(OriginalFormID, oRs.Fields.Item("U_Privacy").Value.ToString.Trim, oRs.Fields.Item("U_Repo").Value, PlainText, oRs.Fields.Item("U_FormNM").Value, oRs.Fields.Item("U_RepoPK").Value.ToString.Trim, PKValue)
                    Case "ACNO"
                        WJSCRYPTO_PROCESS_Encryption = WJSCRYPTO_ACNO(OriginalFormID, oRs.Fields.Item("U_Privacy").Value.ToString.Trim, oRs.Fields.Item("U_Repo").Value, PlainText, oRs.Fields.Item("U_FormNM").Value, oRs.Fields.Item("U_RepoPK").Value.ToString.Trim, PKValue)
                    Case "CRNO"
                        WJSCRYPTO_PROCESS_Encryption = WJSCRYPTO_CRNO(OriginalFormID, oRs.Fields.Item("U_Privacy").Value.ToString.Trim, oRs.Fields.Item("U_Repo").Value, PlainText, oRs.Fields.Item("U_FormNM").Value, oRs.Fields.Item("U_RepoPK").Value.ToString.Trim, PKValue)
                End Select
            Else
                B1Connections.theAppl.MessageBox("암호화 권한이 없습니다. 관리자에게 문의하시길 바랍니다.")
                Exit Try
            End If

            rValue = WJSCRYPTO_PROCESS_Encryption

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            oRs = Nothing
        End Try

        Return rValue
    End Function

    Public Function WJSCRYPTO_JMNO(ByVal FormID As Integer, _
                                      ByVal Privacy As String, _
                                      ByVal Repo As String, _
                                      ByVal Value As String, _
                                      ByVal FormNM As String, _
                                      ByVal PKName As String, _
                                      ByVal PKValue As String) As String

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRs2 As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = ""
        Dim strCryto As String = ""
        Dim strRegno As String = ""
        Dim strC5 As String = ""
        Dim strC8 As String = ""
        Dim strC9 As String = ""
        Dim strC10 As String = ""
        Dim strC11 As String = ""
        Dim strC12 As String = ""
        Dim strC13 As String = ""

        Dim upperbound As Integer = 3
        Dim lowerbound As Integer = 1
        Dim randomValue As Integer = 0

        Dim FixDigit5 As Integer = 0
        Dim FixDigit8 As Integer = 0
        Dim FixDigit9 As Integer = 0
        Dim FixDigit10 As Integer = 0
        Dim FixDigit11 As Integer = 0
        Dim FixDigit12 As Integer = 0
        Dim FixDigit13 As Integer = 0

        Dim ValueDigit5 As Integer = 0
        Dim ValueDigit8 As Integer = 0
        Dim ValueDigit9 As Integer = 0
        Dim ValueDigit10 As Integer = 0
        Dim ValueDigit11 As Integer = 0
        Dim ValueDigit12 As Integer = 0
        Dim ValueDigit13 As Integer = 0
        Dim iCount As Integer = 999

        Dim Type As String = String.Empty

        WJSCRYPTO_JMNO = ""


        Try


            strCryto = CFL.CryptoEncryption(Value)

            If strCryto = "" Then
                Exit Try
            Else

                xSQL = ""
                xSQL = "SELECT  TOP 1 Value  FROM  WJSSY.DBO.JMNO  WHERE  WJSCRYValue  =  '" & strCryto & "'"
                oRs2.DoQuery(xSQL)

                If Not oRs2.EoF Then
                    WJSCRYPTO_JMNO = oRs2.Fields.Item("Value").Value
                Else

                    ValueDigit5 = Value.Substring(4, 1)
                    ValueDigit8 = Value.Substring(7, 1)
                    ValueDigit9 = Value.Substring(8, 1)
                    ValueDigit10 = Value.Substring(9, 1)
                    ValueDigit11 = Value.Substring(10, 1)
                    ValueDigit12 = Value.Substring(11, 1)
                    ValueDigit13 = Value.Substring(12, 1)

                    Do While iCount = 999

                        Randomize()

                        randomValue = CInt(Math.Floor((upperbound - lowerbound + 1) * Rnd())) + lowerbound

                        If randomValue = 1 Then

                            FixDigit5 = 65      '대문자A
                            FixDigit8 = 66      '대문자B
                            FixDigit9 = 99      '소문자C
                            FixDigit10 = 48     '숫자2
                            FixDigit11 = 103    '소문자G
                            FixDigit12 = 109    '소문자M
                            FixDigit13 = 49     '숫자1

                        ElseIf randomValue = 2 Then

                            FixDigit5 = 90      '대문자Z
                            FixDigit8 = 67      '대문자C
                            FixDigit9 = 80      '대문자P
                            FixDigit10 = 97     '소문자A
                            FixDigit11 = 97     '소문자A
                            FixDigit12 = 97     '소문자A
                            FixDigit13 = 48     '숫자0

                        ElseIf randomValue = 3 Then

                            FixDigit5 = 66      '대문자B
                            FixDigit8 = 68      '대문자D
                            FixDigit9 = 80      '대문자P
                            FixDigit10 = 97     '소문자A
                            FixDigit11 = 97     '소문자A
                            FixDigit12 = 97     '소문자A
                            FixDigit13 = 49     '숫자1

                        Else
                            FixDigit5 = 67      '대문자C
                            FixDigit8 = 68      '대문자D
                            FixDigit9 = 80      '대문자P
                            FixDigit10 = 97     '소문자A
                            FixDigit11 = 97     '소문자A
                            FixDigit12 = 97     '소문자A
                            FixDigit13 = 49     '숫자1
                        End If

                        strC5 = Chr(FixDigit5)
                        strC8 = Chr(FixDigit8 + ValueDigit8)
                        strC9 = Chr(FixDigit9 + ValueDigit9)
                        strC10 = Chr(FixDigit10 + ValueDigit10)
                        strC11 = Chr(FixDigit11 + ValueDigit11)
                        strC12 = Chr(FixDigit12 + ValueDigit12)
                        strC13 = WJSCRYPTO_RAND("REGNO")

                        strRegno = Value.Substring(0, 4).ToString & strC5 & Value.Substring(5, 2) & strC8 & strC9 & strC10 & strC11 & strC12 & strC13

                        xSQL = "SELECT   1"
                        xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.JMNO "
                        xSQL = xSQL & vbCrLf & " WHERE  Value = '" & strRegno & "'"
                        oRs.DoQuery(xSQL)

                        If oRs.EoF Then
                            iCount = 1
                        Else
                            iCount = 999
                        End If

                    Loop
                    xSQL = "SELECT   1"
                    xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.JMNO "
                    xSQL = xSQL & vbCrLf & " WHERE  FormNM = '" & FormNM & "'"
                    xSQL = xSQL & vbCrLf & " AND RepoPKValue = '" & PKValue.Trim.ToString & "'"
                    oRs.DoQuery(xSQL)
                    If (Not oRs.EoF) Then
                        Type = "Update"
                    Else
                        Type = "Add"
                    End If
                    'strCryto = CFL.CryptoEncryption(Value)

                    If strCryto <> "" And strRegno <> "" Then
                        Select Case Type
                            Case "Add"
                                xSQL = ""
                                xSQL = "INSERT  INTO  WJSSY.DBO.JMNO (Privacy, FormID, FormNM, Repo, RepoPKName, RepoPKValue, Value, WJSCRYValue, CreateDate, UserCode, CompanyDBNM)"
                                xSQL = xSQL & vbCrLf & "SELECT  '" & Privacy & "' As Privacy ,  '" & FormID & "' As FormID, '" & FormNM & "' As FormNM, '" & Repo & "' As Repo"
                                xSQL = xSQL & vbCrLf & ", '" & PKName.ToString.Trim & "' As RepoPKName , '" & PKValue.ToString.Trim & "' As RepoPKValue"
                                xSQL = xSQL & vbCrLf & ", '" & strRegno & " ' AS Value , '" & strCryto & "'  AS  WJSCRYValue"
                                xSQL = xSQL & vbCrLf & ",  GETDATE() AS CreateDate"
                                xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.UserName & "'  AS  UserCode"
                                xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.CompanyDB & "'"

                            Case "Update"
                                xSQL = ""
                                xSQL = "Update WJSSY.DBO.JMNO "
                                xSQL = xSQL & vbCrLf & "SET Value =  '" & strRegno & "'"
                                xSQL = xSQL & vbCrLf & ", WJSCRYValue = '" & strCryto & "'"
                                xSQL = xSQL & vbCrLf & "WHERE FormNM = '" & FormNM & "'"
                                xSQL = xSQL & vbCrLf & "AND RepoPKValue = '" & PKValue.Trim & "'"
                        End Select
                        oRs.DoQuery(xSQL)
                        WJSCRYPTO_JMNO = strRegno
                    End If

                End If
            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("WJSCRYPTO_JMNO Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)

        Finally
            oRs = Nothing
            oRs2 = Nothing
        End Try

    End Function
    Public Function WJSCRYPTO_ACNO(ByVal FormID As Integer, _
                                       ByVal Privacy As String, _
                                       ByVal Repo As String, _
                                       ByVal Value As String, _
                                       ByVal FormNM As String, _
                                       ByVal PKName As String, _
                                       ByVal PKValue As String) As String


        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRs2 As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = ""
        Dim strCryto As String = ""

        Dim strAccno As String = ""
        Dim strC1 As String = ""
        Dim strC2 As String = ""
        Dim strC3 As String = ""
        Dim strC4 As String = ""
        Dim strC5 As String = ""
        Dim strC6 As String = ""
        Dim strC7 As String = ""
        Dim strC8 As String = ""
        Dim iCount As Integer = 999
        Dim iLength As Integer = 0

        Dim Type As String = String.Empty

        WJSCRYPTO_ACNO = ""


        Try

            strCryto = CFL.CryptoEncryption(Value)

            If strCryto = "" Then
                Exit Try
            Else

                xSQL = ""
                xSQL = "SELECT  TOP 1 Value  FROM  WJSSY.DBO.ACNO  WHERE  WJSCRYValue  =  '" & strCryto & "'"
                oRs2.DoQuery(xSQL)

                If Not oRs2.EoF Then
                    WJSCRYPTO_ACNO = oRs2.Fields.Item("Value").Value
                Else

                    Do While iCount = 999

                        strC1 = WJSCRYPTO_RAND("ACNO")
                        strC2 = WJSCRYPTO_RAND("ACNO")
                        strC3 = WJSCRYPTO_RAND("ACNO")
                        strC4 = WJSCRYPTO_RAND("ACNO")
                        strC5 = WJSCRYPTO_RAND("ACNO")
                        strC6 = WJSCRYPTO_RAND("ACNO")
                        strC7 = WJSCRYPTO_RAND("ACNO")
                        strC8 = WJSCRYPTO_RAND("ACNO")


                        strAccno = Value.Substring(0, 4).ToString & "EN" & strC1 & strC2 & strC3 & strC4 & strC5 & strC6 & strC7 & strC8

                        xSQL = "SELECT   1"
                        xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.JMNO "
                        xSQL = xSQL & vbCrLf & " WHERE  Value  = '" & strAccno & "'"
                        oRs.DoQuery(xSQL)

                        If oRs.EoF Then
                            iCount = 1
                        Else
                            iCount = 999
                        End If
                    Loop
                    xSQL = "SELECT   1"
                    xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.ACNO "
                    xSQL = xSQL & vbCrLf & " WHERE  FormNM = '" & FormNM & "'"
                    xSQL = xSQL & vbCrLf & " AND RepoPKValue = '" & PKValue.Trim & "'"
                    oRs.DoQuery(xSQL)
                    If (Not oRs.EoF) Then
                        Type = "Update"
                    Else
                        Type = "Add"
                    End If
                    'strCryto = CFL.CryptoEncryption(Value)

                    If strCryto <> "" And strAccno <> "" Then
                        Select Case Type
                            Case "Add"
                                xSQL = ""
                                xSQL = "INSERT  INTO  WJSSY.DBO.ACNO (Privacy, FormID, FormNM, Repo, RepoPKName, RepoPKValue, Value, WJSCRYValue, CreateDate, UserCode, CompanyDBNM)"
                                xSQL = xSQL & vbCrLf & "SELECT  '" & Privacy & "' As Privacy ,  '" & FormID & "' As FormID, '" & FormNM & "' As FormNM, '" & Repo & "' As Repo"
                                xSQL = xSQL & vbCrLf & ", '" & PKName.ToString.Trim & "' As RepoPKName , '" & PKValue.ToString.Trim & "' As RepoPKValue"
                                xSQL = xSQL & vbCrLf & ", '" & strAccno & " ' AS Value , '" & strCryto & "'  AS  WJSCRYValue"
                                xSQL = xSQL & vbCrLf & ",  GETDATE() AS CreateDate"
                                xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.UserName & "'  AS  UserCode"
                                xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.CompanyDB & "'"

                            Case "Update"
                                xSQL = ""
                                xSQL = "Update WJSSY.DBO.ACNO "
                                xSQL = xSQL & vbCrLf & "SET Value =  '" & strAccno & "'"
                                xSQL = xSQL & vbCrLf & ", WJSCRYValue = '" & strCryto & "'"
                                xSQL = xSQL & vbCrLf & "WHERE FormNM = '" & FormNM & "'"
                                xSQL = xSQL & vbCrLf & "AND RepoPKValue = '" & PKValue.Trim & "'"
                        End Select

                        oRs.DoQuery(xSQL)

                        WJSCRYPTO_ACNO = strAccno
                    End If
                End If
            End If



        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("WJSCRYPTO_ACNO Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
        Finally
            oRs = Nothing
            oRs2 = Nothing
        End Try


    End Function
    Public Function WJSCRYPTO_CRNO(ByVal FormID As Integer, _
                                   ByVal Privacy As String, _
                                   ByVal Repo As String, _
                                   ByVal Value As String, _
                                   ByVal FormNM As String, _
                                   ByVal PKName As String, _
                                   ByVal PKValue As String) As String


        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRs2 As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = ""
        Dim strCryto As String = ""

        Dim strAccno As String = ""
        Dim strC1 As String = ""
        Dim strC2 As String = ""
        Dim strC3 As String = ""
        Dim strC4 As String = ""
        Dim strC5 As String = ""
        Dim strC6 As String = ""
        Dim strC7 As String = ""
        Dim iCount As Integer = 999
        Dim iLength As Integer = 0

        Dim Type As String = String.Empty

        WJSCRYPTO_CRNO = ""


        Try

            strCryto = CFL.CryptoEncryption(Value)

            If strCryto = "" Then
                Exit Try
            Else

                xSQL = ""
                xSQL = "SELECT  TOP 1 Value  FROM  WJSSY.DBO.CRNO  WHERE  WJSCRYValue  =  '" & strCryto & "'"
                oRs2.DoQuery(xSQL)

                If Not oRs2.EoF Then
                    WJSCRYPTO_CRNO = oRs2.Fields.Item("Value").Value
                Else

                    Do While iCount = 999

                        strC1 = WJSCRYPTO_RAND("ACNO")
                        strC2 = WJSCRYPTO_RAND("ACNO")
                        strC3 = WJSCRYPTO_RAND("ACNO")
                        strC4 = WJSCRYPTO_RAND("ACNO")
                        strC5 = WJSCRYPTO_RAND("ACNO")
                        strC6 = WJSCRYPTO_RAND("ACNO")
                        strC7 = WJSCRYPTO_RAND("ACNO")


                        strAccno = Value.Substring(0, 7).ToString & "EN" & strC1 & strC2 & strC3 & strC4 & strC5 & strC6 & strC7

                        xSQL = "SELECT   1"
                        xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.CRNO "
                        xSQL = xSQL & vbCrLf & " WHERE  Value  = '" & strAccno & "'"
                        oRs.DoQuery(xSQL)

                        If oRs.EoF Then
                            iCount = 1
                        Else
                            iCount = 999
                        End If
                    Loop
                    xSQL = "SELECT   1"
                    xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.CRNO "
                    xSQL = xSQL & vbCrLf & " WHERE  FormNM = '" & FormNM & "'"
                    xSQL = xSQL & vbCrLf & " AND RepoPKValue = '" & PKValue.Trim & "'"
                    oRs.DoQuery(xSQL)
                    If (Not oRs.EoF) Then
                        Type = "Update"
                    Else
                        Type = "Add"
                    End If
                    'strCryto = CFL.CryptoEncryption(Value)

                    If strCryto <> "" And strAccno <> "" Then
                        Select Case Type
                            Case "Add"
                                xSQL = ""
                                xSQL = "INSERT  INTO  WJSSY.DBO.CRNO (Privacy, FormID, FormNM, Repo, RepoPKName, RepoPKValue, Value, WJSCRYValue, CreateDate, UserCode, CompanyDBNM)"
                                xSQL = xSQL & vbCrLf & "SELECT  '" & Privacy & "' As Privacy ,  '" & FormID & "' As FormID, '" & FormNM & "' As FormNM, '" & Repo & "' As Repo"
                                xSQL = xSQL & vbCrLf & ", '" & PKName.ToString.Trim & "' As RepoPKName , '" & PKValue.ToString.Trim & "' As RepoPKValue"
                                xSQL = xSQL & vbCrLf & ", '" & strAccno & " ' AS Value , '" & strCryto & "'  AS  WJSCRYValue"
                                xSQL = xSQL & vbCrLf & ",  GETDATE() AS CreateDate"
                                xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.UserName & "'  AS  UserCode"
                                xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.CompanyDB & "'"

                            Case "Update"
                                xSQL = ""
                                xSQL = "Update WJSSY.DBO.CRNO "
                                xSQL = xSQL & vbCrLf & "SET Value =  '" & strAccno & "'"
                                xSQL = xSQL & vbCrLf & ", WJSCRYValue = '" & strCryto & "'"
                                xSQL = xSQL & vbCrLf & "WHERE FormNM = '" & FormNM & "'"
                                xSQL = xSQL & vbCrLf & "AND RepoPKValue = '" & PKValue.Trim & "'"
                        End Select

                        oRs.DoQuery(xSQL)

                        WJSCRYPTO_CRNO = strAccno
                    End If
                End If
            End If



        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("WJSCRYPTO_CRNO Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
        Finally
            oRs = Nothing
            oRs2 = Nothing
        End Try


    End Function

    Public Sub WJSCRYPTO_PROCESS_Del(ByVal OriginalFormID As Integer, ByVal FormID As Integer, ByVal CrytoColNM As String, ByVal TypeCount As Integer, ByVal DelText As String, ByVal PKValue As String)
        '암호화 테이블 내 데이터 삭제
        Dim DbSrc As SAPbouiCOM.DBDataSource
        Dim xSQL As String = String.Empty
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim Auth As String = String.Empty
        Dim cForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(FormID, TypeCount)
        Dim oForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(OriginalFormID, TypeCount)
        Try
            xSQL = "SELECT TOP 1"
            xSQL = xSQL & vbCrLf & " U_Privacy, U_CrytoColNM, U_Repo, U_RepoPK FROM [@WJS_SAD15M] "
            xSQL = xSQL & vbCrLf & " WHERE U_FormID = '" & OriginalFormID & "'"
            xSQL = xSQL & vbCrLf & " AND U_CrytoColNM = '" & CrytoColNM & "'"
            oRs.DoQuery(xSQL)
            Dim Privacy As String = oRs.Fields.Item("U_Privacy").Value.ToString.Trim
            Select Case Privacy
                Case "JMNO"
                    Privacy = "주민등록번호"
                Case "ACNO"
                    Privacy = "계좌번호"
                Case "CRNO"
                    Privacy = "카드번호"
            End Select
            DbSrc = oForm.DataSources.DBDataSources.Item(oRs.Fields.Item("U_Repo").Value)
            Dim colNM As String = oRs.Fields.Item("U_CrytoColNM").Value
            Select Case oRs.Fields.Item("U_Privacy").Value.ToString
                Case "JMNO"
                    If (Not String.IsNullOrEmpty(cForm.Items.Item(oRs.Fields.Item("U_CrytoColNM").Value).Specific.Value.ToString)) Then
                        xSQL = "Delete"
                        xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.JMNO"
                        xSQL = xSQL & vbCrLf & " WHERE Value = '" & DelText & "'"
                        xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                        xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                        oRs.DoQuery(xSQL)
                    End If
                Case "ACNO"
                    xSQL = "DELETE"
                    xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.ACNO"
                    xSQL = xSQL & vbCrLf & " WHERE Value = '" & DelText & "'"
                    xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                    xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                    oRs.DoQuery(xSQL)
                Case "CRNO"
                    xSQL = "DELETE"
                    xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.CRNO"
                    xSQL = xSQL & vbCrLf & " WHERE Value = '" & DelText & "'"
                    xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                    xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                    oRs.DoQuery(xSQL)
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            oRs = Nothing
        End Try

    End Sub

    Public Sub WJSCRYPTO_PROCESS_Decryption(ByVal OriginalFormID As Integer, ByVal FormID As Integer, ByVal CrytoColNM As String, ByVal TypeCount As Integer, ByVal CipherText As String, ByVal PKValue As String)
        '복호화 Process'
        Dim DbSrc As SAPbouiCOM.DBDataSource
        Dim xSQL As String = String.Empty
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim Auth As String = String.Empty
        Dim cForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(FormID, TypeCount)
        Dim oForm As SAPbouiCOM.Form = B1Connections.theAppl.Forms.GetFormByTypeAndCount(OriginalFormID, TypeCount)
        Try
            Auth = "YN" '권한제외 WJSCRYPTO_PROCESS_CHECKAUTH()
            If (Auth = "YN" Or Auth = "Y") Then
                xSQL = "SELECT TOP 1"
                xSQL = xSQL & vbCrLf & " U_Privacy, U_CrytoColNM, U_Repo, U_RepoPK FROM [@WJS_SAD15M] "
                xSQL = xSQL & vbCrLf & " WHERE U_FormID = '" & OriginalFormID & "'"
                xSQL = xSQL & vbCrLf & " AND U_CrytoColNM = '" & CrytoColNM & "'"
                oRs.DoQuery(xSQL)
                Dim Privacy As String = oRs.Fields.Item("U_Privacy").Value.ToString.Trim
                Select Case Privacy
                    Case "JMNO"
                        Privacy = "주민등록번호"
                    Case "ACNO"
                        Privacy = "계좌번호"
                    Case "CRNO"
                        Privacy = "카드번호"
                End Select
                DbSrc = oForm.DataSources.DBDataSources.Item(oRs.Fields.Item("U_Repo").Value)
                Dim colNM As String = oRs.Fields.Item("U_CrytoColNM").Value
                Select Case oRs.Fields.Item("U_Privacy").Value.ToString
                    Case "JMNO"
                        If (Not String.IsNullOrEmpty(cForm.Items.Item(oRs.Fields.Item("U_CrytoColNM").Value).Specific.Value.ToString)) Then
                            xSQL = "SELECT WJSCRYValue"
                            xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.JMNO"
                            xSQL = xSQL & vbCrLf & " WHERE Value = '" & CipherText & "'"
                            xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                            xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                            oRs.DoQuery(xSQL)
                        End If
                    Case "ACNO"
                        xSQL = "SELECT WJSCRYValue"
                        xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.ACNO"
                        xSQL = xSQL & vbCrLf & " WHERE Value = '" & CipherText & "'"
                        xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                        xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                        oRs.DoQuery(xSQL)
                    Case "CRNO"
                        xSQL = "SELECT WJSCRYValue"
                        xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.CRNO"
                        xSQL = xSQL & vbCrLf & " WHERE Value = '" & CipherText & "'"
                        xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                        xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                        oRs.DoQuery(xSQL)
                End Select
                If Not oRs.EoF Then
                    B1Connections.theAppl.MessageBox("개인정보 ( " & Privacy & " )  복호화 된 값은 :   " & CFL.CryptoDecryption(oRs.Fields.Item("WJSCRYValue").Value.ToString))
                End If
            Else
                B1Connections.theAppl.MessageBox("복호화 권한이 없습니다.")
                Exit Try
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            oRs = Nothing
        End Try
    End Sub

    Public Function WJSCRYPTO_PROCESS_AllEncryption(ByVal Privacy As String, ByVal FormNM As String, ByVal PlainText As String, ByVal PKValue As String) As String
        '일괄암호화 Process'
        Dim xSQL As String = String.Empty
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim Auth As String = String.Empty
        Dim rValue As String = ""

        Try
            WJSCRYPTO_PROCESS_AllEncryption = ""
            Auth = "YN" '--권한제외 WJSCRYPTO_PROCESS_CHECKAUTH() '권한을 체크합니다.

            If (Auth = "YN" Or Auth = "N") Then

                xSQL = "SELECT TOP 1" 'Meta 테이블에서 암호화시 필요한 항목들을 가져 옵니다.
                xSQL = xSQL & vbCrLf & " U_FormID, U_CrytoColNM, U_Repo, U_RepoPK FROM [@WJS_SAD15M] "
                xSQL = xSQL & vbCrLf & " WHERE U_Privacy = '" & Privacy & "'"
                xSQL = xSQL & vbCrLf & " AND U_FormNM = '" & FormNM & "'"
                oRs.DoQuery(xSQL)

                Select Case Privacy '개인 정보에 따라 해당 정보 토큰 암호화
                    Case "JMNO"
                        WJSCRYPTO_PROCESS_AllEncryption = WJSCRYPTO_JMNO(oRs.Fields.Item("U_FormID").Value.ToString.Trim, Privacy, oRs.Fields.Item("U_Repo").Value, PlainText, FormNM, oRs.Fields.Item("U_RepoPK").Value.ToString.Trim, PKValue)
                    Case "ACNO"
                        WJSCRYPTO_PROCESS_AllEncryption = WJSCRYPTO_ACNO(oRs.Fields.Item("U_FormID").Value.ToString.Trim, Privacy, oRs.Fields.Item("U_Repo").Value, PlainText, FormNM, oRs.Fields.Item("U_RepoPK").Value.ToString.Trim, PKValue)
                    Case "CRNO"
                        WJSCRYPTO_PROCESS_AllEncryption = WJSCRYPTO_CRNO(oRs.Fields.Item("U_FormID").Value.ToString.Trim, Privacy, oRs.Fields.Item("U_Repo").Value, PlainText, FormNM, oRs.Fields.Item("U_RepoPK").Value.ToString.Trim, PKValue)
                End Select
            Else
                B1Connections.theAppl.MessageBox("암호화 권한이 없습니다. 관리자에게 문의하시길 바랍니다.")
                Exit Try
            End If

            rValue = WJSCRYPTO_PROCESS_AllEncryption
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return rValue
    End Function

    Public Function WJSCRYPTO_PROCESS_AllDecryption(ByVal Privacy As String, ByVal FormNM As String, ByVal CipherText As String, ByVal PKValue As String) As String
        '복호화 Process'
        Dim xSQL As String = String.Empty
        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim Auth As String = String.Empty
        Dim rValue As String = ""

        Try
            WJSCRYPTO_PROCESS_AllDecryption = ""
            Auth = "YN" '-- 권한제외 WJSCRYPTO_PROCESS_CHECKAUTH()
            If (Auth = "YN" Or Auth = "Y") Then
                xSQL = "SELECT TOP 1" 'Meta 테이블에서 암호화시 필요한 항목들을 가져 옵니다.
                xSQL = xSQL & vbCrLf & " U_FormID, U_CrytoColNM, U_Repo, U_RepoPK FROM [@WJS_SAD15M] "
                xSQL = xSQL & vbCrLf & " WHERE U_Privacy = '" & Privacy & "'"
                xSQL = xSQL & vbCrLf & " AND U_FormNM = '" & FormNM & "'"
                oRs.DoQuery(xSQL)
                Select Case Privacy
                    Case "JMNO"
                        xSQL = "SELECT WJSCRYValue"
                        xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.JMNO"
                        xSQL = xSQL & vbCrLf & " WHERE Value = '" & CipherText & "'"
                        xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                        xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                        oRs.DoQuery(xSQL)
                    Case "ACNO"
                        xSQL = "SELECT WJSCRYValue"
                        xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.ACNO"
                        xSQL = xSQL & vbCrLf & " WHERE Value = '" & CipherText & "'"
                        xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                        xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                        oRs.DoQuery(xSQL)
                    Case "CRNO"
                        xSQL = "SELECT WJSCRYValue"
                        xSQL = xSQL & vbCrLf & " FROM WJSSY.DBO.CRNO"
                        xSQL = xSQL & vbCrLf & " WHERE Value = '" & CipherText & "'"
                        xSQL = xSQL & vbCrLf & " AND Repo = '" & oRs.Fields.Item("U_Repo").Value & "'"
                        xSQL = xSQL & vbCrLf & " AND RepoPKName = '" & oRs.Fields.Item("U_RepoPK").Value & "'"
                        oRs.DoQuery(xSQL)
                End Select
                If Not oRs.EoF Then
                    WJSCRYPTO_PROCESS_AllDecryption = CFL.CryptoDecryption(oRs.Fields.Item("WJSCRYValue").Value.ToString)
                End If

                rValue = WJSCRYPTO_PROCESS_AllDecryption
            Else
                B1Connections.theAppl.MessageBox("복호화 권한이 없습니다.")
                Exit Try
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            oRs = Nothing
        End Try

        Return rValue
    End Function

    Public Function WJSCRYPTO_RAND(ByVal Field As String) As String
        '향후 Field 필드를 이용하여 난수 발생시 특이사항을 적용할 수 있도록 활용할 수 있다.

        Dim upperbound As Integer = 3
        Dim lowerbound As Integer = 1
        Dim randomValue As Integer = 0

        Dim upperbound_L_X As Integer = 90         '대문자 최고값(X ASCII)
        Dim lowerbound_L_X As Integer = 65         '대문자 최소값(A ASCII)
        Dim randomResult As Integer = 0            '대문자 랜덤값

        Dim upperbound_S_X As Integer = 122        '소문자 최고값(x ascii)
        Dim lowerbound_S_X As Integer = 97         '소문자 최소값(a ascii)

        Dim upperbound_9 As Integer = 57           '숫자 최고값 9
        Dim lowerbound_9 As Integer = 48           '숫자 최소값 0


        WJSCRYPTO_RAND = ""

        Try

            Randomize()

            randomValue = CInt(Math.Floor((upperbound - lowerbound + 1) * Rnd())) + lowerbound          '대문자,소문자, 숫자를 결정한다.

            If randomValue = 1 Then         '대문자
                randomResult = CInt(Math.Floor((upperbound_L_X - lowerbound_L_X + 1) * Rnd())) + lowerbound_L_X

            ElseIf randomValue = 2 Then     '소문자
                randomResult = CInt(Math.Floor((upperbound_S_X - lowerbound_S_X + 1) * Rnd())) + lowerbound_S_X

            Else                            '숫자
                randomResult = CInt(Math.Floor((upperbound_9 - lowerbound_9 + 1) * Rnd())) + lowerbound_9
            End If


            WJSCRYPTO_RAND = Chr(randomResult)


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("WJSCRYPTO_RAND Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)

        Finally

        End Try


    End Function

    '암화과 관련 끝


    ''' <summary>
    ''' ChkExtUserDataSource
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="strUid"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ChkExtUserDataSource(ByRef oForm As SAPbouiCOM.Form, ByVal strUid As String) As Boolean


        Dim i As Integer = 0
        Dim xmlAtt As Xml.XmlAttribute
        Dim xmlDoc As Xml.XmlDocument = New Xml.XmlDocument()
        xmlDoc.LoadXml(oForm.GetAsXML())

        For Each node As XmlNode In xmlDoc.SelectNodes("Application/forms/action/form/datasources/userdatasources/action/datasource")
            xmlAtt = node.Attributes.ItemOf("uid")
            If (Not xmlAtt Is Nothing) Then
                If (xmlAtt.InnerText = strUid) Then
                    Return True
                End If
            End If
        Next

        Return False

    End Function


    ''' <summary>
    ''' GetParentForm
    ''' </summary>
    ''' <param name="strParentFormUid"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetParentForm(ByVal strParentFormUid As String) As SAPbouiCOM.Form

        Dim i As Integer

        For i = 0 To B1Connections.theAppl.Forms.Count - 1
            If (B1Connections.theAppl.Forms.Item(i).UniqueID = strParentFormUid) Then
                Return B1Connections.theAppl.Forms.Item(i)
            End If
        Next

        Return Nothing

    End Function


    ''' <summary>
    ''' GetUserText
    ''' </summary>
    ''' <param name="strItemCode"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetUserText(ByVal strItemCode As String) As String
        Dim strUserText As String = ""

        Try

            strUserText = CFL.GetValue("SELECT IFNULL(A.""UserText"", '') FROM OITM A WHERE A.""ItemCode"" = '" & Trim(strItemCode) & "' ")

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetUserText : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
        End Try

        Return strUserText
    End Function


#Region "KillExcel"
    Public Sub KillExcel(ByVal pintHandle As IntPtr)
        Dim intResult As Long
        Try
            'this will perform the end task activity whereby it will release the excel process from the task manager.
            intResult = EndTask(pintHandle)
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' 엑셀 프로세스 삭제
    ''' </summary>
    ''' <param name="obj"></param>
    ''' <remarks></remarks>
    Public Sub KillExcel2(ByVal ParamArray obj() As Object)
        For Each gobj As Object In obj
            System.Runtime.InteropServices.Marshal.ReleaseComObject(gobj)
        Next

    End Sub

    Public Declare Function EndTask Lib "user32.dll" Alias "EndTask" (ByVal hwnd As Long) As Long
    Public Declare Function FindWindow Lib "user32.dll" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr
#End Region


    Public _WJSIFDBNAME As String = "WJSIF"
    Public _WJSSYDBNAME As String = "WJSSY"

    Public Function FConvertDT(ByVal sdata As String) As Date
        ' sdata 는 8 자리로 넘어와야 한다. 20140201
        Dim dt As Date
        Dim iYYYY, iMM, iDD As Integer

        iYYYY = Int32.Parse(sdata.Substring(0, 4))
        iMM = Int32.Parse(sdata.Substring(4, 2))
        iDD = Int32.Parse(sdata.Substring(6, 2))

        dt = New Date(iYYYY, iMM, iDD)

        Return dt

    End Function

    Public boolStartEndProgress As Boolean = True
    Private Delegate Sub mydDbLong(ByVal oForm As SAPbouiCOM.Form, ByVal msg As String)


    Public Sub dDbLong(ByVal oForm As SAPbouiCOM.Form, ByVal msg As String)
        boolStartEndProgress = True
        Dim tb As New mydDbLong(AddressOf DbLongEvent)
        tb.BeginInvoke(oForm, msg, Nothing, Nothing)
    End Sub

    Private Sub DbLongEvent(ByVal oForm As SAPbouiCOM.Form, ByVal msg As String)


        Dim IProgress As Integer = 1

        Dim strMSG As String = String.Empty

        Do While boolStartEndProgress

            System.Threading.Thread.Sleep(500)

            Select Case Microsoft.VisualBasic.Right(IProgress.ToString, 1)
                Case "1"
                    strMSG = "."
                Case "2"
                    strMSG = ".."
                Case "3"
                    strMSG = "..."
                Case "4"
                    strMSG = "...."
                Case "5"
                    strMSG = "....."
                Case "6"
                    strMSG = "......"
                Case "7"
                    strMSG = "......."
                Case "8"
                    strMSG = "........"
                Case "9"
                    strMSG = "........."
                Case "0"
                    strMSG = ".........."


            End Select
            B1Connections.theAppl.StatusBar.SetText(msg & strMSG, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning) '데이터 조회중입니다

            IProgress += 1
        Loop






    End Sub

    Public Function GetKeyValueStringData(ByVal key As String, ByVal value As String) As String
        Dim cv_url_s As String

        cv_url_s = key & "=" & value

        Return cv_url_s

    End Function

    Public Sub gotoSite(ByVal url As String)
        Dim sInfo = New ProcessStartInfo(url)
        Process.Start(sInfo)

    End Sub


    ''' <summary>
    ''' 그리스 수량,금액,가격,비율 등의 소숫점 SBO기준 셋팅
    ''' </summary>
    ''' <param name="oGrid"></param>
    ''' <param name="strColQty"></param>
    ''' <param name="strColAmt"></param>
    ''' <param name="strColPrc"></param>
    ''' <param name="strColRate"></param>
    ''' <remarks></remarks>
    Public Sub SetGrdColumnNumber1(ByRef oGrid As SAPbouiCOM.Grid, ByVal strColQty As String, ByVal strColAmt As String, _
        ByVal strColPrc As String, ByVal strColRate As String, ByVal strColPercent As String, ByVal strColMesure As String)

        Dim xMLDoc As Xml.XmlDocument = New Xml.XmlDocument()
        xMLDoc.LoadXml(oGrid.DataTable.SerializeAsXML(BoDataTableXmlSelect.dxs_All))
        Dim arrColQty As ArrayList = New ArrayList()
        If (Not strColQty Is Nothing) Then arrColQty.AddRange(strColQty.Replace(" ", "").Split(",")) '수량
        Dim arrColAmt As ArrayList = New ArrayList()
        If (Not strColAmt Is Nothing) Then arrColAmt.AddRange(strColAmt.Replace(" ", "").Split(",")) '금액
        Dim arrColPrc As ArrayList = New ArrayList()
        If (Not strColPrc Is Nothing) Then arrColPrc.AddRange(strColPrc.Replace(" ", "").Split(",")) '단가
        Dim arrColRate As ArrayList = New ArrayList()
        If (Not strColRate Is Nothing) Then arrColRate.AddRange(strColRate.Replace(" ", "").Split(",")) '비율
        Dim arrColPercent As ArrayList = New ArrayList()
        If (Not strColPercent Is Nothing) Then arrColPercent.AddRange(strColPercent.Replace(" ", "").Split(",")) '%
        Dim arrColMessure As ArrayList = New ArrayList()
        If (Not strColMesure Is Nothing) Then arrColMessure.AddRange(strColMesure.Replace(" ", "").Split(",")) '단위

        For Each node As XmlNode In xMLDoc.GetElementsByTagName("Column")
            If (arrColQty.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Quantity
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColAmt.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Sum
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColPrc.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Price
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColRate.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Rate
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColPercent.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Percent
                node.Attributes("MaxLength").InnerText = "0"
            ElseIf (arrColMessure.Contains(node.Attributes("Uid").InnerText)) Then
                node.Attributes("Type").InnerText = BoFieldsType.ft_Measure
                node.Attributes("MaxLength").InnerText = "0"
            End If

        Next
        oGrid.DataTable.LoadSerializedXML(BoDataTableXmlSelect.dxs_All, xMLDoc.InnerXml)

        If (ExistsColGrid(oGrid, "RowsHeader")) Then
            oGrid.Columns.Item("RowsHeader").Width = 20
        End If


    End Sub

    Public Function fnGetBatchInfo(ByVal strItemCode As String, ByVal strWhsCode As String, ByVal dcmQuantity As Decimal) As System.Data.DataTable

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = String.Empty
        Dim dcmOut As Decimal = 0
        Dim dcmCal As Decimal = 0
        Dim dcmTotal As Decimal = 0
        Dim dr As System.Data.DataRow
        Dim dtRet As New System.Data.DataTable
        dtRet.Columns.Add("DistNumber")
        dtRet.Columns.Add("Quantity")

        Try

            'xSQL = ""
            'xSQL = xSQL & vbCrLf & "SELECT "
            'xSQL = xSQL & vbCrLf & "A.""DistNumber"" , B.""ItemCode"", B.""SysNumber"" , B.""WhsCode"", B.""Quantity"""
            'xSQL = xSQL & vbCrLf & "FROM OBTN AS A"
            'xSQL = xSQL & vbCrLf & "INNER JOIN OBTQ AS B ON A.""ItemCode"" = B.""ItemCode"" AND A.""SysNumber"" = B.""SysNumber"""
            'xSQL = xSQL & vbCrLf & "WHERE B.""ItemCode"" = '{0}'"
            'xSQL = xSQL & vbCrLf & "AND B.""WhsCode"" = '{1}'"
            'xSQL = xSQL & vbCrLf & "ORDER BY A.""InDate"", A.""DistNumber"", B.""SysNumber"" "

            xSQL = String.Format("CALL WJS_SP_MMF9999F_CKH('{0}','{1}')", strItemCode, strWhsCode)
            oRs.DoQuery(xSQL)
            If Not oRs.EoF Then

                dcmTotal = dcmQuantity

                For i As Integer = 0 To oRs.RecordCount - 1
                    dr = dtRet.NewRow()
                    dr("DistNumber") = oRs.Fields.Item("DistNumber").Value
                    Decimal.TryParse(oRs.Fields.Item("Quantity").Value.ToString.Trim, dcmOut)
                    If dcmOut >= dcmTotal Then
                        dr("Quantity") = dcmTotal
                        dtRet.Rows.Add(dr)
                        Exit For
                    Else
                        dr("Quantity") = dcmOut.ToString()
                        dtRet.Rows.Add(dr)
                        dcmTotal = dcmTotal - dcmOut
                    End If
                    oRs.MoveNext()
                Next

            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("Error " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try

        Return dtRet
    End Function

    '판매오더 배치 품목 2개 라인 이상건 처리를 위해 추가 181030 LJK
    '(문제가 발생한 OMS 주문확정에만 우선 적용함 : HELP 요청번호 151-00136)
    '취소할 땐 재고이전을 취소하지만 배치를 이미 사용했을 경우 역재고이전을 만드는데, 그 때도 라인이 2개일 수 있으므로 CRTP(A:추가,C:취소)로 구분 처리될 수 있도록 수정 190212 LJK
    '(OMS 주문확정 취소에 적용 : HELP 요청번호 151-00416)
    Public Function fnGetBatchInfo(ByVal strItemCode As String, ByVal strWhsCode As String, ByVal dcmQuantity As Decimal, ByVal strDocEntry As String, ByVal strCRTP As String) As System.Data.DataTable

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = String.Empty
        Dim dcmOut As Decimal = 0
        Dim dcmCal As Decimal = 0
        Dim dcmTotal As Decimal = 0
        Dim dr As System.Data.DataRow
        Dim dtRet As New System.Data.DataTable
        dtRet.Columns.Add("DistNumber")
        dtRet.Columns.Add("Quantity")

        Try

            xSQL = String.Format("CALL WJS_SP_MMF9998F_CKH('{0}','{1}','{2}','{3}');", strItemCode, strWhsCode, strDocEntry, strCRTP)
            oRs.DoQuery(xSQL)
            If Not oRs.EoF Then

                dcmTotal = dcmQuantity

                For i As Integer = 0 To oRs.RecordCount - 1
                    dr = dtRet.NewRow()
                    dr("DistNumber") = oRs.Fields.Item("DistNumber").Value
                    Decimal.TryParse(oRs.Fields.Item("Quantity").Value.ToString.Trim, dcmOut)
                    If dcmOut >= dcmTotal Then
                        dr("Quantity") = dcmTotal
                        dtRet.Rows.Add(dr)
                        Exit For
                    Else
                        dr("Quantity") = dcmOut.ToString()
                        dtRet.Rows.Add(dr)
                        dcmTotal = dcmTotal - dcmOut
                    End If
                    oRs.MoveNext()
                Next

            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("Error " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try

        Return dtRet
    End Function

    Public Function fnGetBatchInfo(ByVal strItemCode As String, ByVal strWhsCode As String, ByVal dcmQuantity As Decimal, ByVal dtOccupy As System.Data.DataTable) As System.Data.DataTable

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = String.Empty
        Dim dcmOut As Decimal = 0
        Dim dcmCal As Decimal = 0
        Dim dcmTotal As Decimal = 0
        Dim dr As System.Data.DataRow

        Dim dtSet As New System.Data.DataTable
        dtSet.Columns.Add("DistNumber")
        dtSet.Columns.Add("Quantity")

        Dim dtRet As New System.Data.DataTable
        dtRet.Columns.Add("DistNumber")
        dtRet.Columns.Add("Quantity")

        Try

            'xSQL = ""
            'xSQL = xSQL & vbCrLf & "SELECT "
            'xSQL = xSQL & vbCrLf & "A.""DistNumber"" , B.""ItemCode"", B.""SysNumber"" , B.""WhsCode"", B.""Quantity"""
            'xSQL = xSQL & vbCrLf & "FROM OBTN AS A"
            'xSQL = xSQL & vbCrLf & "INNER JOIN OBTQ AS B ON A.""ItemCode"" = B.""ItemCode"" AND A.""SysNumber"" = B.""SysNumber"""
            'xSQL = xSQL & vbCrLf & "WHERE B.""ItemCode"" = '{0}'"
            'xSQL = xSQL & vbCrLf & "AND B.""WhsCode"" = '{1}'"
            'xSQL = xSQL & vbCrLf & "ORDER BY A.""InDate"", A.""DistNumber"", B.""SysNumber"" "

            xSQL = String.Format("CALL WJS_SP_MMF9999F_CKH('{0}','{1}')", strItemCode, strWhsCode)
            oRs.DoQuery(xSQL)
            If Not oRs.EoF Then


                For i As Integer = 0 To oRs.RecordCount - 1
                    dr = dtSet.NewRow()
                    dr("DistNumber") = oRs.Fields.Item("DistNumber").Value
                    Decimal.TryParse(oRs.Fields.Item("Quantity").Value.ToString.Trim, dcmOut)
                    dr("Quantity") = dcmOut.ToString()
                    dtSet.Rows.Add(dr)
                    oRs.MoveNext()
                Next
                dtSet.AcceptChanges()
                '미리 선점된 데이터를 차감 ..


                For Each drOccupy As System.Data.DataRow In dtOccupy.Select(String.Format("ItemCode ='{0}' AND WhsCd ='{1}'", strItemCode, strWhsCode))
                    For Each drSet As System.Data.DataRow In dtSet.Select(String.Format("DistNumber ='{0}'", drOccupy("DistNumber")))

                        Dim dblSet As Double
                        Dim dblOcc As Double
                        If Double.TryParse(drSet("Quantity").ToString(), dblSet) And Double.TryParse(drOccupy("Quantity").ToString(), dblOcc) Then

                            If dblSet <= dblOcc Then
                                drSet.Delete()
                            Else
                                drSet("Quantity") = dblSet - dblOcc
                            End If
                            drSet.AcceptChanges()
                        End If
                    Next
                Next


                dcmTotal = dcmQuantity

                For i As Integer = 0 To dtSet.Rows.Count - 1
                    dr = dtRet.NewRow()
                    dr("DistNumber") = dtSet.Rows(i)("DistNumber") ' oRs.Fields.Item("DistNumber").Value
                    Decimal.TryParse(dtSet.Rows(i)("Quantity").ToString.Trim, dcmOut)
                    If dcmOut >= dcmTotal Then
                        dr("Quantity") = dcmTotal
                        dtRet.Rows.Add(dr)
                        Exit For
                    Else
                        dr("Quantity") = dcmOut.ToString()
                        dtRet.Rows.Add(dr)
                        dcmTotal = dcmTotal - dcmOut
                    End If
                Next

            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("Error " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try

        Return dtRet
    End Function

    '// 파일의 읽기전용 속성 변경
    Public Sub SetReadonly(ByVal sFileName As String, ByVal bReadOnly As Boolean)
        Dim fileInfo As System.IO.FileInfo
        fileInfo = New System.IO.FileInfo(sFileName)

        If fileInfo.IsReadOnly <> bReadOnly Then
            fileInfo.IsReadOnly = bReadOnly
        End If

        fileInfo = Nothing

    End Sub

    Public Function GetFileFromBrowser(Optional ByVal pOption As String = "") As String
        Dim strFileName As String = ""
        Dim oDIVersion As String = ""
        Dim oOptMsg As String = ""
        Dim oFinalMsg As String = ""
        Dim oOption() As String

        Dim i As Integer

        Try

            pOption = UCase(pOption)
            oOption = Split(pOption, ",")

            For i = LBound(oOption) To UBound(oOption)
                If Trim(oOption(i)) = "ALL" Then
                    oOptMsg = ""
                    Exit For '전체 파일이면 끝...
                ElseIf Trim(oOption(i)) = "XLS" Then
                    oOptMsg = "excel files (*.xls)|*.xls"
                ElseIf Trim(oOption(i)) = "XLSX" Then
                    oOptMsg = "excel files (*.xlsx)|*.xlsx"
                ElseIf Trim(oOption(i)) = "TXT" Then
                    oOptMsg = "Text (tab-seperated)|*.txt"
                ElseIf Trim(oOption(i)) = "CSV" Then
                    oOptMsg = "CSV (comma-seperated)|*.csv"
                ElseIf Trim(oOption(i)) = "JPG" Then
                    oOptMsg = "JPG files (*.jpg)|*.jpg"
                ElseIf Trim(oOption(i)) = "BMP" Then
                    oOptMsg = "BMP files (*.bmp)|*.bmp"
                End If
                oFinalMsg = IIf(oFinalMsg = "", oFinalMsg & oOptMsg, oFinalMsg & "|" & oOptMsg)

            Next i

#If DIVERSION = "92" Then
            If B1Connections.theAppl.ClientType = SAPbouiCOM.BoClientType.ct_Browser Then
                strFileName = B1Connections.theAppl.GetFileFromBrowser()
            Else
                If oOptMsg = "" Then
                    strFileName = CFL.FileDialog(eFileDialog.en_OpenFile, True)
                Else
                    strFileName = CFL.FileDialog(eFileDialog.en_OpenFile, oFinalMsg, True)
                End If
            End If
#Else
            If oOptMsg = "" Then
                strFileName = CFL.FileDialog(eFileDialog.en_OpenFile, True)
            Else
                strFileName = CFL.FileDialog(eFileDialog.en_OpenFile, oFinalMsg, True)
            End If
#End If

        Catch ex As Exception
            If Err.Number <> -10 Then
                B1Connections.theAppl.StatusBar.SetText("GetFileFromBrowser Error : " & Err.Number & " " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
            End If
        End Try

        Return strFileName

    End Function

    Public Function WPIN1_JMNOCHK(ByVal JuminNo As String) As Boolean

        Dim oRs As SAPbobsCOM.Recordset

        Dim cv_GBN_s As String = ""

        Dim xSQL As String = ""
        Dim i As Integer = 0
        Dim cv_Gubun_s() As String
        Dim cv_Gubun1_i As Integer = 0

        Try

            oRs = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            WPIN1_JMNOCHK = False

            '기초데이터 가져오기
#If HANA = "Y" Then
            xSQL = "SELECT IFNULL(U_RMK4, '') AS ""U_RMK4"" FROM ""@WJS_SAD011"" WHERE ""Code"" = 'HR101' AND U_SMLCD = 'U01'"
#Else
            xSQL = "SELECT	ISNULL(U_RMK4,'') AS U_RMK4" & vbCrLf
            xSQL = xSQL & "FROM	[@WJS_SAD011]" & vbCrLf
            xSQL = xSQL & "WHERE	CODE	= 'HR101'" & vbCrLf
            xSQL = xSQL & "AND		U_SMLCD	= 'U01'"
#End If
            oRs.DoQuery(xSQL)

            cv_GBN_s = oRs.Fields.Item("U_RMK4").Value
            cv_Gubun_s = Split(cv_GBN_s, ",")

            '암호화된 데이터인지 검사
            For i = cv_Gubun_s.GetLowerBound(0) To cv_Gubun_s.GetUpperBound(0)
                cv_Gubun1_i = InStr(Left(JuminNo, 6), cv_Gubun_s(i))

                If cv_Gubun1_i > 0 Then
                    Exit For
                End If
            Next

            If cv_Gubun1_i > 0 Then
                WPIN1_JMNOCHK = True
            End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("WPIN1_JMNOCHK Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)

        Finally

            oRs = Nothing

        End Try

    End Function

    Public Function WPIN1_JMNO(ByVal EncryptionYN As Boolean, ByVal JuminNo As String, Optional ByVal Accessurl As String = "", Optional ByVal Empno As String = "") As String

        '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        '// 함 수 명: WPIN1_JMNO
        '// 수정내역: 
        '//------------------------------------------------------------------------------------------------------------------
        '// 2014.03.20 -  코웨이복호화 함수 변경에 따른 파라미터 Accessurl 추가 및 ConnWPinWebCOWAY 연결
        '// 2017.03.14 -  표준암호화 사용시 공통코드 HR101 코드 셋팅의 사용유무에 따라서 암호화 처리하도록 수정
        '// 2018.03.16 -  웅진컴퍼스  B1인사모듈 사이트코드 : 2036 적용
        '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Dim oRs As SAPbobsCOM.Recordset

        Dim cv_Server_s As String = ""
        Dim cv_ENCFunNm_s As String = ""
        Dim cv_DECFunNm_s As String = ""
        Dim cv_FLDNm_s As String = ""
        Dim cv_DelGubun() As String = Nothing
        Dim xSQL As String = ""
        Dim iLooper As Integer = 0
        Dim cv_Sitecode_s As String = ""          '사이트코드
        Dim cv_USEYN As String = "N"              '사용여부 
        Dim cv_Company_s As String = ""           '회사코드


        Try

            oRs = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            WPIN1_JMNO = ""

#If HANA = "Y" Then
            xSQL = "SELECT IFNULL(U_SECURITY,'S00') AS U_SECURITY FROM ""@WJS_SHR01M"" "
#Else
            xSQL = "SELECT ISNULL(U_SECURITY,'S00') AS U_SECURITY FROM [@WJS_SHR01M]"
#End If
            oRs.DoQuery(xSQL)


            If oRs.Fields.Item("U_SECURITY").Value = "S01" Then

                '기초데이터 가져오기
#If HANA = "Y" Then
                xSQL = "SELECT	U_SMLCD, " & vbCrLf
                xSQL = xSQL & "     IFNULL(CAST(U_RMK1 AS nvarchar(200)), '') AS ""U_RMK1"", " & vbCrLf
                xSQL = xSQL & "     IFNULL(CAST(U_RMK2 AS nvarchar(200)), '') AS ""U_RMK2"", " & vbCrLf
                xSQL = xSQL & "     IFNULL(CAST(U_RMK3 AS nvarchar(200)), '') AS ""U_RMK3"", " & vbCrLf
                xSQL = xSQL & "     IFNULL(CAST(U_RMK5 AS nvarchar(200)), '') AS ""U_RMK5"" " & vbCrLf
                xSQL = xSQL & "FROM ""@WJS_SAD011""" & vbCrLf
                xSQL = xSQL & "WHERE ""Code"" = 'HR101'" & vbCrLf
                xSQL = xSQL & "AND  U_SMLCD IN ('U00','U01') "
#Else
                xSQL = "SELECT	U_SMLCD," & vbCrLf
                xSQL = xSQL & "		ISNULL(CAST(U_RMK1 AS NVARCHAR(200)),'') AS U_RMK1," & vbCrLf
                xSQL = xSQL & "		ISNULL(CAST(U_RMK2 AS NVARCHAR(200)),'') AS U_RMK2," & vbCrLf
                xSQL = xSQL & "		ISNULL(CAST(U_RMK3 AS NVARCHAR(200)),'') AS U_RMK3," & vbCrLf
                xSQL = xSQL & "		ISNULL(CAST(U_RMK5 AS NVARCHAR(200)),'') AS U_RMK5 " & vbCrLf
                xSQL = xSQL & "FROM	[@WJS_SAD011]" & vbCrLf
                xSQL = xSQL & "WHERE	CODE	= 'HR101'" & vbCrLf
                xSQL = xSQL & "AND		U_SMLCD	IN ('U00', 'U01')"
#End If
                oRs.DoQuery(xSQL)

                For iLooper = 1 To oRs.RecordCount

                    Select Case oRs.Fields.Item("U_SMLCD").Value

                        Case "U00"  '서버

                            cv_Server_s = oRs.Fields.Item("U_RMK1").Value
                            cv_Sitecode_s = oRs.Fields.Item("U_RMK2").Value      '사이트코드
                            cv_Company_s = oRs.Fields.Item("U_RMK3").Value       '회사코드(2017.03.29) 추가

                        Case "U01"  '주민번호

                            cv_ENCFunNm_s = oRs.Fields.Item("U_RMK1").Value
                            cv_DECFunNm_s = oRs.Fields.Item("U_RMK2").Value
                            cv_FLDNm_s = oRs.Fields.Item("U_RMK3").Value
                            cv_DelGubun = Split(oRs.Fields.Item("U_RMK5").Value, ",")

                    End Select

                    oRs.MoveNext()

                Next

                If EncryptionYN = True Then
                    For iLooper = cv_DelGubun.GetLowerBound(0) To cv_DelGubun.GetUpperBound(0)
                        JuminNo = Replace(JuminNo, cv_DelGubun(iLooper), "")
                    Next
                End If


                If cv_Sitecode_s = "1548" Then          '코웨이
                    WPIN1_JMNO = ConnWPinWebCOWAY(cv_Server_s, IIf(EncryptionYN, cv_ENCFunNm_s, cv_DECFunNm_s), cv_FLDNm_s, JuminNo, cv_Sitecode_s, EncryptionYN, Accessurl)

                ElseIf cv_Sitecode_s = "2036" Then      '웅진컴퍼스 B1
                    WPIN1_JMNO = ConnWPinWebThinkBig(cv_Server_s, IIf(EncryptionYN, cv_ENCFunNm_s, cv_DECFunNm_s), cv_FLDNm_s, JuminNo, cv_Sitecode_s, EncryptionYN, Accessurl)

                ElseIf cv_Sitecode_s = "1802" Or cv_Sitecode_s = "1804" Then      '릴리에뜨 B1, 플레이도시
                    WPIN1_JMNO = ConnWPinWebGroup(cv_Server_s, IIf(EncryptionYN, cv_ENCFunNm_s, cv_DECFunNm_s), cv_FLDNm_s, JuminNo, cv_Sitecode_s, EncryptionYN, Accessurl, cv_Company_s)

                Else
                    WPIN1_JMNO = ConnWPinWeb(cv_Server_s, IIf(EncryptionYN, cv_ENCFunNm_s, cv_DECFunNm_s), cv_FLDNm_s, JuminNo)
                End If

            ElseIf oRs.Fields.Item("U_SECURITY").Value = "S02" Then

                xSQL = " SELECT   U_USEYN "
                xSQL = xSQL & vbCrLf & " FROM	    [@WJS_SAD011]"
                xSQL = xSQL & vbCrLf & " WHERE    Code    = 'HR101'"
                xSQL = xSQL & vbCrLf & " AND      U_SMLCD = 'U01'"
                xSQL = xSQL & vbCrLf & " AND      U_USEYN = 'Y'"

#If HANA = "Y" Then
                xSQL = CFL.GetConvertHANA(xSQL)
#End If
                oRs.DoQuery(xSQL)

                If oRs.EoF Then
                    cv_USEYN = "N"
                Else
                    cv_USEYN = "Y"
                End If

                If cv_USEYN = "Y" Then

                    If EncryptionYN = True Then
                        WPIN1_JMNO = WJSCRYPTO_JMNO2(cv_Server_s, IIf(EncryptionYN, cv_ENCFunNm_s, cv_DECFunNm_s), cv_FLDNm_s, JuminNo, "", EncryptionYN, Accessurl, Empno)
                    Else
                        WPIN1_JMNO = WJSCRYPTO_DEC(cv_Server_s, IIf(EncryptionYN, cv_ENCFunNm_s, cv_DECFunNm_s), "REGNO", JuminNo, "", EncryptionYN, Accessurl, Empno)
                    End If
                Else
                    WPIN1_JMNO = JuminNo
                End If

            End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("WPIN1_JMNO Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
            WPIN1_JMNO = ""

        Finally

            oRs = Nothing

        End Try

    End Function

    Public Function WJSCRYPTO_DEC(ByVal ServerAddr As String, _
                                          ByVal FuncNm As String, _
                                          ByVal FieldNm As String, _
                                          ByVal Value As String, _
                                          ByVal Sitecode As String, _
                                          ByVal EncryptionYN As Boolean, _
                                          ByVal Accessurl As String, _
                                          ByVal Empno As String) As String

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim DecValue As String = ""
        Dim XSQL As String = ""
        Dim RtnValue As String = ""

        WJSCRYPTO_DEC = ""

        Try


            If FieldNm.ToUpper = "REGNO" Then

#If HANA = "Y" Then
                XSQL = "SELECT    ""WJSCRYVALUE"""
                XSQL = XSQL & vbCrLf & " FROM   ""WJSSY"".""ZHR_REGNO"" "
                XSQL = XSQL & vbCrLf & " WHERE  ""VALUE"" = '" & Value & "'"
#Else
                XSQL = "SELECT    WJSCRYValue"
                XSQL = XSQL & vbCrLf & " FROM   WJSSY.DBO.ZHR_REGNO"
                XSQL = XSQL & vbCrLf & " WHERE  Value = '" & Value & "'"
#End If


            ElseIf FieldNm.ToUpper = "ACNO" Then


#If HANA = "Y" Then
                XSQL = "SELECT    ""WJSCRYVALUE"""
                XSQL = XSQL & vbCrLf & " FROM   ""WJSSY"".""ZHR_ACNO"" "
                XSQL = XSQL & vbCrLf & " WHERE  ""VALUE"" = '" & Value & "'"
#Else
                XSQL = "SELECT    WJSCRYValue"
                XSQL = XSQL & vbCrLf & " FROM   WJSSY.DBO.ZHR_ACNO"
                XSQL = XSQL & vbCrLf & " WHERE  Value = '" & Value & "'"
#End If


            ElseIf FieldNm.ToUpper = "TELNO" Then

#If HANA = "Y" Then
                XSQL = "SELECT    ""WJSCRYVALUE"""
                XSQL = XSQL & vbCrLf & " FROM   ""WJSSY"".""ZHR_TELNO"" "
                XSQL = XSQL & vbCrLf & " WHERE  ""VALUE"" = '" & Value & "'"
#Else
                XSQL = "SELECT    WJSCRYValue"
                XSQL = XSQL & vbCrLf & " FROM   WJSSY.DBO.ZHR_TELNO"
                XSQL = XSQL & vbCrLf & " WHERE  Value = '" & Value & "'"
#End If


            ElseIf FieldNm.ToUpper = "EMAIL" Then

#If HANA = "Y" Then
                XSQL = "SELECT    ""WJSCRYVALUE"""
                XSQL = XSQL & vbCrLf & " FROM   ""WJSSY"".""ZHR_EMAIL"""
                XSQL = XSQL & vbCrLf & " WHERE  ""VALUE"" = '" & Value & "'"
#Else
                XSQL = "SELECT    WJSCRYValue"
                XSQL = XSQL & vbCrLf & " FROM   WJSSY.DBO.ZHR_EMAIL"
                XSQL = XSQL & vbCrLf & " WHERE  Value = '" & Value & "'"
#End If


            End If

            oRs.DoQuery(XSQL)

            If Not oRs.EoF Then

                DecValue = oRs.Fields.Item("WJSCRYValue").Value

                RtnValue = CFL.CryptoDecryption(DecValue)

                If RtnValue <> "" Then
                    WJSCRYPTO_DEC = RtnValue
                End If
            Else
                WJSCRYPTO_DEC = Value
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("WJSCRYPTO_DEC Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
        Finally
            oRs = Nothing
        End Try

    End Function

    Public Function ConnWPinWeb(ByVal ServerAddr As String, ByVal FuncNm As String, ByVal FieldNm As String, ByVal Value As String) As String


        Dim Soap As String = ""

        Dim Response As WebResponse
        Dim ResponseStream As Stream
        Dim ReaderPost As StreamReader
        Dim XmlData As String
        Dim XmlDS As DataSet
        Dim Stream As StringReader
        Dim Reader As XmlTextReader

        ConnWPinWeb = ""

        Try

            Dim Req As HttpWebRequest = DirectCast(WebRequest.Create(ServerAddr), HttpWebRequest)

            Req.Headers.Add("SOAPAction", "http://tempuri.org/" & FuncNm)
            Req.Accept = "text/xml"
            Req.Method = "POST"
            Req.ContentType = "text/xml;charset=UTF-8"

            Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                        "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                       "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                       "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                            "<soap:Body>" & _
                                "<" & FuncNm & " xmlns=""http://tempuri.org/"">" & _
                                    "<" & FieldNm & ">" & Value & "</" & FieldNm & ">" & _
                                "</" & FuncNm & " >" & _
                            "</soap:Body>" & _
                        "</soap:Envelope>"

            Dim Writer As StreamWriter = New StreamWriter(Req.GetRequestStream())

            '// Write the xml text into the stream
            Writer.WriteLine(Soap)
            Writer.Close()


            Response = Req.GetResponse()
            ResponseStream = Response.GetResponseStream()
            ReaderPost = New StreamReader(ResponseStream, System.Text.Encoding.UTF8)
            XmlData = ReaderPost.ReadLine()
            ReaderPost.Close()

            XmlDS = New DataSet()
            Stream = New StringReader(XmlData)

            '// Load the XmlTextReader from the stream
            Reader = New XmlTextReader(Stream)
            XmlDS.ReadXml(Reader)

            If XmlDS.Tables.Count = 2 Then

                If XmlDS.Tables(1).Rows.Count = 1 Then

                    ConnWPinWeb = XmlDS.Tables(1).Rows(0)(0).ToString()

                End If

            End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("ConnWPinWeb Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)

        End Try


    End Function
    Public Function ConnWPinWebCOWAY(ByVal ServerAddr As String, _
                                     ByVal FuncNm As String, _
                                     ByVal FieldNm As String, _
                                     ByVal Value As String, _
                                     ByVal Sitecode As String, _
                                     ByVal EncryptionYN As Boolean, _
                                     ByVal Accessurl As String) As String

        Dim Soap As String = ""
        Dim Response As WebResponse
        Dim ResponseStream As Stream
        Dim ReaderPost As StreamReader
        Dim XmlData As String
        Dim XmlDS As DataSet
        Dim Stream As StringReader
        Dim Reader As XmlTextReader
        Dim cv_USER As String = ""
        Dim cvip() As System.Net.IPAddress
        Dim strIp As String = ""


        ConnWPinWebCOWAY = ""

        Try

            Dim Req As HttpWebRequest = DirectCast(WebRequest.Create(ServerAddr), HttpWebRequest)

            cv_USER = B1Connections.diCompany.UserName
            cvip = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList
            strIp = cvip(0).ToString()

            Req.Headers.Add("SOAPAction", "http://tempuri.org/" & FuncNm)
            Req.Accept = "text/xml"
            Req.Method = "POST"
            Req.ContentType = "text/xml;charset=UTF-8"

            If EncryptionYN = False Then          '복호화 함수

                Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                         "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                        "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                        "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                             "<soap:Body>" & _
                                 "<" & FuncNm & " xmlns=""http://tempuri.org/"">" & _
                                     "<" & FieldNm & ">" & Value & "</" & FieldNm & ">"
                '"</" & FuncNm & " >"

                If FieldNm.ToLower.Trim = "cardno" Or FieldNm.ToLower.Trim = "accno" Then          '카드번호

                    Soap = Soap & "<sitecode>" & Sitecode & "</sitecode>" & _
                                  "<accessip>" & strIp & "</accessip>" & _
                                  "<sessionid></sessionid>" & _
                                  "<accessurl>" & Accessurl & "</accessurl>" & _
                                  "<accessid>" & cv_USER & "</accessid>" & _
                                  "<etc1></etc1>" & _
                                  "<etc2></etc2>"
                Else
                    Soap = Soap & "<resulttype></resulttype>" & _
                                  "<sitecode>" & Sitecode & "</sitecode>" & _
                                  "<accessip>" & strIp & "</accessip>" & _
                                  "<sessionid></sessionid>" & _
                                  "<accessurl>" & Accessurl & "</accessurl>" & _
                                  "<accessid>" & cv_USER & "</accessid>" & _
                                  "<etc1></etc1>" & _
                                  "<etc2></etc2>"
                End If

                Soap = Soap & "</" & FuncNm & " >" & _
                            "</soap:Body>" & _
                            "</soap:Envelope>"
            Else
                '암호화 함수
                Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                         "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                        "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                        "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                             "<soap:Body>" & _
                                 "<" & FuncNm & " xmlns=""http://tempuri.org/"">" & _
                                     "<" & FieldNm & ">" & Value & "</" & FieldNm & ">" & _
                                 "</" & FuncNm & " >" & _
                             "</soap:Body>" & _
                         "</soap:Envelope>"
            End If



            Dim Writer As StreamWriter = New StreamWriter(Req.GetRequestStream())

            '// Write the xml text into the stream
            Writer.WriteLine(Soap)
            Writer.Close()


            Response = Req.GetResponse()
            ResponseStream = Response.GetResponseStream()
            ReaderPost = New StreamReader(ResponseStream, System.Text.Encoding.UTF8)
            XmlData = ReaderPost.ReadLine()
            ReaderPost.Close()

            XmlDS = New DataSet()
            Stream = New StringReader(XmlData)

            '// Load the XmlTextReader from the stream
            Reader = New XmlTextReader(Stream)
            XmlDS.ReadXml(Reader)

            If XmlDS.Tables.Count = 2 Then

                If XmlDS.Tables(1).Rows.Count = 1 Then

                    ConnWPinWebCOWAY = XmlDS.Tables(1).Rows(0)(0).ToString()

                End If

            End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("ConnWPinWebCOWAY Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)

        End Try


    End Function
    ' 2017.03.20 웅진그룹에서 사용하는  WPIN 함수 추가
    '구주소 : http://websv.woongjin.com:8012/wpin/WebTockenService/TockenGroup.asmx
    '신주소 : http://webservice.woongjin.com:8012/wPin/webservice/wjallwpinnew.asmx
    '////////////////////////////////////////////////////////////////////////////////
    '// 2017.12.20 엘리먼트명칭 수정 
    '// accessip -> access_ip, sitecode -> site_code
    '////////////////////////////////////////////////////////////////////////////////
    Public Function ConnWPinWebGroup(ByVal ServerAddr As String, _
                                     ByVal FuncNm As String, _
                                     ByVal FieldNm As String, _
                                     ByVal Value As String, _
                                     ByVal Sitecode As String, _
                                     ByVal EncryptionYN As Boolean, _
                                     ByVal Accessurl As String, _
                                     ByVal CompanyCode As String) As String


        Dim Soap As String = ""

        Dim Response As WebResponse
        Dim ResponseStream As Stream
        Dim ReaderPost As StreamReader
        Dim XmlData As String
        Dim XmlDS As DataSet
        Dim Stream As StringReader
        Dim Reader As XmlTextReader
        Dim strProcessStat As String = ""
        Dim cv_USER As String = ""
        Dim cvip() As System.Net.IPAddress
        Dim strIp As String = ""


        ConnWPinWebGroup = ""

        Try

            strProcessStat = "1. 변수값 초기화 "

            Dim Req As HttpWebRequest = DirectCast(WebRequest.Create(ServerAddr), HttpWebRequest)

            cv_USER = B1Connections.diCompany.UserName
            cvip = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList
            strIp = cvip(1).ToString()      '0 -> 1, 2017-12-20 수정 적용함.


            Req.Headers.Add("SOAPAction", "http://tempuri.org/" & FuncNm)
            Req.Accept = "text/xml"
            Req.Method = "POST"
            Req.ContentType = "text/xml;charset=UTF-8"


            If EncryptionYN = False Then          '복호화 함수

                Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                         "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                        "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                        "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                             "<soap:Body>" & _
                                 "<" & FuncNm & " xmlns=""http://tempuri.org/"">" & _
                                 "<com>" & CompanyCode & "</com>" & _
                                     "<" & FieldNm & ">" & Value & "</" & FieldNm & ">"
                ' "</" & FuncNm & " >"

                If FieldNm.ToLower.Trim = "regno" Or FieldNm.ToLower.Trim = "email" Or FieldNm.ToLower.Trim = "telno" Then

                    Soap = Soap & "<resulttype></resulttype>" & _
                                                     "<site_code>" & Sitecode & "</site_code>" & _
                                                     "<access_ip>" & strIp & "</access_ip>" & _
                                                     "<session_id></session_id>" & _
                                                     "<access_url>" & Accessurl & "</access_url>" & _
                                                     "<access_id>" & cv_USER & "</access_id>"

                Else

                    Soap = Soap & "<site_code>" & Sitecode & "</site_code>" & _
                                  "<access_ip>" & strIp & "</access_ip>" & _
                                  "<session_id></session_id>" & _
                                  "<access_url>" & Accessurl & "</access_url>" & _
                                  "<access_id>" & cv_USER & "</access_id>"


                End If

                Soap = Soap & "</" & FuncNm & " >" & _
                            "</soap:Body>" & _
                            "</soap:Envelope>"

            Else


                '암호화 함수
                If FieldNm.ToLower.Trim.ToLower = "regno" Or FieldNm.ToLower.Trim.ToUpper = "email" Or FieldNm.ToLower.Trim.ToUpper = "telno" Then
                    Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                                                           "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                                                          "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                                                          "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                                                               "<soap:Body>" & _
                                                                   "<" & FuncNm & " xmlns=""http://tempuri.org/"">" & _
                                                                       "<com>" & CompanyCode & "</com>" & _
                                                                       "<" & FieldNm & ">" & Value & "</" & FieldNm & ">" & _
                                                                       "<resulttype>string</resulttype>" & _
                                                                   "</" & FuncNm & " >" & _
                                                               "</soap:Body>" & _
                                                           "</soap:Envelope>"

                Else

                    Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                                         "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                                        "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                                        "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                                             "<soap:Body>" & _
                                                 "<" & FuncNm & " xmlns=""http://tempuri.org/"">" & _
                                                     "<com>" & CompanyCode & "</com>" & _
                                                     "<" & FieldNm & ">" & Value & "</" & FieldNm & ">" & _
                                                 "</" & FuncNm & " >" & _
                                             "</soap:Body>" & _
                                         "</soap:Envelope>"


                End If




            End If


            Dim Writer As StreamWriter = New StreamWriter(Req.GetRequestStream())

            strProcessStat = "2. Write the xml text into the stream "
            '// Write the xml text into the stream
            Writer.WriteLine(Soap)
            Writer.Close()

            strProcessStat = "3. Response = Req.GetResponse()"
            Response = Req.GetResponse()
            strProcessStat = "3. ResponseStream = Response.GetResponseStream()"
            ResponseStream = Response.GetResponseStream()
            strProcessStat = "3. ReaderPost = New StreamReader(ResponseStream, System.Text.Encoding.UTF8) "
            ReaderPost = New StreamReader(ResponseStream, System.Text.Encoding.UTF8)
            strProcessStat = "3. XmlData = ReaderPost.ReadLine() "
            XmlData = ReaderPost.ReadLine()
            ReaderPost.Close()

            XmlDS = New DataSet()
            Stream = New StringReader(XmlData)

            '// Load the XmlTextReader from the stream
            Reader = New XmlTextReader(Stream)
            strProcessStat = "4. XmlDS.ReadXml(Reader) "
            XmlDS.ReadXml(Reader)

            If XmlDS.Tables.Count = 2 Then

                If XmlDS.Tables(1).Rows.Count = 1 Then

                    strProcessStat = "4. ConnWPinWebGroup = XmlDS.Tables(1).Rows(0)(0).ToString() // " & XmlDS.Tables(1).Rows(0)(0).ToString()
                    ConnWPinWebGroup = XmlDS.Tables(1).Rows(0)(0).ToString()

                End If

            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ConnWPinWebGroup  Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
            'WriteLogFile("ConnWPinWebGroup  Error : " & Err.Description)
            'WriteLogFile("- ServerAddr : " & ServerAddr & ", FuncNm : " & FuncNm & ", FieldNm : " & FieldNm & ", Value : " & Value)
            'WriteLogFile("- Process Status : " & strProcessStat)
        End Try


    End Function

    '// 2017.05.17 씽크빅 암복호화 부분 추가
    '// 신웹서비스로 처리할 수 있도록 함수 추가함.
    '- 구웹서비스 : http://webservice.wjthinkbig.com:8012/interface/wPin/WebTockenService/TockenThinkBig.asmx
    '- 신웹서비스 : http://webservice.wjthinkbig.com:8012/websrv/thinkbigcommon/thinkbigcommon.asmx

    '// 2018.03.16 , 웅진컴퍼스 사이트코드(SAP B1인사급여)-2036으로 확정 (김호동차장님에게 발급받음)

    Public Function ConnWPinWebThinkBig(ByVal ServerAddr As String, _
                                        ByVal FuncNm As String, _
                                        ByVal FieldNm As String, _
                                        ByVal Value As String, _
                                        ByVal Sitecode As String, _
                                        ByVal EncryptionYN As Boolean, _
                                        ByVal Accessurl As String) As String


        Dim Soap As String = ""

        Dim Response As WebResponse
        Dim ResponseStream As Stream
        Dim ReaderPost As StreamReader
        Dim XmlData As String
        Dim XmlDS As DataSet
        Dim Stream As StringReader
        Dim Reader As XmlTextReader
        Dim strProcessStat As String = ""
        Dim cv_USER As String = ""
        Dim cvip() As System.Net.IPAddress
        Dim strIp As String = ""



        ConnWPinWebThinkBig = ""

        Try

            strProcessStat = "1. 변수값 초기화 "

            Dim Req As HttpWebRequest = DirectCast(WebRequest.Create(ServerAddr), HttpWebRequest)
            cv_USER = B1Connections.diCompany.UserName
            cvip = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList
            strIp = cvip(0).ToString()



            Req.Headers.Add("SOAPAction", "http://ThinkbigCommon/" & FuncNm)
            Req.Accept = "text/xml"
            Req.Method = "POST"
            Req.ContentType = "text/xml;charset=UTF-8"


            If EncryptionYN = False Then


                Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                      "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                     "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                     "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                          "<soap:Body>" & _
                              "<" & FuncNm & " xmlns=""http://ThinkbigCommon/"">" & _
                                  "<" & FieldNm & ">" & Value & "</" & FieldNm & ">"
                ' "</" & FuncNm & " >"

                If FieldNm.ToLower.Trim = "regno" Then

                    Soap = Soap & "<resulttype></resulttype>" & _
                                                     "<sitecode>" & Sitecode & "</sitecode>" & _
                                                     "<accessip>" & strIp & "</accessip>" & _
                                                     "<sessionid>" & cv_USER & "</sessionid>" & _
                                                     "<accessurl>" & Accessurl & "</accessurl>" & _
                                                     "<accessid>" & cv_USER & "</accessid>" & _
                                                     "<etc1></etc1>" & _
                                                     "<etc2></etc2>"

                Else

                    Soap = Soap & "<sitecode>" & Sitecode & "</sitecode>" & _
                                  "<accessip>" & strIp & "</accessip>" & _
                                  "<sessionid>" & cv_USER & "</sessionid>" & _
                                  "<accessurl>" & Accessurl & "</accessurl>" & _
                                  "<accessid>" & cv_USER & "</accessid>" & _
                                  "<etc1></etc1>" & _
                                  "<etc2></etc2>"

                End If

                Soap = Soap & "</" & FuncNm & " >" & _
                            "</soap:Body>" & _
                            "</soap:Envelope>"



            Else

                '암호화
                Soap = "<?xml version=""1.0"" encoding=""UTF-8""?>" & _
                            "<soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" " & _
                                           "xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" " & _
                                           "xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" >" & _
                                "<soap:Body>" & _
                                    "<" & FuncNm & " xmlns=""http://ThinkbigCommon/"">" & _
                                        "<" & FieldNm & ">" & Value & "</" & FieldNm & ">" & _
                                    "</" & FuncNm & " >" & _
                                "</soap:Body>" & _
                            "</soap:Envelope>"
            End If





            Dim Writer As StreamWriter = New StreamWriter(Req.GetRequestStream())

            strProcessStat = "2. Write the xml text into the stream "
            '// Write the xml text into the stream
            Writer.WriteLine(Soap)
            Writer.Close()

            strProcessStat = "3. Response = Req.GetResponse()"
            Response = Req.GetResponse()
            strProcessStat = "3. ResponseStream = Response.GetResponseStream()"
            ResponseStream = Response.GetResponseStream()
            strProcessStat = "3. ReaderPost = New StreamReader(ResponseStream, System.Text.Encoding.UTF8) "
            ReaderPost = New StreamReader(ResponseStream, System.Text.Encoding.UTF8)
            strProcessStat = "3. XmlData = ReaderPost.ReadLine() "
            XmlData = ReaderPost.ReadLine()
            ReaderPost.Close()

            XmlDS = New DataSet()
            Stream = New StringReader(XmlData)

            '// Load the XmlTextReader from the stream
            Reader = New XmlTextReader(Stream)
            strProcessStat = "4. XmlDS.ReadXml(Reader) "
            XmlDS.ReadXml(Reader)

            If XmlDS.Tables.Count = 2 Then

                If XmlDS.Tables(1).Rows.Count = 1 Then

                    strProcessStat = "4. ConnWPinWebGroup = XmlDS.Tables(1).Rows(0)(0).ToString() // " & XmlDS.Tables(1).Rows(0)(0).ToString()
                    ConnWPinWebThinkBig = XmlDS.Tables(1).Rows(0)(0).ToString()

                End If

            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ConnWPinWebGroup  Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)
            'WriteLogFile("ConnWPinWebThinkBig  Error : " & Err.Description)
            'WriteLogFile("- ServerAddr : " & ServerAddr & ", FuncNm : " & FuncNm & ", FieldNm : " & FieldNm & ", Value : " & Value)
            'WriteLogFile("- Process Status : " & strProcessStat)
        End Try


    End Function

    Public Function WJSCRYPTO_JMNO2(ByVal ServerAddr As String, _
                                      ByVal FuncNm As String, _
                                      ByVal FieldNm As String, _
                                      ByVal Value As String, _
                                      ByVal Sitecode As String, _
                                      ByVal EncryptionYN As Boolean, _
                                      ByVal Accessurl As String, _
                                      ByVal Empno As String) As String

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRs2 As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = ""
        Dim strCryto As String = ""
        Dim strRegno As String = ""
        Dim strC5 As String = ""
        Dim strC8 As String = ""
        Dim strC9 As String = ""
        Dim strC10 As String = ""
        Dim strC11 As String = ""
        Dim strC12 As String = ""
        Dim strC13 As String = ""

        Dim upperbound As Integer = 3
        Dim lowerbound As Integer = 1
        Dim randomValue As Integer = 0

        Dim FixDigit5 As Integer = 0
        Dim FixDigit8 As Integer = 0
        Dim FixDigit9 As Integer = 0
        Dim FixDigit10 As Integer = 0
        Dim FixDigit11 As Integer = 0
        Dim FixDigit12 As Integer = 0
        Dim FixDigit13 As Integer = 0

        Dim ValueDigit5 As Integer = 0
        Dim ValueDigit8 As Integer = 0
        Dim ValueDigit9 As Integer = 0
        Dim ValueDigit10 As Integer = 0
        Dim ValueDigit11 As Integer = 0
        Dim ValueDigit12 As Integer = 0
        Dim ValueDigit13 As Integer = 0
        Dim iCount As Integer = 999


        WJSCRYPTO_JMNO2 = ""


        Try


            strCryto = CFL.CryptoEncryption(Value)

            If strCryto = "" Then
                strCryto = Value
                Exit Try
            Else

#If HANA = "Y" Then
                xSQL = "SELECT  TOP 1 ""VALUE""  FROM  ""WJSSY"".""ZHR_REGNO""  WHERE  ""WJSCRYVALUE""  =  '" & strCryto & "'"
#Else
                xSQL = "SELECT  TOP 1 Value  FROM  WJSSY.DBO.ZHR_REGNO  WHERE  WJSCRYValue  =  '" & strCryto & "'"
#End If
                oRs2.DoQuery(xSQL)

                If Not oRs2.EoF Then
                    WJSCRYPTO_JMNO2 = oRs2.Fields.Item("Value").Value
                Else

                    ValueDigit5 = Value.Substring(4, 1)
                    ValueDigit8 = Value.Substring(7, 1)
                    ValueDigit9 = Value.Substring(8, 1)
                    ValueDigit10 = Value.Substring(9, 1)
                    ValueDigit11 = Value.Substring(10, 1)
                    ValueDigit12 = Value.Substring(11, 1)
                    ValueDigit13 = Value.Substring(12, 1)

                    Do While iCount = 999

                        Randomize()

                        randomValue = CInt(Math.Floor((upperbound - lowerbound + 1) * Rnd())) + lowerbound

                        If randomValue = 1 Then

                            FixDigit5 = 65      '대문자A
                            FixDigit8 = 66      '대문자B
                            FixDigit9 = 99      '소문자C
                            FixDigit10 = 48     '숫자2
                            FixDigit11 = 103    '소문자G
                            FixDigit12 = 109    '소문자M
                            FixDigit13 = 49     '숫자1

                        ElseIf randomValue = 2 Then

                            FixDigit5 = 90      '대문자Z
                            FixDigit8 = 67      '대문자C
                            FixDigit9 = 80      '대문자P
                            FixDigit10 = 97     '소문자A
                            FixDigit11 = 97     '소문자A
                            FixDigit12 = 97     '소문자A
                            FixDigit13 = 48     '숫자0

                        ElseIf randomValue = 3 Then

                            FixDigit5 = 66      '대문자B
                            FixDigit8 = 68      '대문자D
                            FixDigit9 = 80      '대문자P
                            FixDigit10 = 97     '소문자A
                            FixDigit11 = 97     '소문자A
                            FixDigit12 = 97     '소문자A
                            FixDigit13 = 49     '숫자1

                        Else
                            FixDigit5 = 67      '대문자C
                            FixDigit8 = 68      '대문자D
                            FixDigit9 = 80      '대문자P
                            FixDigit10 = 97     '소문자A
                            FixDigit11 = 97     '소문자A
                            FixDigit12 = 97     '소문자A
                            FixDigit13 = 49     '숫자1
                        End If

                        strC5 = Chr(FixDigit5)
                        strC8 = Chr(FixDigit8 + ValueDigit8)
                        strC9 = Chr(FixDigit9 + ValueDigit9)
                        strC10 = Chr(FixDigit10 + ValueDigit10)
                        strC11 = Chr(FixDigit11 + ValueDigit11)
                        strC12 = Chr(FixDigit12 + ValueDigit12)
                        strC13 = WJSCRYPTO_RAND("REGNO")

                        strRegno = Value.Substring(0, 4).ToString & strC5 & Value.Substring(5, 2) & strC8 & strC9 & strC10 & strC11 & strC12 & strC13

#If HANA = "Y" Then
                        xSQL = "SELECT   1"
                        xSQL = xSQL & vbCrLf & " FROM   ""WJSSY"".""ZHR_REGNO""  "
                        xSQL = xSQL & vbCrLf & " WHERE  ""VALUE""  = '" & strRegno & "'"
#Else
                        xSQL = "SELECT   1"
                        xSQL = xSQL & vbCrLf & " FROM   WJSSY.DBO.ZHR_REGNO "
                        xSQL = xSQL & vbCrLf & " WHERE  Value = '" & strRegno & "'"
#End If

                        oRs.DoQuery(xSQL)

                        If oRs.EoF Then
                            iCount = 1
                        Else
                            iCount = 999
                        End If

                    Loop


                    'strCryto = CFL.CryptoEncryption(Value)

                    If strCryto <> "" And strRegno <> "" Then

#If HANA = "Y" Then
                        xSQL = ""
                        xSQL = "INSERT  INTO  ""WJSSY"".""ZHR_REGNO"" (""VALUE"", ""WJSCRYVALUE"", ""CREATEDATE"", ""USERCODE"", ""FORMID"", ""COMPANYDBNM"", EMPNO)"
                        xSQL = xSQL & vbCrLf & "SELECT  '" & strRegno & "' AS VALUE , '" & strCryto & "'  AS  WJSCRYVALUE "
                        xSQL = xSQL & vbCrLf & ",  NOW() AS CREATEDATE"
                        xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.UserName & "'  AS  USERCODE"
                        xSQL = xSQL & vbCrLf & ", '" & Accessurl & "'  AS  FORMID "
                        xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.CompanyDB & "'  AS  COMPANYDBNM"
                        xSQL = xSQL & vbCrLf & ", '" & Empno & "'  AS EMPNO"
                        xSQL = xSQL & vbCrLf & "FROM    DUMMY"
#Else
                        xSQL = ""
                        xSQL = "INSERT  INTO  WJSSY.DBO.ZHR_REGNO (Value, WJSCRYValue, CreateDate, UserCode, FormID, CompanyDBNM, EMPNO)"
                        xSQL = xSQL & vbCrLf & "SELECT  '" & strRegno & "' AS Value , '" & strCryto & "'  AS  WJSCRYValue "
                        xSQL = xSQL & vbCrLf & ",  GETDATE() AS CreateDate"
                        xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.UserName & "'  AS  UserCode"
                        xSQL = xSQL & vbCrLf & ", '" & Accessurl & "'  AS  FormID "
                        xSQL = xSQL & vbCrLf & ", '" & B1Connections.diCompany.CompanyDB & "'  AS  CompanyDBNM"
                        xSQL = xSQL & vbCrLf & ", '" & Empno & "'  AS EMPNO"
#End If

                        oRs.DoQuery(xSQL)
                        WJSCRYPTO_JMNO2 = strRegno
                    End If

                End If
            End If


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("WJSCRYPTO_JMNO Error : " & Err.Description, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error)

        Finally
            oRs = Nothing
            oRs2 = Nothing
        End Try

    End Function

    Public Sub GetAuth2(ByVal av_UserId_s As String, ByVal av_FormId_s As String, ByVal av_ACD_s As String, _
       ByRef av_empno_s As String, ByRef av_empnm_s As String, ByRef av_hacd_s As String, ByRef av_hanm_s As String, _
       ByRef av_paycd_s As String, ByRef av_paynm_s As String, ByRef av_readtpa_s As String, ByRef av_readtp_s As String, _
       ByRef av_authyn_s As String, ByRef av_authNEW_s As String)
        '데이타사용자 권한
        Dim oRS As SAPbobsCOM.Recordset
        Dim xsql As String
        Try
            av_authyn_s = "N"

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
#If HANA = "Y" Then
            xsql = "SELECT TOP 1 IFNULL(U_DPRIYN, ''), IFNULL(U_NEWDPRI, 'N') FROM ""@WJS_SHR01M"" "
#Else
            xsql = " select top 1 isnull(U_DPRIYN,''),isnull(U_NEWDPRI,'N') from [@WJS_SHR01M] WITH(NOLOCK) "
#End If
            oRS.DoQuery(xsql)
            If Not oRS.EoF Then
                av_authyn_s = oRS.Fields.Item(0).Value
                av_authNEW_s = oRS.Fields.Item(1).Value
                If av_authyn_s = "Y" And av_authNEW_s <> "Y" Then '권한을 사용하지만, 구데이터권한을 사용하는 경우 

                    xsql = " "

#If HANA = "Y" Then
                    xsql = xsql & "SELECT	T0.U_EMPNO, T0.U_EMPNM,                                                              " & vbCrLf
                    xsql = xsql & "		CASE WHEN IFNULL(T2.U_READTP,'') <> 'W' THEN T0.U_HACD                                   " & vbCrLf
                    xsql = xsql & "		     WHEN IFNULL(T2.U_MDGBN,'') = 'H' THEN IFNULL(T5.U_INARTP,T2.U_ACD)                  " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS ""U_HACD"",                                                          " & vbCrLf
                    xsql = xsql & "		CASE WHEN IFNULL(T2.U_READTP,'') <> 'W' THEN T0.U_HANM                                   " & vbCrLf
                    xsql = xsql & "		     WHEN IFNULL(T2.U_MDGBN,'') = 'H' THEN IFNULL(T5.U_INARNM,T2.U_ANM)                  " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS ""U_HANM"",                                                          " & vbCrLf
                    xsql = xsql & "		CASE WHEN IFNULL(T2.U_READTP,'') <> 'W' THEN T7.U_PYACD                                  " & vbCrLf
                    xsql = xsql & "		     WHEN IFNULL(T2.U_MDGBN,'') = 'P' THEN IFNULL(T6.Code,T2.U_ACD)                      " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS ""U_PAYCD"",                                                         " & vbCrLf
                    xsql = xsql & "		CASE WHEN IFNULL(T2.U_READTP,'') <> 'W' THEN T7.U_PYANM                                  " & vbCrLf
                    xsql = xsql & "		     WHEN IFNULL(T2.U_MDGBN,'') = 'P' THEN IFNULL(T6.Name,T2.U_ANM)                      " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS ""U_PAYNM"",                                                         " & vbCrLf
                    xsql = xsql & "		CASE WHEN IFNULL(T2.U_ACD,'') <> '' THEN IFNULL(T2.U_READTP,'') ELSE '' END AS ""U_READTP"", " & vbCrLf
                    xsql = xsql & "		CASE WHEN IFNULL(T2.U_ACD,'') =  '' THEN IFNULL(T2.U_READTP,'') ELSE '' END AS ""U_READTPA"" " & vbCrLf
                    xsql = xsql & "FROM	""@WJS_SHR11M"" T0                                                                       " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN ""@WJS_SPY11M"" T7 ON T0.U_EMPNO = T7.U_EMPNO                                 " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN (                                                                             " & vbCrLf
                    xsql = xsql & "		SELECT	A0.U_EMPNO,                                                                      " & vbCrLf
                    xsql = xsql & "				A1.U_ACD,                                                                        " & vbCrLf
                    xsql = xsql & "				A1.U_ANM,                                                                        " & vbCrLf
                    xsql = xsql & "				A1.U_READTP,                                                                     " & vbCrLf
                    xsql = xsql & "				CAST(A2.U_RMK2 AS nvarchar(10)) AS ""U_MDGBN""                                   " & vbCrLf
                    xsql = xsql & "		FROM	""@WJS_SHR091"" A0                                                               " & vbCrLf
                    xsql = xsql & "				INNER JOIN ""@WJS_SHR101"" A1 ON A0.""Code"" = ""A1.Code""                       " & vbCrLf
                    xsql = xsql & "				INNER JOIN ""@WJS_SAD011"" A2 ON A1.U_PRGNO = A2.U_SMLCD AND A2.""Code"" = 'HR70'" & vbCrLf
                    xsql = xsql & "		WHERE	CAST(A2.U_RMK1 AS nvarchar(100)) = '" & av_FormId_s & "'		                 " & vbCrLf
                    xsql = xsql & "		) T2 ON T0.U_EMPNO = T2.U_EMPNO                                                          " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN ""@WJS_SHR03M"" T5 ON T2.U_ACD = T5.U_INARTP                                  " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN ""@WJS_SPY01M"" T6 ON T2.U_ACD = T6.""Code""                                  " & vbCrLf
                    xsql = xsql & "WHERE	T0.U_USERID = '" & av_UserId_s & "'                                                  " & vbCrLf
#Else
                    xsql = xsql & "SELECT	T0.U_EMPNO, T0.U_EMPNM,                                                              " & vbCrLf
                    xsql = xsql & "		CASE WHEN ISNULL(T2.U_READTP,'') <> 'W' THEN T0.U_HACD                                   " & vbCrLf
                    xsql = xsql & "		     WHEN ISNULL(T2.U_MDGBN,'') = 'H' THEN ISNULL(T5.U_INARTP,T2.U_ACD)                  " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS U_HACD,                                                              " & vbCrLf
                    xsql = xsql & "		CASE WHEN ISNULL(T2.U_READTP,'') <> 'W' THEN T0.U_HANM                                   " & vbCrLf
                    xsql = xsql & "		     WHEN ISNULL(T2.U_MDGBN,'') = 'H' THEN ISNULL(T5.U_INARNM,T2.U_ANM)                  " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS U_HANM,                                                              " & vbCrLf
                    xsql = xsql & "		CASE WHEN ISNULL(T2.U_READTP,'') <> 'W' THEN T7.U_PYACD                                  " & vbCrLf
                    xsql = xsql & "		     WHEN ISNULL(T2.U_MDGBN,'') = 'P' THEN ISNULL(T6.Code,T2.U_ACD)                      " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS U_PAYCD,                                                             " & vbCrLf
                    xsql = xsql & "		CASE WHEN ISNULL(T2.U_READTP,'') <> 'W' THEN T7.U_PYANM                                  " & vbCrLf
                    xsql = xsql & "		     WHEN ISNULL(T2.U_MDGBN,'') = 'P' THEN ISNULL(T6.Name,T2.U_ANM)                      " & vbCrLf
                    xsql = xsql & "		     ELSE '' END AS U_PAYNM,                                                             " & vbCrLf
                    xsql = xsql & "		CASE WHEN ISNULL(T2.U_ACD,'') <> '' THEN ISNULL(T2.U_READTP,'') ELSE '' END AS U_READTP, " & vbCrLf
                    xsql = xsql & "		CASE WHEN ISNULL(T2.U_ACD,'') =  '' THEN ISNULL(T2.U_READTP,'') ELSE '' END AS U_READTPA " & vbCrLf
                    xsql = xsql & "FROM	[@WJS_SHR11M] T0                                                                         " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN [@WJS_SPY11M] T7 ON T0.U_EMPNO = T7.U_EMPNO                                   " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN (                                                                             " & vbCrLf
                    xsql = xsql & "		SELECT	A0.U_EMPNO,                                                                      " & vbCrLf
                    xsql = xsql & "				A1.U_ACD,                                                                        " & vbCrLf
                    xsql = xsql & "				A1.U_ANM,                                                                        " & vbCrLf
                    xsql = xsql & "				A1.U_READTP,                                                                     " & vbCrLf
                    xsql = xsql & "				CONVERT(NVARCHAR(10),A2.U_RMK2) AS U_MDGBN                                       " & vbCrLf
                    xsql = xsql & "		FROM	[@WJS_SHR091] A0                                                                 " & vbCrLf
                    xsql = xsql & "				INNER JOIN [@WJS_SHR101] A1 ON A0.Code = A1.Code                                 " & vbCrLf
                    xsql = xsql & "				INNER JOIN [@WJS_SAD011] A2 ON A1.U_PRGNO = A2.U_SMLCD AND A2.Code = 'HR70'      " & vbCrLf
                    xsql = xsql & "		WHERE	CONVERT(NVARCHAR(100),A2.U_RMK1) = '" & av_FormId_s & "'		                 " & vbCrLf
                    xsql = xsql & "		) T2 ON T0.U_EMPNO = T2.U_EMPNO                                                          " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN [@WJS_SHR03M] T5 ON T2.U_ACD = T5.U_INARTP                                    " & vbCrLf
                    xsql = xsql & "		LEFT  JOIN [@WJS_SPY01M] T6 ON T2.U_ACD = T6.Code                                        " & vbCrLf
                    xsql = xsql & "WHERE	T0.U_USERID = '" & av_UserId_s & "'                                                  " & vbCrLf
#End If
                    oRS.DoQuery(xsql)
                    If oRS.EoF Then
                        av_empno_s = ""
                        av_empnm_s = ""
                        av_hacd_s = ""
                        av_hanm_s = ""
                        av_paycd_s = ""
                        av_paynm_s = ""
                        av_readtpa_s = ""
                        av_readtp_s = ""
                    Else
                        av_empno_s = oRS.Fields.Item("U_EMPNO").Value '사번
                        av_empnm_s = oRS.Fields.Item("U_EMPNM").Value '성명
                        av_hacd_s = oRS.Fields.Item("U_HACD").Value '디폴트 인사영역
                        av_hanm_s = oRS.Fields.Item("U_HANM").Value '디폴트 인사영역명

                        av_paycd_s = oRS.Fields.Item("U_PAYCD").Value '디폴트 급여영역
                        av_paynm_s = oRS.Fields.Item("U_PAYNM").Value '디폴트 급여영역명

                        av_readtpa_s = oRS.Fields.Item("U_READTPA").Value '전체영역 사용자권한

                        av_readtp_s = oRS.Fields.Item("U_READTP").Value '특정영역 사용자권한 , 전체영역의 사용자권한 이 '' 이면 특정영역 사용자권한 으로 한다.
                    End If

                End If
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetAuth" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

    End Sub

    Public Function SaupNoCheck(ByVal sSaupNo As String) As Boolean

        Dim intA(13) As Long
        Dim intB(13) As Long

        Try
            sSaupNo = Replace(Replace(sSaupNo.Trim, "-", ""), " ", "")
            Dim i1 As Integer = (CType(sSaupNo.Substring(0, 1), Integer) * 1) Mod 10
            Dim i2 As Integer = (CType(sSaupNo.Substring(1, 1), Integer) * 3) Mod 10
            Dim i3 As Integer = (CType(sSaupNo.Substring(2, 1), Integer) * 7) Mod 10
            Dim i4 As Integer = (CType(sSaupNo.Substring(3, 1), Integer) * 1) Mod 10
            Dim i5 As Integer = (CType(sSaupNo.Substring(4, 1), Integer) * 3) Mod 10
            Dim i6 As Integer = (CType(sSaupNo.Substring(5, 1), Integer) * 7) Mod 10
            Dim i7 As Integer = (CType(sSaupNo.Substring(6, 1), Integer) * 1) Mod 10
            Dim i8 As Integer = (CType(sSaupNo.Substring(7, 1), Integer) * 3) Mod 10
            Dim i9 As Integer = (CType(sSaupNo.Substring(8, 1), Integer) * 5) / 10
            Dim i10 As Integer = (CType(sSaupNo.Substring(8, 1), Integer) * 5) Mod 10

            Dim iRegistNumberKey As Integer = CType(sSaupNo.Substring(9, 1), Integer)

            Dim iTotal As Integer = i1 + i2 + i3 + i4 + i5 + i6 + i7 + i8 + i9 + i10

            Dim iKeyNumber As Integer = 10 - (iTotal Mod 10)

            If iKeyNumber >= 10 Then
                iKeyNumber = iKeyNumber - 10
            End If

            If iKeyNumber = iRegistNumberKey Then
                SaupNoCheck = True
            Else
                SaupNoCheck = False
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("SaupNoCheck " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try

    End Function

    Public Function BubinNoCheck(ByVal sBubinNo As String) As Boolean

        Dim intA(13) As Long
        Dim intB(13) As Long
        Dim div As Integer = 0

        Try

            If Trim(sBubinNo).Length = 13 Then
                sBubinNo = Left(sBubinNo, 6) + "-" + Right(sBubinNo, 7)
            End If

            If Trim(sBubinNo).Length = 14 Then
                '######-####### 형식일 경우
                Dim i1 As Integer = (CType(sBubinNo.Substring(0, 1), Integer) - div) * 1
                Dim i2 As Integer = (CType(sBubinNo.Substring(1, 1), Integer) - div) * 2
                Dim i3 As Integer = (CType(sBubinNo.Substring(2, 1), Integer) - div) * 1
                Dim i4 As Integer = (CType(sBubinNo.Substring(3, 1), Integer) - div) * 2
                Dim i5 As Integer = (CType(sBubinNo.Substring(4, 1), Integer) - div) * 1
                Dim i6 As Integer = (CType(sBubinNo.Substring(5, 1), Integer) - div) * 2
                Dim i7 As Integer = (CType(sBubinNo.Substring(7, 1), Integer) - div) * 1
                Dim i8 As Integer = (CType(sBubinNo.Substring(8, 1), Integer) - div) * 2
                Dim i9 As Integer = (CType(sBubinNo.Substring(9, 1), Integer) - div) * 1
                Dim i10 As Integer = (CType(sBubinNo.Substring(10, 1), Integer) - div) * 2
                Dim i11 As Integer = (CType(sBubinNo.Substring(11, 1), Integer) - div) * 1
                Dim i12 As Integer = (CType(sBubinNo.Substring(12, 1), Integer) - div) * 2
                Dim iRegistNumberKey As Integer = CType(sBubinNo.Substring(13, 1), Integer)

                Dim iTotal As Integer = i1 + i2 + i3 + i4 + i5 + i6 + i7 + i8 + i9 + i10 + i11 + i12

                Dim iKeyNumber As Integer = iTotal Mod 10

                iKeyNumber = 10 - iKeyNumber

                'If iKeyNumber = 10 Then
                '    iKeyNumber = 0
                'End If

                If iKeyNumber >= 10 Then
                    iKeyNumber = iKeyNumber - 10
                End If

                'iKeyNumber와 주민번호의 맨 끝자리 번호와 같으면 유효한 주민번호이고 아니면 유효하지 않은 주민번호임.
                If iKeyNumber = iRegistNumberKey Then
                    BubinNoCheck = True
                Else
                    BubinNoCheck = False
                End If

            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("BubinNoCheck " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try


    End Function

    '// 내.외국인 번호 체크
    Public Function JuminNoChk(ByVal sJuminNo As String) As Boolean

        Dim intA(13) As Long
        Dim intB(13) As Long
        Dim div As Integer = 0

        Try

            If Trim(sJuminNo).Length = 13 Then
                sJuminNo = Left(sJuminNo, 6) + "-" + Right(sJuminNo, 7)
            End If

            If Trim(sJuminNo).Length = 14 Then
                '######-####### 형식일 경우
                Dim i1 As Integer = (CType(sJuminNo.Substring(0, 1), Integer) - div) * 2
                Dim i2 As Integer = (CType(sJuminNo.Substring(1, 1), Integer) - div) * 3
                Dim i3 As Integer = (CType(sJuminNo.Substring(2, 1), Integer) - div) * 4
                Dim i4 As Integer = (CType(sJuminNo.Substring(3, 1), Integer) - div) * 5
                Dim i5 As Integer = (CType(sJuminNo.Substring(4, 1), Integer) - div) * 6
                Dim i6 As Integer = (CType(sJuminNo.Substring(5, 1), Integer) - div) * 7
                Dim i7 As Integer = (CType(sJuminNo.Substring(7, 1), Integer) - div) * 8
                Dim i8 As Integer = (CType(sJuminNo.Substring(8, 1), Integer) - div) * 9
                Dim i9 As Integer = (CType(sJuminNo.Substring(9, 1), Integer) - div) * 2
                Dim i10 As Integer = (CType(sJuminNo.Substring(10, 1), Integer) - div) * 3
                Dim i11 As Integer = (CType(sJuminNo.Substring(11, 1), Integer) - div) * 4
                Dim i12 As Integer = (CType(sJuminNo.Substring(12, 1), Integer) - div) * 5
                Dim iRegistNumberKey As Integer = CType(sJuminNo.Substring(13, 1), Integer)

                Dim iTotal As Integer = i1 + i2 + i3 + i4 + i5 + i6 + i7 + i8 + i9 + i10 + i11 + i12

                Dim iKeyNumber As Integer = iTotal Mod 11

                iKeyNumber = 11 - iKeyNumber

                'If iKeyNumber = 10 Then
                '    iKeyNumber = 0
                'End If

                If iKeyNumber >= 10 Then
                    iKeyNumber = iKeyNumber - 10
                End If

                '// 외국인 번호 체크 로직추가(2011.12.14 최동권)
                Select Case sJuminNo.Substring(7, 1)
                    Case "5", "6", "7", "8"
                        iKeyNumber = iKeyNumber + 2
                        If iKeyNumber >= 10 Then
                            iKeyNumber = iKeyNumber - 10
                        End If
                End Select

                'iKeyNumber와 주민번호의 맨 끝자리 번호와 같으면 유효한 주민번호이고 아니면 유효하지 않은 주민번호임.
                If iKeyNumber = iRegistNumberKey Then
                    JuminNoChk = True
                Else
                    JuminNoChk = False
                End If

            End If

        Catch ex As Exception


            B1Connections.theAppl.StatusBar.SetText("JuminNoChk " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally


        End Try


    End Function

    Public Function GetYYFI(ByVal dt8 As String) As String
        Dim YYFI As String = ""
        Try


            Dim xSQL As String = "SELECT Year FROM OACP WHERE '" + dt8 + "' Between F_RefDate AND T_RefDate"
#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If
            YYFI = CFL.GetValue(xSQL).ToString.Trim
            If YYFI = "" Then
                YYFI = Left(dt8, 4)
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetYYFI" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally

        End Try

        Return YYFI

    End Function

    Public Function SetGridTitle_Array(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As ArrayList, ByVal pColNms As ArrayList, ByVal pEdCols As ArrayList, ByVal pViCols As ArrayList, ByVal pAlignCols As ArrayList, ByVal pColor1Cols As ArrayList, ByVal pcolor2Cols As ArrayList) As Boolean

        Dim cols() As String
        Dim colNms() As String
        Dim affCols() As String
        Dim edCols() As String
        Dim viCols() As String
        Dim alignCols() As String
        Dim xSql As String = ""
        Dim i As Integer = 0

        Try

            SetGridTitle_Array = False

            If pCols.Count <> pColNms.Count Then
                Exit Function
            End If

            For i = 0 To pCols.Count - 1
                xSql = xSql & IIf(xSql = "", "", ",") & "'' as """ & pCols(i).ToString.Trim & """ "
            Next

            xSql = IIf(xSql = "", "", "Select ") & xSql

            If xSql <> "" Then
#If HANA = "Y" Then
                xSql = xSql & " FROM DUMMY;"
#End If
                Call oGrid.DataTable.ExecuteQuery(xSql)
                Call oGrid.DataTable.Rows.Remove(0)
            End If

            For i = 0 To pCols.Count - 1
                oGrid.Columns.Item(pCols.Item(i).ToString.Trim).TitleObject.Caption = CFL.GetCaption(pColNms.Item(i).ToString.Trim, ModuleIni.CO)
            Next i

            For i = 0 To pEdCols.Count - 1
                oGrid.Columns.Item(pEdCols.Item(i)).Editable = False
            Next i

            For i = 0 To pViCols.Count - 1
                oGrid.Columns.Item(pViCols.Item(i)).Visible = False
            Next i

            For i = 0 To pAlignCols.Count - 1
                oGrid.Columns.Item(pAlignCols.Item(i)).RightJustified = True
            Next i

            For i = 0 To pColor1Cols.Count - 1
                oGrid.Columns.Item(pColor1Cols.Item(i)).BackColor = 12777465
            Next i


            For i = 0 To pcolor2Cols.Count - 1
                oGrid.Columns.Item(pcolor2Cols.Item(i)).BackColor = 13624308
            Next i

            oGrid.AutoResizeColumns()

            SetGridTitle_Array = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("SetGridTitle_Array " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            cols = Nothing
            colNms = Nothing
            affCols = Nothing
            edCols = Nothing
            viCols = Nothing
            alignCols = Nothing

        End Try

    End Function

    Public Function BindGrid_array(ByVal oGrid As SAPbouiCOM.Grid, ByVal pCols As ArrayList, ByVal pColNms As ArrayList, ByVal pEdCols As ArrayList, ByVal pViCols As ArrayList, ByVal pAlignCols As ArrayList, ByVal pColor1Cols As ArrayList, ByVal pColor2Cols As ArrayList) As Boolean
        BindGrid_array = False

        'Dim cols() As String
        'Dim colNms() As String
        'Dim affCols() As String
        'Dim edCols() As String
        'Dim viCols() As String
        'Dim alignCols() As String
        Dim i As Integer

        Try

            If pCols.Count <> pColNms.Count Then
                Exit Function
            End If


            For i = 0 To pCols.Count - 1
                oGrid.Columns.Item(pCols.Item(i).ToString.Trim).TitleObject.Caption = CFL.GetCaption(pColNms.Item(i).ToString.Trim, ModuleIni.CO)
            Next i

            For i = 0 To pEdCols.Count - 1
                oGrid.Columns.Item(pEdCols.Item(i)).Editable = False
            Next i

            For i = 0 To pViCols.Count - 1
                oGrid.Columns.Item(pViCols.Item(i)).Visible = False
            Next i

            For i = 0 To pAlignCols.Count - 1
                oGrid.Columns.Item(pAlignCols.Item(i)).RightJustified = True
            Next i

            For i = 0 To pColor1Cols.Count - 1
                oGrid.Columns.Item(pColor1Cols.Item(i)).BackColor = 12777465
            Next i


            For i = 0 To pColor2Cols.Count - 1
                oGrid.Columns.Item(pColor2Cols.Item(i)).BackColor = 13624308
            Next i


            'If pEdCols.ToString.Trim.Length > 0 Then
            '    edCols = Split(pEdCols, ",")
            '    For i = LBound(edCols) To UBound(edCols)
            '        oGrid.Columns.Item(edCols(i)).Editable = False
            '    Next i
            'End If

            'If pViCols.ToString.Trim.Length > 0 Then
            '    viCols = Split(pViCols, ",")
            '    For i = LBound(viCols) To UBound(viCols)
            '        oGrid.Columns.Item(viCols(i)).Visible = False
            '    Next i
            'End If

            'If pAffCols.ToString.Trim.Length > 0 Then
            '    affCols = Split(pAffCols, ",")
            '    For i = LBound(affCols) To UBound(affCols)
            '        oGrid.Columns.Item(affCols(i)).AffectsFormMode = False
            '    Next i
            'End If

            'If pAlignCols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pAlignCols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).RightJustified = True
            '    Next i
            'End If

            'If pColor1Cols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pColor1Cols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).BackColor = 12777465
            '    Next i
            'End If

            'If pColor2Cols.ToString.Trim.Length > 0 Then
            '    alignCols = Split(pColor2Cols, ",")
            '    For i = LBound(alignCols) To UBound(alignCols)
            '        oGrid.Columns.Item(alignCols(i)).BackColor = 13624308
            '    Next i
            'End If

            BindGrid_array = True

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("BindGrid_array " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            'cols = Nothing
            'colNms = Nothing
            'affCols = Nothing
            'edCols = Nothing
            'viCols = Nothing
            'alignCols = Nothing

        End Try

    End Function


    Public Function RT_EXVAL(ByVal oCELLOBJ As Object) As String

        Dim oRTVal As String = ""
        Try
            Dim obj2 As Object
            Dim chk As String
            Dim obj233 As DateTime
            Dim chk33 As String

            If DirectCast(oCELLOBJ.GetType, System.Type).Name = "Double" Then
                obj2 = String.Format("{0:0}", oCELLOBJ).ToString()
                chk = String.Empty
                oRTVal = String.Format("{0:0}", oCELLOBJ).ToString()
            ElseIf DirectCast(oCELLOBJ.GetType, System.Type).Name = "DateTime" Then
                obj233 = DateTime.Parse(oCELLOBJ)
                chk33 = obj233.ToString("yyyyMMdd")
                oRTVal = obj233.ToString("yyyyMMdd")
            ElseIf DirectCast(oCELLOBJ.GetType, System.Type).Name = "DBNull" Then

            Else
                oRTVal = Replace(oCELLOBJ, "'", "''")
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("Error " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        End Try

        Return oRTVal

    End Function

    Public Function GetCOTEMPLET(Optional ByVal sCACD As String = "", Optional ByVal sCT As String = "") As String

        Dim xSQL As String
        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim v_RTNVAL As String = ""
        Try
            xSQL = " SELECT COUNT(DISTINCT(A.U_TPL))"
            xSQL = xSQL & vbCrLf & " FROM [@WJS_SCO10M] AS A"
            xSQL = xSQL & vbCrLf & " WHERE A.U_CACD = CASE WHEN N'" & sCACD & "' = '' THEN A.U_CACD ELSE '" & sCACD & "' END "
            xSQL = xSQL & vbCrLf & " AND A.U_CT = CASE WHEN N'" & sCT & "' = '' THEN A.U_CT ELSE '" & sCT & "' END "
#If HANA = "Y" Then
            xSQL = CFL.GetConvertHANA(xSQL)
#End If
            oRS.DoQuery(xSQL)

            If Not (oRS.EoF) Then

                If oRS.Fields.Item(0).Value > 1 Then
                    v_RTNVAL = ""
                Else
                    xSQL = "SELECT TOP 1 U_TPL FROM [@WJS_SCO10M] WHERE U_CT = CASE WHEN N'" & sCT & "' = '' THEN U_CT ELSE '" & sCT & "' END "
                    v_RTNVAL = CFL.GetValue(xSQL)
                End If

            End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText("GetCOTEMPLET" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            oRS = Nothing

        End Try

        Return v_RTNVAL

    End Function


    Public Function GetYMDfromSAPDate(ByVal strDate As String, ByVal boDtTmp As BoDateTemplate, ByVal strDetSep As String) As String

        If (strDate = "") Then
            Return ""
        End If

        Dim sarDate() As String = strDate.Split(strDetSep)

        Try

            If (boDtTmp = BoDateTemplate.dt_CCYYMMDD) Then
                strDate = sarDate(0) + sarDate(1) + sarDate(2)
            ElseIf (boDtTmp = BoDateTemplate.dt_DDMMCCYY) Then
                strDate = sarDate(2) + sarDate(1) + sarDate(0)
            ElseIf (boDtTmp = BoDateTemplate.dt_DDMMYY) Then
                strDate = IIf(Len(sarDate(2)) = 2, "20", "") + sarDate(2) + sarDate(1) + sarDate(0)
            ElseIf (boDtTmp = BoDateTemplate.dt_DDMonthYYYY) Then
                strDate = sarDate(2) + sarDate(1) + sarDate(0)
            ElseIf (boDtTmp = BoDateTemplate.dt_MMDDCCYY) Then
                strDate = sarDate(2) + sarDate(0) + sarDate(1)
            ElseIf (boDtTmp = BoDateTemplate.dt_MMDDYY) Then
                strDate = IIf(Len(sarDate(2)) = 2, "20", "") + sarDate(2) + sarDate(0) + sarDate(1)
            End If

            Return strDate

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
        End Try

    End Function


    Public Function ChkRate(ByVal strDate As String, ByVal strCurr As String) As Boolean

        Dim RS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        If (strCurr <> B1Connections.diCompany.GetCompanyService().GetAdminInfo().LocalCurrency) Then '로컬통화
            RS.DoQuery("select Currency from ORTT where RateDate = " + CFL.GetQD(strDate) _
                        + " and Currency = " + CFL.GetQD(strCurr))
            If (RS.RecordCount = 0) Then
                Return False
            End If

        End If

        Return True

    End Function

    Friend Sub BLCalCul(ByRef oForm As SAPbouiCOM.Form, ByRef DbSrcH As SAPbouiCOM.DBDataSource, ByRef DbSrcD As SAPbouiCOM.DBDataSource)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()

        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double

        Dim dAmt As Double
        Dim dQtySum As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격
                dQty = DbSrcD.GetValue("U_BLQTY", i)
                dPrc = DbSrcD.GetValue("U_BLPRC", i)


                If (DbSrcD.GetValue("U_BLAMT", i) <> 0) Then
                    If (dAmt <> dQty * dPrc) Then
                        dAmt = dQty * dPrc
                    Else
                        dAmt = DbSrcD.GetValue("U_BLAMT", i)
                    End If

                Else
                    ''금액/누적금액 계산
                    dAmt = dQty * dPrc
                End If
                dAmt = Math.Round(dAmt, dRound)

                dAmtSum = dAmtSum + dAmt


                '비재고 품목이면 수량을 더하지 않음
                If CFL.GetValue("SELECT InvntItem FROM OITM WHERE ItemCode = '" & DbSrcD.GetValue("U_ITEMCD", i) & "'") = "Y" Then
                    dQtySum = dQtySum + dQty                '누적수량
                End If

                'dQtySum = dQtySum + dQty

                '환산금액/누적환산금액 계산
                If (strCURR = strLCURR) Then '로컬통화하고 같으면
                    dAmtL = dAmt
                    dAmtLSum = dAmtLSum + dAmtL
                Else
                    dAmtL = dAmt * dRate '환산
                    dAmtLSum = dAmtLSum + dAmtL
                End If

                DbSrcD.SetValue("U_BLAMT", i, dAmt)
                DbSrcD.SetValue("U_BLLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next
        End If


        DbSrcH.SetValue("U_TOTAL", 0, dAmtSum)
        DbSrcH.SetValue("U_BLAMT", 0, dAmtSum)
        DbSrcH.SetValue("U_BLLAMT", 0, dAmtLSum)
        oForm.DataSources.UserDataSources.Item("edtTOQTY").Value = dQtySum
        'oForm.Items.Item("edtTOQTY").Specific.value = dQtySum


        oMatrix = Nothing

    End Sub

    ''' 다중사업장여부 체크 
    Public Function GetBPMultiCheck() As Boolean

        Dim oRs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim cv_BplTP As String
        Dim bolRet As Boolean = False

        Try
#If HANA = "Y" Then
            oRs.DoQuery(CFL.GetConvertHANA("SELECT ISNULL(U_BPLTP, 'N') AS U_BPLTP FROM [@WJS_SAD00M] "))
#Else
            oRs.DoQuery("SELECT ISNULL(U_BPLTP, 'N') AS U_BPLTP FROM [@WJS_SAD00M] ")
#End If
            cv_BplTP = oRs.Fields.Item("U_BPLTP").Value

            If cv_BplTP = "Y" Then
                bolRet = True
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRs = Nothing
        End Try

        Return bolRet

    End Function

    Friend Sub CalCul(ByRef oForm As SAPbouiCOM.Form, ByVal bLocalYN As Boolean)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()

        Dim DbSrcH As SAPbouiCOM.DBDataSource
        Dim DbSrcD As SAPbouiCOM.DBDataSource

        If (Not bLocalYN) Then
            DbSrcH = oForm.DataSources.DBDataSources.Item("@WJS_STM04M")
            DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_STM041")
        Else
            DbSrcH = oForm.DataSources.DBDataSources.Item("@WJS_STM06T")
            DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_STM061")
        End If

        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격

                If (Not bLocalYN) Then
                    dQty = DbSrcD.GetValue("U_LCQTY", i)
                    dPrc = DbSrcD.GetValue("U_LCPRC", i)
                Else
                    dQty = DbSrcD.GetValue("U_LLCQTY", i)
                    dPrc = DbSrcD.GetValue("U_LLCPRC", i)
                End If

                '금액/누적금액 계산
                dAmt = Math.Round(dQty * dPrc, dRound)
                dAmtSum = dAmtSum + dAmt

                '환산금액/누적환산금액 계산
                If (strCURR = strLCURR) Then '로컬통화하고 같으면

                    dAmtL = dAmt
                    dAmtLSum = dAmtLSum + dAmtL
                Else
                    dAmtL = dAmt * dRate '환산
                    dAmtLSum = dAmtLSum + dAmtL
                End If

                If (Not bLocalYN) Then
                    DbSrcD.SetValue("U_LCAMT", i, dAmt)
                    DbSrcD.SetValue("U_LCLAMT", i, dAmtL)
                Else
                    DbSrcD.SetValue("U_LLCAMT", i, dAmt)
                    DbSrcD.SetValue("U_LLCLAMT", i, dAmtL)
                End If

                oMatrix.SetLineData(i + 1)

            Next
        End If


        DbSrcH.SetValue("U_TOTAL", 0, dAmtSum)


        oMatrix = Nothing

    End Sub

    Friend Sub LLCCalCulAmend(ByRef oForm As SAPbouiCOM.Form)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()


        Dim DbSrcH As SAPbouiCOM.DBDataSource
        Dim DbSrcD As SAPbouiCOM.DBDataSource
        Dim DbSrcD2 As SAPbouiCOM.DBDataSource

        DbSrcH = oForm.DataSources.DBDataSources.Item("@WJS_STM12T")
        DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_STM121")
        DbSrcD2 = oForm.DataSources.DBDataSources.Item("@WJS_STM122")



        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double
        Dim strADTP As String

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        DbSrcD2.SetValue("U_EXCRT", 0, dRate)

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격
                strADTP = DbSrcD.GetValue("U_AMDTP", i)
                dQty = DbSrcD.GetValue("U_LLCQTY", i)
                dPrc = DbSrcD.GetValue("U_LLCPRC", i)

                '금액/누적금액 계산
                dAmt = dQty * dPrc

                If (strADTP <> "D") Then
                    dAmtSum = dAmtSum + dAmt

                    '환산금액/누적환산금액 계산
                    If (strCURR = strLCURR) Then '로컬통화하고 같으면

                        dAmtL = dAmt
                        dAmtLSum = dAmtLSum + dAmtL
                    Else
                        dAmtL = dAmt * dRate '환산
                        dAmtLSum = dAmtLSum + dAmtL
                    End If
                End If

                DbSrcD.SetValue("U_LLCAMT", i, dAmt)
                DbSrcD.SetValue("U_LLCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next

        End If


        DbSrcH.SetValue("U_ATOTAL", 0, dAmtSum)

        oMatrix = Nothing

    End Sub

    Friend Sub LLCCalCul(ByRef oForm As SAPbouiCOM.Form)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()

        Dim DbSrcH As SAPbouiCOM.DBDataSource
        Dim DbSrcD As SAPbouiCOM.DBDataSource


        DbSrcH = oForm.DataSources.DBDataSources.Item("@WJS_STM11T")
        DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_STM111")


        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격
                dQty = DbSrcD.GetValue("U_LLCQTY", i)
                dPrc = DbSrcD.GetValue("U_LLCPRC", i)

                '반올림 자릿수가 0보다 작으면 0으로 맞춤
                If dRound < 0 Then
                    dRound = 0
                End If

                '금액/누적금액 계산
                dAmt = Math.Round(dQty * dPrc, dRound)
                dAmtSum = dAmtSum + dAmt

                '환산금액/누적환산금액 계산
                If (strCURR = strLCURR) Then '로컬통화하고 같으면

                    dAmtL = dAmt
                    dAmtLSum = dAmtLSum + dAmtL
                Else
                    dAmtL = dAmt * dRate '환산
                    dAmtLSum = dAmtLSum + dAmtL
                End If

                DbSrcD.SetValue("U_LLCAMT", i, dAmt)
                DbSrcD.SetValue("U_LLCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next
        End If


        DbSrcH.SetValue("U_TOTAL", 0, dAmtSum)
        DbSrcH.SetValue("U_OPNAMT", 0, dAmtSum)
        DbSrcH.SetValue("U_OPNLAMT", 0, dAmtLSum)


        oMatrix = Nothing

    End Sub

    Friend Sub LCCalCul(ByRef oForm As SAPbouiCOM.Form)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()


        Dim DbSrcH As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item("@WJS_STM04M")
        Dim DbSrcD As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item("@WJS_STM041")

        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격

                dQty = DbSrcD.GetValue("U_LCQTY", i)
                dPrc = DbSrcD.GetValue("U_LCPRC", i)
                '금액/누적금액 계산
                dAmt = Math.Round(dQty * dPrc, dRound)
                dAmtSum = dAmtSum + dAmt

                '환산금액/누적환산금액 계산
                If (strCURR = strLCURR) Then '로컬통화하고 같으면

                    dAmtL = dAmt
                    dAmtLSum = dAmtLSum + dAmtL
                Else
                    dAmtL = dAmt * dRate '환산
                    dAmtLSum = dAmtLSum + dAmtL
                End If

                DbSrcD.SetValue("U_LCAMT", i, dAmt)
                DbSrcD.SetValue("U_LCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next
        End If


        DbSrcH.SetValue("U_TOTAL", 0, dAmtSum)


        oMatrix = Nothing

    End Sub

    Friend Sub LCCalCul(ByRef oForm As SAPbouiCOM.Form, ByRef DbSrcH As SAPbouiCOM.DBDataSource, ByRef DbSrcD As SAPbouiCOM.DBDataSource)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()

        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격

                dQty = DbSrcD.GetValue("U_LCQTY", i)
                dPrc = DbSrcD.GetValue("U_LCPRC", i)
                '금액/누적금액 계산
                dAmt = Math.Round(dQty * dPrc, dRound)
                dAmtSum = dAmtSum + dAmt

                '환산금액/누적환산금액 계산
                If (strCURR = strLCURR) Then '로컬통화하고 같으면

                    dAmtL = dAmt
                    dAmtLSum = dAmtLSum + dAmtL
                Else
                    dAmtL = dAmt * dRate '환산
                    dAmtLSum = dAmtLSum + dAmtL
                End If

                DbSrcD.SetValue("U_LCAMT", i, dAmt)
                DbSrcD.SetValue("U_LCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next
        End If


        DbSrcH.SetValue("U_TOTAL", 0, dAmtSum)


        oMatrix = Nothing

    End Sub

    '****************************************************************************************************
    '   함수명      :   SetCOMBOBPLID
    '   작성자      :   
    '   작성일      :   
    '   간략한 설명 :   사업장 콤보 셋팅
    '   인수        :   ComboObj- 콤보객체명

    '                   AllYN   - TRUE    : 전체추가 
    '                             FALSE   : 전체없음
    '                   UseYN   - TRUE    : 사용중인 사업장만
    '                             FALSE   : 모든 사업장

    '****************************************************************************************************
    Public Sub SetCOMBOBPLID(ByVal ComboObj As SAPbouiCOM.ComboBox, ByVal AllYN As Boolean, ByVal UseYN As Boolean)

        Dim oRS As SAPbobsCOM.Recordset
        Dim xSql As String
        Dim i As Integer

        Try

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            For i = 1 To ComboObj.ValidValues.Count
                ComboObj.ValidValues.Remove(0, BoSearchKey.psk_Index)
            Next

            If UseYN Then
                xSql = "SELECT BPLID, BPLNAME FROM OBPL WHERE DISABLED = N'N' ORDER BY BPLID"
            Else
                xSql = "SELECT BPLID, BPLNAME FROM OBPL ORDER BY BPLID"
            End If
            oRS.DoQuery(xSql)

            If AllYN Then
                ComboObj.ValidValues.Add("", CFL.GetCaption("전체"))
            End If

            'If Not oRS.EoF Then
            For i = 0 To oRS.RecordCount - 1
                ComboObj.ValidValues.Add(oRS.Fields.Item(0).Value.ToString, oRS.Fields.Item(1).Value.ToString)
                oRS.MoveNext()
            Next
            'End If

        Catch ex As Exception

            B1Connections.theAppl.StatusBar.SetText(Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

        Finally

            oRS = Nothing

        End Try

    End Sub

    ''' <summary>
    ''' 화면에 Item 포함여부
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="strItemUID"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ExistsItem(ByRef oForm As SAPbouiCOM.Form, ByVal strItemUID As String) As Boolean


        Dim i As Integer
        For i = 0 To oForm.Items.Count - 1
            If (oForm.Items.Item(i).UniqueID = strItemUID) Then
                Return True
            End If
        Next

        Return False

    End Function

    Public Function GetDateStringYMDWithHypen(ByVal dt As Object) As String

        Try
            Dim strDate As String = ""

            If (dt Is Nothing) Then

            ElseIf dt.GetType().Name = "String" Then
                If IsDate(dt) Then
                    strDate = DateTime.Parse(CDate(dt)).ToString("yyyy-MM-dd")
                ElseIf (dt.ToString.Length = 8) Then

                    If (IsDate(dt.Insert(4, "-").Insert(7, "-"))) Then
                        strDate = dt.Insert(4, "-").Insert(7, "-")
                    Else
                        Return dt
                    End If


                End If
            ElseIf dt.GetType().Name = "DateTime" Then
                strDate = DateTime.Parse(dt).ToString("yyyy-MM-dd")
            End If

            Return strDate

        Catch ex As Exception
            Return ""
        End Try

    End Function

    ''' <summary>
    ''' Navigation 최종 Key값 가져옴.
    ''' </summary>
    ''' <param name="strTableId">TableID</param>
    ''' <param name="strKeyField">Search KeyField</param>
    ''' <param name="strSortField">Sort Field</param>
    ''' <param name="strStartKey">Start Key Value</param>
    ''' <param name="strNaviType">Navigator type(1290:First, 1289: Previouse, 1288:Next, 1291:Last)</param>
    ''' <param name="strWhere">Where절 - And 포함해서..</param>
    ''' <remarks></remarks>
    Public Function GetSearchMaxNum(ByVal strTableId As String _
    , ByVal strKeyField As String, ByVal strSortField As String, ByVal strStartKey As String, ByVal strNaviType As String _
    , ByVal strWhere As String) As String

        Dim Rs As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String = ""

        If (strNaviType = "1291") Then 'Last
            xSQL = " select Top 1 A." + strKeyField
            xSQL = xSQL & vbCrLf & " from " + strTableId + " A "
            xSQL = xSQL & vbCrLf & " where "
            xSQL = xSQL & vbCrLf & " 	 A." + strKeyField + " <> isnull(" + CFL.GetQD(strStartKey) + ",'')"
            xSQL = xSQL & vbCrLf & " 	" + strWhere
            xSQL = xSQL & vbCrLf & " order by A." + strSortField + " desc "

            Rs.DoQuery(xSQL)

        ElseIf (strNaviType = "1288") Then 'Next
            xSQL = " select Top 1 A." + strKeyField
            xSQL = xSQL & vbCrLf & " from " + strTableId + " A "
            xSQL = xSQL & vbCrLf & " where "
            xSQL = xSQL & vbCrLf & " 	 A." + strKeyField + " > isnull(" + CFL.GetQD(strStartKey) + ",'')"
            xSQL = xSQL & vbCrLf & " 	" + strWhere
            xSQL = xSQL & vbCrLf & " order by A." + strSortField + " asc "

            Rs.DoQuery(xSQL)

            If (Rs.RecordCount = 0) Then
                xSQL = " select Top 1 A." + strKeyField
                xSQL = xSQL & vbCrLf & " from " + strTableId + " A "
                xSQL = xSQL & vbCrLf & " where "
                xSQL = xSQL & vbCrLf & " 	 A." + strKeyField + " < isnull(" + CFL.GetQD(strStartKey) + ",'')"
                xSQL = xSQL & vbCrLf & " 	" + strWhere
                xSQL = xSQL & vbCrLf & " order by A." + strSortField + " asc "

                Rs.DoQuery(xSQL)
            End If
        ElseIf (strNaviType = "1289") Then 'Previouse
            xSQL = " select Top 1 A." + strKeyField
            xSQL = xSQL & vbCrLf & " from " + strTableId + " A "
            xSQL = xSQL & vbCrLf & " where "
            xSQL = xSQL & vbCrLf & " 	 A." + strKeyField + " <    isnull(" + CFL.GetQD(strStartKey) + ",'')"
            xSQL = xSQL & vbCrLf & " 	" + strWhere
            xSQL = xSQL & vbCrLf & " order by A." + strSortField + " desc "

            Rs.DoQuery(xSQL)

            If (Rs.RecordCount = 0) Then
                xSQL = " select Top 1 A." + strKeyField
                xSQL = xSQL & vbCrLf & " from " + strTableId + " A "
                xSQL = xSQL & vbCrLf & " where "
                xSQL = xSQL & vbCrLf & " 	 A." + strKeyField + " > isnull(" + CFL.GetQD(strStartKey) + ",'')"
                xSQL = xSQL & vbCrLf & " 	" + strWhere
                xSQL = xSQL & vbCrLf & " order by A." + strSortField + " desc "

                Rs.DoQuery(xSQL)
            End If
        ElseIf (strNaviType = "1290") Then 'First
            xSQL = " select Top 1 A." + strKeyField
            xSQL = xSQL & vbCrLf & " from " + strTableId + " A "
            xSQL = xSQL & vbCrLf & " where "
            xSQL = xSQL & vbCrLf & " 	 A." + strKeyField + " <> isnull(" + CFL.GetQD(strStartKey) + ",'')"
            xSQL = xSQL & vbCrLf & " 	" + strWhere
            xSQL = xSQL & vbCrLf & " order by A." + strSortField + " asc "

            Rs.DoQuery(xSQL)
        End If

        Return Rs.Fields.Item(0).Value.ToString().Trim()

    End Function

    

    Friend Sub CalCulAmend(ByRef oForm As SAPbouiCOM.Form, ByRef DbSrcH As SAPbouiCOM.DBDataSource, ByRef DbSrcD As SAPbouiCOM.DBDataSource, ByRef DbSrcD2 As SAPbouiCOM.DBDataSource)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()


        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double
        Dim strADTP As String

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        DbSrcD2.SetValue("U_EXCRT", 0, dRate)

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격
                strADTP = DbSrcD.GetValue("U_AMDTP", i)
                dQty = DbSrcD.GetValue("U_LCQTY", i)
                dPrc = DbSrcD.GetValue("U_LCPRC", i)
                '금액/누적금액 계산
                dAmt = dQty * dPrc

                If (strADTP <> "D") Then
                    dAmtSum = dAmtSum + dAmt

                    '환산금액/누적환산금액 계산
                    If (strCURR = strLCURR) Then '로컬통화하고 같으면

                        dAmtL = dAmt
                        dAmtLSum = dAmtLSum + dAmtL
                    Else
                        dAmtL = dAmt * dRate '환산
                        dAmtLSum = dAmtLSum + dAmtL
                    End If
                End If

                DbSrcD.SetValue("U_LCAMT", i, dAmt)
                DbSrcD.SetValue("U_LCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next

        End If

        DbSrcH.SetValue("U_ATOTAL", 0, dAmtSum)

        oMatrix = Nothing

    End Sub

    Friend Sub CalCulAmend(ByRef oForm As SAPbouiCOM.Form)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()


        Dim DbSrcH As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item("@WJS_STM05T")
        Dim DbSrcD As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item("@WJS_STM051")
        Dim DbSrcD2 As SAPbouiCOM.DBDataSource = oForm.DataSources.DBDataSources.Item("@WJS_STM052")

        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double
        Dim strADTP As String

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        DbSrcD2.SetValue("U_EXCRT", 0, dRate)

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격
                strADTP = DbSrcD.GetValue("U_AMDTP", i)
                dQty = DbSrcD.GetValue("U_LCQTY", i)
                dPrc = DbSrcD.GetValue("U_LCPRC", i)
                '금액/누적금액 계산
                dAmt = Math.Round(dQty * dPrc, dRound)

                If (strADTP <> "D") Then
                    dAmtSum = dAmtSum + dAmt

                    '환산금액/누적환산금액 계산
                    If (strCURR = strLCURR) Then '로컬통화하고 같으면

                        dAmtL = dAmt
                        dAmtLSum = dAmtLSum + dAmtL
                    Else
                        dAmtL = dAmt * dRate '환산
                        dAmtLSum = dAmtLSum + dAmtL
                    End If
                End If

                DbSrcD.SetValue("U_LCAMT", i, dAmt)
                DbSrcD.SetValue("U_LCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next

        End If


        DbSrcH.SetValue("U_ATOTAL", 0, dAmtSum)

        oMatrix = Nothing

    End Sub

    Friend Sub CalCulAmend(ByRef oForm As SAPbouiCOM.Form, ByVal bLocalYN As Boolean)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()


        Dim DbSrcH As SAPbouiCOM.DBDataSource
        Dim DbSrcD As SAPbouiCOM.DBDataSource
        Dim DbSrcD2 As SAPbouiCOM.DBDataSource

        If (Not bLocalYN) Then
            DbSrcH = oForm.DataSources.DBDataSources.Item("@WJS_STM05T")
            DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_STM051")
            DbSrcD2 = oForm.DataSources.DBDataSources.Item("@WJS_STM052")
        Else
            DbSrcH = oForm.DataSources.DBDataSources.Item("@WJS_STM07T")
            DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_STM071")
            DbSrcD2 = oForm.DataSources.DBDataSources.Item("@WJS_STM072")
        End If


        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency

        Dim dQty As Double
        Dim dPrc As Double
        Dim strADTP As String

        Dim dAmt As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        DbSrcD2.SetValue("U_EXCRT", 0, dRate)

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격

                If (Not bLocalYN) Then
                    strADTP = DbSrcD.GetValue("U_AMDTP", i)
                    dQty = DbSrcD.GetValue("U_LCQTY", i)
                    dPrc = DbSrcD.GetValue("U_LCPRC", i)
                Else
                    strADTP = DbSrcD.GetValue("U_AMDTP", i)
                    dQty = DbSrcD.GetValue("U_LLCQTY", i)
                    dPrc = DbSrcD.GetValue("U_LLCPRC", i)
                End If
                '금액/누적금액 계산
                dAmt = dQty * dPrc

                If (strADTP <> "D") Then
                    dAmtSum = dAmtSum + dAmt

                    '환산금액/누적환산금액 계산
                    If (strCURR = strLCURR) Then '로컬통화하고 같으면

                        dAmtL = dAmt
                        dAmtLSum = dAmtLSum + dAmtL
                    Else
                        dAmtL = dAmt * dRate '환산
                        dAmtLSum = dAmtLSum + dAmtL
                    End If
                End If

                If (Not bLocalYN) Then
                    DbSrcD.SetValue("U_LCAMT", i, dAmt)
                    DbSrcD.SetValue("U_LCLAMT", i, dAmtL)
                Else
                    DbSrcD.SetValue("U_LLCAMT", i, dAmt)
                    DbSrcD.SetValue("U_LLCLAMT", i, dAmtL)
                End If


                oMatrix.SetLineData(i + 1)

            Next

        End If


        DbSrcH.SetValue("U_ATOTAL", 0, dAmtSum)

        oMatrix = Nothing

    End Sub

    Friend Sub CCCalCul(ByRef oForm As SAPbouiCOM.Form, ByRef DbSrcH As SAPbouiCOM.DBDataSource, ByRef DbSrcD As SAPbouiCOM.DBDataSource)

        Dim oMatrix As SAPbouiCOM.Matrix = oForm.Items.Item("mtx1").Specific
        '편집중인 데이터 데이터소스로 올린다.
        oMatrix.FlushToDataSource()

        Dim i As Integer
        Dim strCURR As String = DbSrcH.GetValue("U_CURR", 0).Trim()
        Dim strLCURR As String = B1Connections.diCompany.GetCompanyService.GetAdminInfo.LocalCurrency
        Dim iAmtDecPoint As Integer = B1Connections.diCompany.GetCompanyService.GetAdminInfo.PriceAccuracy

        Dim dQty As Double
        Dim dPrc As Double

        Dim dAmt As Double
        Dim dQtySum As Double
        Dim dAmtL As Double
        Dim dAmtSum As Double
        Dim dAmtLSum As Double

        Dim dRate As Double = DbSrcH.GetValue("U_EXCRT", 0)
        Dim dRound As Integer = CFL.GetValue("SELECT Decimals FROM OCRN WHERE CurrCode = " & CFL.GetQD(DbSrcH.GetValue("U_CURR", 0)))

        If (oMatrix.VisualRowCount > 0) Then
            For i = 0 To DbSrcD.Size - 1

                DbSrcD.Offset = i

                '수량가격

                dQty = DbSrcD.GetValue("U_CCQTY", i)
                dPrc = DbSrcD.GetValue("U_CCPRC", i)


                If (DbSrcD.GetValue("U_CCAMT", i) <> 0) Then
                    If (dAmt <> dQty * dPrc) Then
                        dAmt = dQty * dPrc
                    Else
                        dAmt = DbSrcD.GetValue("U_CCAMT", i)
                    End If
                Else
                    ''금액/누적금액 계산
                    dAmt = dQty * dPrc
                End If
                dAmt = Math.Round(dAmt, dRound)

                dAmtSum = dAmtSum + dAmt
                dQtySum = dQtySum + dQty


                '환산금액/누적환산금액 계산
                If (strCURR = strLCURR) Then '로컬통화하고 같으면

                    dAmtL = dAmt
                    dAmtLSum = dAmtLSum + dAmtL
                Else
                    dAmtL = dAmt * dRate '환산
                    dAmtLSum = dAmtLSum + dAmtL
                End If

                DbSrcD.SetValue("U_CCAMT", i, dAmt)
                DbSrcD.SetValue("U_CCLAMT", i, dAmtL)

                oMatrix.SetLineData(i + 1)

            Next
        End If


        DbSrcH.SetValue("U_TOTAL", 0, dAmtSum)

        DbSrcH.SetValue("U_CCAMT", 0, dAmtSum)
        DbSrcH.SetValue("U_CCLAMT", 0, dAmtLSum)
        oForm.DataSources.UserDataSources.Item("edtTOQTY").Value = dQtySum

        oMatrix = Nothing

    End Sub

    Public Sub JR_PRINT(ByVal cv_TransId_s As String)


        Dim oRS As SAPbobsCOM.Recordset

        Dim i As Integer

        Dim xlFileName As String
        Dim xSql As String

        Dim cv_PrcNm1_s As String = ""
        Dim cv_PrcNm2_s As String = ""
        Dim strRptFile As String = "", strSP As String = ""
        Dim strCode As String = ""

        Try

            If LMS_COMMON.FI_CHK_AD = False Then
                Exit Sub
            End If

            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            If cv_TransId_s = "" Then

                CFL.COMMON_MESSAGE("!", CFL.GetMSG("LMS0001")) '선택된 내역이 존재하지 않습니다.
                Exit Try
            Else

                If CFL.COMMON_MESSAGE("%", CFL.GetMSG("LMS0002"), 1) = 1 Then '인쇄하시겠습니까?

                    xSql = "SELECT DimDesc FROM ODIM WHERE DimCode IN ('1', '2') ORDER BY DimCode"
#If HANA = "Y" Then
                    xSql = CFL.GetConvertHANA(xSql)
#End If
                    oRS.DoQuery(xSql)

                    If Not oRS.EoF Then

                        oRS.MoveFirst()
                        cv_PrcNm1_s = oRS.Fields.Item("DimDesc").Value
                        oRS.MoveNext()
                        cv_PrcNm2_s = oRS.Fields.Item("DimDesc").Value

                    End If


                    '환경설정정보에 셋팅된 정보를 읽는다.
                    '인쇄정보가 건별만 설정된 경우에 건별, 그룹만 설정된 경우는 그룹, 둘다 세팅된 경우 건별로 출력
                    xSql = "SELECT	CASE WHEN ISNULL(MAX(CASE WHEN ISNULL(U_PRTTP,'') = 'S01' THEN ISNULL(U_PRTTP,'') ELSE '' END),'') = '' THEN "
                    xSql = xSql & "  ISNULL(MAX(CASE WHEN ISNULL(U_PRTTP,'') = 'S02' THEN ISNULL(U_PRTTP,'') ELSE '' END),'')		"
                    xSql = xSql & " ELSE            "
                    xSql = xSql & " ISNULL(MAX(CASE WHEN ISNULL(U_PRTTP,'') = 'S01' THEN ISNULL(U_PRTTP,'') ELSE '' END),'')        "
                    xSql = xSql & " END AS GUBUN    "
                    xSql = xSql & " FROM [@WJS_SAD001]		"
                    xSql = xSql & " WHERE ISNULL(U_PRTTP,'') IN ('S01','S02')		"
                    xSql = xSql & " AND ISNULL(U_PRTFILE,'') <> '' AND ISNULL(U_PRTPROC,'') <> ''"
#If HANA = "Y" Then
                    xSql = CFL.GetConvertHANA(xSql)
#End If
                    oRS.DoQuery(xSql)

                    If Not oRS.EoF Then

                        strCode = oRS.Fields.Item("GUBUN").Value

                    End If

                    '환경설정정보에 셋팅된 정보를 읽는다.
                    xSql = "SELECT "
                    xSql = xSql & "  U_PRTTP		"
                    xSql = xSql & " ,U_PRTFILE		"
                    xSql = xSql & " ,U_PRTPROC		"
                    xSql = xSql & " FROM [@WJS_SAD001] WHERE U_PRTTP='" & strCode & "'"
#If HANA = "Y" Then
                    xSql = CFL.GetConvertHANA(xSql)
#End If
                    oRS.DoQuery(xSql)

                    If Not oRS.EoF Then

                        strRptFile = "\RPT\" + CFL.LanguageToString + "\" & oRS.Fields.Item("U_PRTFILE").Value.ToString.Substring(0, oRS.Fields.Item("U_PRTFILE").Value.ToString.LastIndexOf(".rpt")) + "_" + CFL.LanguageToString + ".rpt"
                        strSP = oRS.Fields.Item("U_PRTPROC").Value

                    End If

                    '크리스탈리포트객체생성
#If HANA = "Y" Then
                    Using rpt As WJS.COMM.H.Report = New WJS.COMM.H.Report
                        ' 리포트데이터테이블을가져오기위해Data Object 생성
                        Dim dbData As WJS.COMM.H.data.DbObject = New WJS.COMM.H.data.DbObject("WJS", "WJS", B1Connections.diCompany.Server _
                                                                            , B1Connections.diCompany.DbUserName _
                                                                            , CFL.GetSysDBPassWord(B1Connections.diCompany.DbUserName) _
                                                                            , B1Connections.diCompany.CompanyDB _
                                                                            , "")
#Else
                    Using rpt As WJS.COMM.Report = New WJS.COMM.Report
                        ' 리포트데이터테이블을가져오기위해Data Object 생성
                        Dim dbData As WJS.COMM.data.DbObject = New WJS.COMM.data.DbObject("WJS", "WJS", B1Connections.diCompany.Server _
                                                                    , B1Connections.diCompany.DbUserName _
                                                                    , CFL.GetSysDBPassWord(B1Connections.diCompany.DbUserName) _
                                                                    , B1Connections.diCompany.CompanyDB _
                                                                    , "")
#End If

                        '리포트경로설정
                        Dim pStartPath As String = System.Reflection.Assembly.GetExecutingAssembly.Location

                        pStartPath = pStartPath.Substring(0, pStartPath.LastIndexOf("\"))

                        xlFileName = strRptFile

                        xSql = "EXEC " & strSP
                        xSql = xSql & "  N''"
                        xSql = xSql & " ,N'" & cv_TransId_s & ",'"
                        xSql = xSql & " ,N'1'"
#If HANA = "Y" Then
                        xSql = CFL.GetConvertHANA(xSql)
#End If

                        '데이터테이블가져옴.
                        Using rs As System.Data.DataTable = dbData.RunSqlDT(xSql)

                            rpt.crxReport.Load(pStartPath & xlFileName)
                            rpt.crxReport.SetDataSource(rs)

                        End Using

                        '리포트파라미터설정

                        For i = 0 To rpt.crxReport.DataDefinition.FormulaFields.Count - 1
                            Select Case rpt.crxReport.DataDefinition.FormulaFields(i).Name
                                Case "DIMDESC1"
                                    rpt.crxReport.DataDefinition.FormulaFields(i).Text = "'" & cv_PrcNm1_s & "'"
                                Case "DIMDESC2"
                                    rpt.crxReport.DataDefinition.FormulaFields(i).Text = "'" & cv_PrcNm2_s & "'"

                            End Select
                        Next

                        'Report Viewer 실행
                        LMS_COMMON.RptShow2(rpt)

                        'Data Object 리소스해제
                        dbData.Dispose()

                        '크리스탈리포트객체리소스해제
                    End Using

                Else
                    Exit Try
                End If

            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("JR_PRINT " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try

    End Sub

    ''' <summary>
    ''' 크리스탈 리포트 팝업
    ''' </summary>
    ''' <param name="rpt"></param>
    ''' <remarks></remarks>
#If HANA = "Y" Then
    Public Sub RptShow2(ByRef rpt As WJS.COMM.H.Report)
#Else
    Public Sub RptShow2(ByRef rpt As WJS.COMM.Report)
#End If

        Dim strStartPath As String = System.Reflection.Assembly.GetExecutingAssembly.Location
        Dim strReportPath As String
        Dim strExportPath As String
        Dim proc As Process

        Try
            strStartPath = strStartPath.Substring(0, strStartPath.LastIndexOf("\"))

            If (System.IO.File.Exists(strStartPath + "\CrystalViewer.exe")) Then

                strReportPath = rpt.crxReport.FileName

                'My.Computer.FileSystem.SpecialDirectories.Temp

                strExportPath = My.Computer.FileSystem.SpecialDirectories.Temp + strReportPath.Substring(strReportPath.LastIndexOf("\"), strReportPath.Length - strReportPath.LastIndexOf("\"))

                rpt.crxReport.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.CrystalReport, strExportPath)

                proc = New System.Diagnostics.Process
                proc.StartInfo.FileName = strStartPath + "\CrystalViewer.exe"
                proc.StartInfo.Arguments = " """ & strExportPath & """"
                proc.Start()

            Else
                'Report Viewer 실행
                rpt.ShowDialog(CFL.GetSBOWindow())
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("RptShow Error : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            proc = Nothing

            If IsNothing(rpt) = False Then
                rpt.crxReport.Close()
                rpt.crxReport.Dispose()
                rpt.Close()
                rpt.Dispose()
                rpt = Nothing
                GC.Collect()
            End If

        End Try

    End Sub

    Public Function DistNumberCaption() As String
        Dim strReturn As String = ""

        strReturn = CFL.GetCaption(CFL.GetValue("SELECT ISNULL(U_DISTCAP,N'일련번호') FROM [@WJS_SCO01M]"), ModuleIni.CO)

        Return strReturn
    End Function

    Public Function DistNumberVisible_Product() As Boolean

        Try

            If CFL.GetValue("SELECT TOP 1 1 FROM [@WJS_SCO111] WHERE U_CITGBN IN ('S02','S03') AND U_STEMH = 'S06'") = "1" Then
                DistNumberVisible_Product = True
            Else
                DistNumberVisible_Product = False
            End If

        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("DistNumberVisible_Product" & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally

        End Try

    End Function
    Public Function GetCountryCode() As String
        Dim strReturn As String = ""

        strReturn = CFL.GetValue("SELECT Country FROM OADM")

        Return strReturn
    End Function
    Public Function DateSepAdd() As Boolean

        Dim strQ As String = "SELECT ISNULL(MAX(U_USEYN), 'N') AS VAL FROM [@WJS_SAD011] WHERE Code = 'AD97'"
        Dim strYN As String = CFL.GetValue(strQ)

        If strYN = "Y" Then
            Return True
        Else
            Return False
        End If

    End Function
    ''' <summary>
    ''' Date(yyyy-MM-dd hh:mm:ss)변수를 받아 SBO에서 정의한 달 표시 원칙에 따라 string을 Return 한다.
    ''' </summary>
    ''' <param name="dt">Date Type</param>
    ''' <returns>SBO정의한 달 표시원칙에 따라 년월을 리턴함</returns>
    ''' <remarks></remarks>
    Public Function ConvertSBOMonth(dt As Date) As String

        '0	DD/MM/YY																																														
        '1	DD/MM/CCYY																																														
        '2	MM/DD/YY																																														
        '3	MM/DD/CCYY																																														
        '4	CCYY/MM/DD																																														
        '5	YYYY/MM/DD																																														
        '6	YY/MM/DD																																														

        Dim strDateFormat As String = CFL.GetValue("SELECT TOP 1 DateFormat from OADM")
        Dim strDateSep As String = CFL.GetValue("SELECT TOP 1 DateSep from OADM")

        Dim YYYY As String = dt.Year
        Dim MM As String = dt.Month
        Dim strReturnDate As String = String.Empty

        MM = Right("0" & MM, 2)


        If Not DateSepAdd() Then
            strDateSep = String.Empty
        End If

        Select Case strDateFormat

            Case 0
                Return MM & strDateSep & Right(YYYY, 2)
            Case 1 'DD/MM/CCYY																																															
                Return MM & strDateSep & YYYY
            Case 2
                Return MM & strDateSep & Right(YYYY, 2)
            Case 3
                Return MM & strDateSep & YYYY
            Case 4
                Return YYYY & strDateSep & MM
            Case 5
                Return YYYY & strDateSep & MM
            Case 6
                Return Right(YYYY, 2) & strDateSep & MM
        End Select


    End Function

    ''' <summary>
    ''' YYYYMMDD를 받아 SBO에 정의한 날짜 포맷으로 변경하여 Return 한다
    ''' </summary>
    ''' <param name="dt">YYYYMMDD형태의 문자열</param>
    ''' <returns>SBO날짜 포맷으로 년월일을 변환</returns>
    ''' <remarks></remarks>

    Public Function ConvertSBODate(dt As String) As String

        '0	DD/MM/YY																																														
        '1	DD/MM/CCYY																																														
        '2	MM/DD/YY																																														
        '3	MM/DD/CCYY																																														
        '4	CCYY/MM/DD																																														
        '5	YYYY/MM/DD																																														
        '6	YY/MM/DD																																														

        Dim strDateFormat As String = CFL.GetValue("SELECT TOP 1 DateFormat from OADM")
        Dim strDateSep As String = CFL.GetValue("SELECT TOP 1 DateSep from OADM")

        Dim YYYY As String = dt.Substring(0, 4)
        Dim MM As String = dt.Substring(4, 2)
        Dim DD As String = dt.Substring(6, 2)


        If Not DateSepAdd() Then
            strDateSep = String.Empty
        End If

        Select Case strDateFormat

            Case 0
                Return DD & strDateSep & MM & strDateSep & Right(YYYY, 2)
            Case 1 'DD/MM/CCYY																																															
                Return DD & strDateSep & MM & strDateSep & YYYY
            Case 2
                Return MM & strDateSep & DD & strDateSep & Right(YYYY, 2)
            Case 3
                Return MM & strDateSep & DD & strDateSep & YYYY
            Case 4
                Return YYYY & strDateSep & MM & strDateSep & DD
            Case 5
                Return YYYY & strDateSep & MM & strDateSep & DD
            Case 6
                Return Right(YYYY, 2) & strDateSep & MM & strDateSep & DD
        End Select


    End Function

    '******************************************************
    '리모트 서비스 관련
    '******************************************************

    Public Function UrlEncode(ByVal Text As String) As String
        Dim i As Integer
        Dim Ansi() As Byte
        Dim AsciiCode As Short
        Dim strEncode As String


        Ansi = System.Text.Encoding.UTF8.GetBytes(Text)
        strEncode = ""


        For i = 0 To UBound(Ansi)
            AsciiCode = Ansi(i)


            Select Case AsciiCode
                Case 48 To 57, 65 To 90, 97 To 122
                    strEncode = strEncode & Chr(AsciiCode)
                Case 32
                    strEncode = strEncode & "+"
                Case Else
                    If AsciiCode < 16 Then
                        strEncode = strEncode & "%0" & Hex(AsciiCode)
                    Else
                        strEncode = strEncode & "%" & Hex(AsciiCode)
                    End If
            End Select
        Next i
        UrlEncode = strEncode
    End Function

    Public Function SendEmail(ByVal sendusing As Integer, ByVal smtpserver As String, ByVal smtpserverport As Integer, ByVal smtpconnectiontimeout As Integer, ByVal smtpauthenticate As Integer _
    , ByVal cdoSendUserName As String, ByVal cdosendpassword As String, ByVal smtpusessl As Integer, ByVal sendusername As String, ByVal sendpassword As String _
    , ByVal mailFrom As String, ByVal mailTo As String, ByVal mailCC As String, ByVal isHTLM As Boolean, ByVal mailSubject As String, ByVal mailBody As String _
    , ByVal mailAttachs As String(), ByVal ImgPath As String, ByVal ImgContent As String) As Boolean

        Dim mail As MailMessage = Nothing

        SendEmail = False

        Try

            ' 메일을 전송합니다.

            mail = New MailMessage()


            mail.From = New MailAddress(mailFrom)

            mailTo = mailTo.Replace(",", " ")
            Dim mailTos() As String = Split(mailTo)

            For i As Integer = 0 To mailTos.Length - 1
                If mailTos(i) <> "" Then
                    mail.To.Add(New MailAddress(mailTos(i)))
                End If
            Next

            mailCC = mailCC.Replace(",", " ")
            Dim mailCcs() As String = Split(mailCC)

            For i As Integer = 0 To mailCcs.Length - 1
                If mailCcs(i) <> "" Then
                    mail.CC.Add(New MailAddress(mailCcs(i)))
                End If
            Next

            mail.Subject = mailSubject
            mail.Body = mailBody
            mail.IsBodyHtml = isHTLM

            Dim iPort As Integer
            iPort = Integer.Parse(smtpserverport)

            Dim smtp As SmtpClient = New SmtpClient(smtpserver, iPort)

            'smtp.DeliveryMethod = SmtpDeliveryMethod.Network
            'Relay IP 방식으로 사용되는 메일서버에서는 사용할 수 없음(다하미)
            If sendpassword <> "" Then
                smtp.UseDefaultCredentials = True

                smtp.Credentials = New NetworkCredential(sendusername, sendpassword)
            End If

            If smtpusessl <> 0 Then
                smtp.EnableSsl = True
            End If

            If mailAttachs.Length > 1 Then
                For iSeq As Integer = 0 To mailAttachs.Length - 1
                    If Not (mailAttachs(iSeq) = Nothing) Then
                        mail.Attachments.Add(New System.Net.Mail.Attachment(mailAttachs(iSeq)))
                    End If
                Next
            End If

            If ImgContent <> "" Then
                Dim ImgAttach As System.Net.Mail.Attachment
                ImgAttach = New System.Net.Mail.Attachment(ImgPath)
                ImgAttach.ContentId = ImgContent
                mail.Attachments.Add(ImgAttach)
            End If

            smtp.Timeout = 1 * smtpconnectiontimeout * 10
            smtp.Send(mail)


            SendEmail = True


        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("SendEmail - " & ex.ToString() & " -" & ex.Message.ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

            SendEmail = False
        Finally
            For iSeq As Integer = 0 To mail.Attachments.Count - 1
                mail.Attachments(iSeq).Dispose()
            Next

            mail = Nothing
            'oMail = Nothing
        End Try

    End Function
    'Public Function ValidateHeader(ByVal oForm As SAPbouiCOM.Form) As Boolean
    '    Dim c_Status_b As Boolean = False
    '    Dim oUserData As SAPbouiCOM.UserDataSources
    '    Dim DbSrc As SAPbouiCOM.DBDataSource
    '    Dim DbSrcD As SAPbouiCOM.DBDataSource
    '    oUserData = oForm.DataSources.UserDataSources
    '    DbSrc = oForm.DataSources.DBDataSources.Item("@WJS_UPP02M_LMS")
    '    DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_UPP021_LMS")
    '    Try
    '        If DbSrc.GetValue("U_PLCD", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0067"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_UITEMNM", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0054"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '        ElseIf DbSrc.GetValue("U_TWGT", 0) = 0 Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0073"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '        ElseIf DbSrc.GetValue("U_MWGT", 0) = 0 Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0427"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_ITEMGP", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0253"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_SHAPE", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0070"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_ALLOY", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0071"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_HT", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0072"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_SHT", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0133"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_L1CATG", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0069"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_UOM", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0066"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_ITEMTP", 0) = "D" And DbSrc.GetValue("U_NITEMCD", 0) = "" Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0075"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_ITEMTP", 0) = "D" And Len(DbSrc.GetValue("U_NITEMCD", 0)) <> 9 Then
    '            B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0481"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '            c_Status_b = False
    '        ElseIf DbSrc.GetValue("U_SHAPE", 0) = "RE" Or DbSrc.GetValue("U_SHAPE", 0) = "RD" Or DbSrc.GetValue("U_SHAPE", 0) = "HE" Or DbSrc.GetValue("U_SHAPE", 0) = "HD" Then
    '            If DbSrc.GetValue("U_LENGTH", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0135"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_OD", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0234"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_ODTOLP", 0) = 0 And DbSrc.GetValue("U_ODTOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0235"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_SIZETOLP", 0) = 0 And DbSrc.GetValue("U_SIZETOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0243"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_STRTTOLP", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0245"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            Else
    '                c_Status_b = True
    '            End If
    '        ElseIf DbSrc.GetValue("U_SHAPE", 0) = "QD" Or DbSrc.GetValue("U_SHAPE", 0) = "QE" Then
    '            If DbSrc.GetValue("U_LENGTH", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0135"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_OD", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0234"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_ODTOLP", 0) = 0 And DbSrc.GetValue("U_ODTOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0235"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_SIZETOLP", 0) = 0 And DbSrc.GetValue("U_SIZETOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0243"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_STRTTOLP", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0245"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_THICK", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0240"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_THICKTOLP", 0) = 0 And DbSrc.GetValue("U_THICKTOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0241"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            Else
    '                c_Status_b = True
    '            End If

    '        ElseIf DbSrc.GetValue("U_SHAPE", 0) = "TE" Or DbSrc.GetValue("U_SHAPE", 0) = "TD" Then
    '            If DbSrc.GetValue("U_LENGTH", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0135"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_OD", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0234"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_ODTOLP", 0) = 0 And DbSrc.GetValue("U_ODTOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0235"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_ID", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0237"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_IDTOLP", 0) = 0 And DbSrc.GetValue("U_IDTOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0238"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_SIZETOLP", 0) = 0 And DbSrc.GetValue("U_SIZETOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0243"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_STRTTOLP", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0245"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_THICK", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0240"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_THICKTOLP", 0) = 0 And DbSrc.GetValue("U_THICKTOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0241"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            Else
    '                c_Status_b = True
    '            End If
    '        ElseIf DbSrc.GetValue("U_SHAPE", 0) = "SS" Then
    '            If DbSrc.GetValue("U_LENGTH", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0135"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False

    '                'ElseIf DbSrc.GetValue("U_OD", 0) = 0 Then
    '                '    B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0234"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                '    c_Status_b = False

    '            ElseIf DbSrc.GetValue("U_SIZETOLP", 0) = 0 And DbSrc.GetValue("U_SIZETOLM", 0) = 0 Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0243"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            ElseIf DbSrc.GetValue("U_DRAWNO", 0) = "" Then
    '                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG("LMS0246"), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
    '                c_Status_b = False
    '            Else
    '                c_Status_b = True
    '            End If
    '        Else
    '            c_Status_b = True
    '        End If
    '    Catch ex As Exception
    '        B1Connections.theAppl.StatusBar.SetText("ValidateHeader " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
    '    Finally

    '    End Try
    '    Return c_Status_b
    'End Function

    Public Function ValidateHeader(ByVal oForm As SAPbouiCOM.Form, ByVal sTBID As String, ByVal sCHKTP As String) As Boolean
        Dim c_Status_b As Boolean = False
        Dim oUserData As SAPbouiCOM.UserDataSources
        Dim xsql As String = ""
        Dim DbSrc As SAPbouiCOM.DBDataSource
        Dim oRS As SAPbobsCOM.Recordset
        oUserData = oForm.DataSources.UserDataSources
        DbSrc = oForm.DataSources.DBDataSources.Item(sTBID)

        Try
            oRS = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

            If sTBID = "@WJS_UPP02M_LMS" Then
                xsql = " EXEC WJS_SP_PPA0090F7_LMS "
                xsql = xsql & " " & CFL.GetQD(sTBID)
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_UITEMCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_UITEMNM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ITEMGP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ITEMTP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_PLCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SHAPE", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ALLOY", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_HT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SHT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_MROUT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_L1CATG", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_UOM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_OD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ID", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_THICK", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_LENGTH", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_CITEMCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_NITEMCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ODTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ODTOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_IDTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_IDTOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_THICKTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_THICKTOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SIZETOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SIZETOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_STRTTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_DRAWNO", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_TWGT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_MWGT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SALLOY", 0))
                xsql = xsql & " ," & CFL.GetQD(sCHKTP)
            ElseIf sTBID = "@WJS_USD01T_LMS" Then
                xsql = " EXEC WJS_SP_PPA0090F7_LMS "
                xsql = xsql & " " & CFL.GetQD(sTBID)
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ITEMCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ITEMNM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ITEMGP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ITEMTP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_PLCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SHAPE", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ALLOY", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_HT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SHT", 0))
                xsql = xsql & " , '' "
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_L1CATG", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_UOM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_OD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ID", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_THICK", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_LENGTH", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_CITEMCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_NITEMCD", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ODTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_ODTOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_IDTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_IDTOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_THICKTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_THICKTOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SIZETOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SIZETOLM", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_STRTTOLP", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_DRAWNO", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_TWGT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_MWGT", 0))
                xsql = xsql & " ," & CFL.GetQD(DbSrc.GetValue("U_SALLOY", 0))
                xsql = xsql & " ," & CFL.GetQD(sCHKTP)
            End If
            oRS.DoQuery(xsql)
            If oRS.Fields.Item("RTNCD").Value <> "" Then
                B1Connections.theAppl.StatusBar.SetText(CFL.GetMSG(oRS.Fields.Item("RTNCD").Value), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                c_Status_b = False
            Else
                c_Status_b = True
            End If



        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("ValidateHeader " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
            DbSrc = Nothing
            oUserData = Nothing
        End Try
        Return c_Status_b
    End Function

    Public Sub DefineNew(oForm As SAPbouiCOM.Form)
        Dim oUserData As SAPbouiCOM.UserDataSources
        Dim DbSrc As SAPbouiCOM.DBDataSource
        Dim DbSrcD As SAPbouiCOM.DBDataSource
        Dim oMatrix As SAPbouiCOM.Matrix
        Dim cv_SetCol_s As String = "ITEMCD, ITEMNM, ITMSGRPCOD, BQTY, OD, ID, THK, BLENGTH, TWGT, MWGT"
        Dim cv_SetColNm_s As String = "품목, 품목명, 품목그룹, 투입소요량, O.D, I.D, Thick, Length, 이론중량, 단중"
        Dim cv_NoEditablCol_s As String = "ITMSGRPCOD, OD, ID, THK, BLENGTH, TWGT, MWGT"
        Dim cv_NoEditablCol_s2 As String = "ITEMCD, ITEMNM, ITMSGRPCOD, BQTY, OD, ID, THK, BLENGTH, TWGT, MWGT"
        Dim cv_RightAlignCol_s As String = "BQTY, OD, ID, THK, BLENGTH, TWGT, MWGT, OD, ID"
        Dim cv_NoVisibleCol_s As String = ""
        Dim oGrid As SAPbouiCOM.Grid
        oMatrix = oForm.Items.Item("mtx").Specific
        oUserData = oForm.DataSources.UserDataSources
        DbSrc = oForm.DataSources.DBDataSources.Item("@WJS_UPP02M_LMS")
        DbSrcD = oForm.DataSources.DBDataSources.Item("@WJS_UPP021_LMS")
        Try
            oForm.Freeze(True)
            DbSrc.SetValue("U_UITEMCD", 0, "")
            DbSrc.SetValue("U_UITEMNM", 0, "")
            DbSrc.SetValue("U_ITEMGP", 0, "")
            DbSrc.SetValue("U_ITEMTP", 0, "P")
            DbSrc.SetValue("U_PLCD", 0, "A")
            DbSrc.SetValue("U_SHAPE", 0, "")
            DbSrc.SetValue("U_ALLOY", 0, "")
            DbSrc.SetValue("U_SALLOY", 0, "")
            oUserData.Item("edtALNM").Value = ""
            oUserData.Item("edtHTNM").Value = ""
            DbSrc.SetValue("U_HT", 0, "")
            DbSrc.SetValue("U_SHT", 0, "")
            DbSrc.SetValue("U_SHAPE", 0, "")
            DbSrc.SetValue("U_MROUT", 0, "Y")
            oUserData.Item("edtRVHTCD").Value = ""
            DbSrc.SetValue("U_L1CATG", 0, "")
            DbSrc.SetValue("U_UOM", 0, "")
            DbSrc.SetValue("U_OD", 0, 0)
            DbSrc.SetValue("U_ID", 0, 0)
            DbSrc.SetValue("U_THICK", 0, 0)
            DbSrc.SetValue("U_LENGTH", 0, 0)
            DbSrc.SetValue("U_CITEMCD", 0, "")
            DbSrc.SetValue("U_NITEMCD", 0, "")
            DbSrc.SetValue("U_ODTOLP", 0, 0)
            DbSrc.SetValue("U_IDTOLP", 0, 0)
            DbSrc.SetValue("U_THICKTOLP", 0, 0)
            DbSrc.SetValue("U_SIZETOLP", 0, 0)
            DbSrc.SetValue("U_STRTTOLP", 0, 0)
            DbSrc.SetValue("U_ODTOLM", 0, 0)
            DbSrc.SetValue("U_IDTOLM", 0, 0)
            DbSrc.SetValue("U_THICKTOLM", 0, 0)
            DbSrc.SetValue("U_SIZETOLM", 0, 0)
            'DbSrc.SetValue("U_STRTTOLM", 0, 0)
            DbSrc.SetValue("U_DRAWNO", 0, "")
            DbSrc.SetValue("U_SOENTRY", 0, 0)
            DbSrc.SetValue("U_SOLINENUM", 0, 0)
            DbSrc.SetValue("U_TWGT", 0, 0)
            DbSrc.SetValue("U_MWGT", 0, 0)
            oUserData.Item("edtCRDT").ValueEx = CFL.GetValue("SELECT CONVERT(NVARCHAR(10),GetDate(),112) ")
            DbSrc.SetValue("U_USERID", 0, B1Connections.diCompany.UserName)
            DbSrc.SetValue("U_USERNM", 0, CFL.GetValue("SELECT U_NAME FROM OUSR WHERE USER_CODE ='" & B1Connections.diCompany.UserName & "' "))
            oUserData.Item("edtUPDT").Value = ""
            oUserData.Item("edtUPTM").Value = ""
            oMatrix.Clear()
            DbSrcD.Clear()
            oGrid = oForm.Items.Item("grd1").Specific
            oGrid.DataTable.Clear()
            Call SetGridTitle(oGrid, cv_SetCol_s, cv_SetColNm_s, cv_NoEditablCol_s, cv_NoVisibleCol_s, "", "", "", "")
            'HeaderEnable(oForm, True)
            oForm.Mode = BoFormMode.fm_ADD_MODE
            oForm.Freeze(False)
        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("DefineNew " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oForm.Freeze(False)
        End Try

    End Sub

    Public Sub SetBPLid(ByVal oComboBox As SAPbouiCOM.ComboBox)

        Dim xSQL As String
        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        xSQL = ""
        xSQL = xSQL & "SELECT T1.U_BACD "
        xSQL = xSQL & "FROM [@WJS_SAD51M] T0 "
        xSQL = xSQL & "INNER JOIN [@WJS_SAD511] T1 ON T0.Code = T1.Code "
        xSQL = xSQL & "WHERE ISNULL(T1.U_DFTYN, 'N') = 'Y'"
        xSQL = xSQL & "	AND T0.U_USERID = '" & B1Connections.diCompany.UserName() & "' "

        oRS.DoQuery(xSQL)

        If Not oRS.EoF Then
            oComboBox.Select(oRS.Fields.Item("U_BACD").Value, BoSearchKey.psk_ByValue)
        End If

    End Sub

    Public Sub SetCulture()
        Dim culture As System.Globalization.CultureInfo
        culture = System.Globalization.CultureInfo.CreateSpecificCulture("ko-KR")
        culture.NumberFormat.CurrencyDecimalSeparator = "."
        culture.NumberFormat.NumberDecimalSeparator = "."
        culture.NumberFormat.CurrencyGroupSeparator = ","
        culture.NumberFormat.NumberGroupSeparator = ","

        culture.DateTimeFormat.ShortDatePattern = "yyyy-MM-dd"
        System.Threading.Thread.CurrentThread.CurrentCulture = culture
        System.Threading.Thread.CurrentThread.CurrentUICulture = culture
    End Sub

#Region "그룹웨어 전자결재"

    ''' <summary>
    ''' 구매오더 전자결재 OPEN
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="DocEntry"></param>
    ''' <param name="ie"></param>
    ''' <remarks></remarks>
    Public Sub SENDOPOR(ByVal oForm As SAPbouiCOM.Form, DocEntry As String, ByRef ie As SHDocVw.InternetExplorer)

        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSH As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSD As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String
        Dim encoding As New UTF8Encoding
        Dim cv_GWURL_s As String = ""
        Dim cv_FormId_s As String = ""
        Dim cv_ApprDocNo_s As String = ""
        Dim cv_APIKEY_s As String = ""
        Dim byteData As Byte()

        Dim cv_Jason_s As String
        Dim cv_body_s As String
        Dim cv_EmpNo_s As String
        Dim cv_TITLE_s As String = ""
        Dim cv_DOCTYPE_s As String
        Dim i As Integer
        Dim vHeaders As Object

        Try
            cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN ISNULL(T1.U_DTCRDNO, '') <> '' THEN ISNULL(T1.U_DTCRDNO, '') ELSE T0.U_EMPNO END FROM ODRF T0 LEFT OUTER JOIN OSLP T2 ON T0.SlpCode = T2.SlpCode LEFT OUTER JOIN [@WJS_SHR11M] T1 ON T2.U_EMPNO = T1.U_EMPNO WHERE T0.DocEntry = '" & DocEntry & "'")

            'cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN ISNULL(T1.U_EMPNO, '') <> '' THEN ISNULL(T1.U_EMPNO, '') ELSE T0.U_EMPNO END FROM ODRF T0 LEFT OUTER JOIN OSLP T1 ON T0.SlpCode = T1.SlpCode WHERE T0.DocEntry = '" & DocEntry & "'")
            xSQL = " EXEC WJS_SP_AD_COR142F2_LMS "
            xSQL = xSQL & "  " & CFL.GetQD(DocEntry)
            xSQL = xSQL & ", " & CFL.GetQD(cv_EmpNo_s)

            oRS.DoQuery(xSQL)

            cv_ApprDocNo_s = oRS.Fields.Item("ApprDocNo").Value
            cv_FormId_s = oRS.Fields.Item("FormId").Value
            cv_GWURL_s = oRS.Fields.Item("GWURL").Value
            cv_APIKEY_s = oRS.Fields.Item("APIKEY").Value

            xSQL = " EXEC WJS_SP_AD_COR142F3_LMS "
            xSQL = xSQL & "  'H' "
            xSQL = xSQL & ", '" & cv_ApprDocNo_s & "'"

            oRSH.DoQuery(xSQL)

            xSQL = " EXEC WJS_SP_AD_COR142F3_LMS "
            xSQL = xSQL & "  'D' "
            xSQL = xSQL & ", '" & cv_ApprDocNo_s & "'"

            oRSD.DoQuery(xSQL)

            cv_TITLE_s = oRSH.Fields.Item("FORMTITLE").Value.ToString()
            cv_TITLE_s = Left(cv_TITLE_s, 59)   '59자 제한
            cv_DOCTYPE_s = oRSH.Fields.Item("DocType").Value.ToString()

            ' 헤더
            cv_body_s = ""
            cv_body_s = cv_body_s + "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><body><table style='width:100%;' > "
            cv_body_s = cv_body_s + "<tr>"
            cv_body_s = cv_body_s + "<td style='width:100%;' >"
            cv_body_s = cv_body_s + "<table border='2' style='border-spacing:0;padding:0;width:100%;' >"
            cv_body_s = cv_body_s + "<tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>PO No.</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("DocEntry").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("전기일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("DocDate").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("입고예정일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("DocDueDate").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("공급업체") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5' >" + oRSH.Fields.Item("CardName").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("사업장") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("BPLID").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("담당자") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("SlpCode").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:120px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;' colspan='2'>" + CFL.GetCaption("비고") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:93%;text-align:left; padding-left:5px;' colspan='19'>" + oRSH.Fields.Item("Comments").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr></td> </table></tr>"

            ' 디테일 
            If cv_DOCTYPE_s = "I" Then

                cv_body_s = cv_body_s + "<tr style='height:30px;'> <td style='width:100%;' ><table border='2' style='border-spacing:0;padding:0;width:100%;' > <tr style='height:30px;'> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;' colspan='2'>" + CFL.GetCaption("품목코드") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:22%;text-align:center;' colspan='5'>" + CFL.GetCaption("품목명") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:20%;text-align:center;' colspan='5'>" + CFL.GetCaption("품목상세") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("단위") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("수량") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("통화") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("단가") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("금액") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:4%;text-align:center;'>" + CFL.GetCaption("세금그룹") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("세액") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:9%;text-align:center;' colspan='2'>" + CFL.GetCaption("총금액") + "</td>"
                cv_body_s = cv_body_s + "</tr> </tr>"

                For i = 1 To oRSD.RecordCount

                    cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='2'>" + oRSD.Fields.Item("ItemCode").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='5'>" + oRSD.Fields.Item("ItemName").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='5'>" + oRSD.Fields.Item("ItemDetail").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("Unit").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Quantity").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Price").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("VatCode").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;' colspan='2'>" + oRSD.Fields.Item("Amount").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "</tr>"

                    oRSD.MoveNext()
                Next

                oRSD.MoveLast()
                cv_body_s = cv_body_s + "<tr style='height:30px;'> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='13' >" + CFL.GetCaption("합 계") + "</td> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Quantity_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Amount_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"

                'ElseIf cv_DOCTYPE_s = "S" Then

                '    cv_body_s = cv_body_s + "<tr style='height:30px;'>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;' colspan='2'></td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:22%;text-align:center;' colspan='5'>" + CFL.GetCaption("내역") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:20%;text-align:center;' colspan='5'>" + CFL.GetCaption("계정과목") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("구매단위") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("수량") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("통화") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("단가") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("금액") + "</td>"
                '    cv_body_s = cv_body_s + "<td st0yle='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;'>" + CFL.GetCaption("세금그룹") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("세액") + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;'>" + CFL.GetCaption("총금액") + "</td>"
                '    cv_body_s = cv_body_s + "</tr>"

                '    For i = 1 To oRSD.RecordCount

                '        cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                '        cv_body_s = cv_body_s + "<td style='text-align:left;padding:0px;border:1;padding-left:5px;' colspan='2'></td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:left;padding:0px;border:1;padding-left:5px;' colspan='5'>" + oRSD.Fields.Item("ITEMNM").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:left;padding:0px;border:1;padding-left:5px;' colspan='5'>" + oRSD.Fields.Item("ACCTNM").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;padding-left:5px;'></td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'></td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'></td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='2'>" + oRSD.Fields.Item("VatCode").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Amount").Value.ToString() + "</td>"
                '        cv_body_s = cv_body_s + "</tr>"

                '        oRSD.MoveNext()
                '    Next

                '    oRSD.MoveLast()
                '    cv_body_s = cv_body_s + "<tr style='height:30px;'> "
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='13' >" + CFL.GetCaption("합 계") + "</td> "
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'></td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' ></td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt_Total").Value.ToString() + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='2'></td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt_Total").Value.ToString() + "</td>"
                '    cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Amount_Total").Value.ToString() + "</td>"
                '    cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"

            End If

            cv_TITLE_s = UrlEncode(cv_TITLE_s)
            cv_body_s = UrlEncode(cv_body_s)
            cv_APIKEY_s = UrlEncode(cv_APIKEY_s)

            cv_Jason_s = "formId=" & cv_FormId_s & "&userId=" & cv_EmpNo_s & "&apiConsumerkey=" & cv_APIKEY_s & "&orgApprDocNo=" & cv_ApprDocNo_s & "&apprTitle=" & cv_TITLE_s & "&formEditorData=" & cv_body_s
            'cv_Jason_s = "formId=FORM00590003&userId=admin&apiConsumerkey=" + cv_APIKEY_s + "&orgApprDocNo=aaddff&apprTitle=결재 상신 테스트 제목  &formEditorData=테스트 본문"

            byteData = encoding.GetBytes(cv_Jason_s)

            vHeaders = "Content-Type: application/x-www-form-urlencoded" + Chr(10) + Chr(13)

            Try
                If Not ie Is Nothing Then           ' 분개장 결재창이 띄워져 있는 상태면
                    ie.Quit()                       ' 그 창을 닫아버린다. 만약 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 예외처리함.
                End If

            Catch ex As Exception
                ' 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 그 에러 메세지는 무시하기 위해 Try Catch 문을 써서 에러처리를 함.
            End Try

            ie = New SHDocVw.InternetExplorer()     ' 새로 객체 할당 후 보이게 함..
            ie.Visible = True
            ie.Navigate2(cv_GWURL_s, "POST", , byteData, vHeaders)

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
            B1Connections.theAppl.StatusBar.SetText("SENDOPOR ERROR : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub

    ''' <summary>
    ''' AP선금요청 전자결재 OPEN
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="DocEntry"></param>
    ''' <param name="ie"></param>
    ''' <remarks></remarks>
    Public Sub SENDODPO(ByVal oForm As SAPbouiCOM.Form, DocEntry As String, ByRef ie As SHDocVw.InternetExplorer)

        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSH As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSD As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String
        Dim encoding As New UTF8Encoding
        Dim cv_GWURL_s As String = ""
        Dim cv_FormId_s As String = ""
        Dim cv_ApprDocNo_s As String = ""
        Dim cv_APIKEY_s As String = ""
        Dim byteData As Byte()

        Dim cv_Jason_s As String
        Dim cv_body_s As String
        Dim cv_EmpNo_s As String
        Dim cv_TITLE_s As String = ""
        Dim cv_DOCTYPE_s As String

        Dim i As Integer
        Dim vHeaders As Object

        Try

            xSQL = ""
            xSQL = xSQL & " SELECT CASE WHEN ISNULL(T1.U_DTCRDNO, '') <> '' THEN ISNULL(T1.U_DTCRDNO, '') ELSE T0.U_EMPNO END "
            xSQL = xSQL & " FROM ODRF T0 "
            xSQL = xSQL & " LEFT OUTER JOIN OSLP T2 ON T0.SlpCode = T2.SlpCode "
            xSQL = xSQL & " LEFT OUTER JOIN [@WJS_SHR11M] T1 ON T2.U_EMPNO = T1.U_EMPNO "
            xSQL = xSQL & " WHERE T0.DocEntry = '" & DocEntry & "'"
            cv_EmpNo_s = CFL.GetValue(xSQL)
            'cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN ISNULL(T1.U_EMPNO, '') <> '' THEN ISNULL(T1.U_EMPNO, '') ELSE T0.U_EMPNO END FROM ODRF T0 LEFT OUTER JOIN OSLP T1 ON T0.SlpCode = T1.SlpCode WHERE T0.DocEntry = '" & DocEntry & "'")

            xSQL = " EXEC WJS_SP_AD_COR65309F2_LMS "                    'EXEC WJS_SP_AD_COR65309F2_XCE
            xSQL = xSQL & "  " & CFL.GetQD(DocEntry)
            xSQL = xSQL & ", " & CFL.GetQD(cv_EmpNo_s)

            oRS.DoQuery(xSQL)

            cv_ApprDocNo_s = oRS.Fields.Item("ApprDocNo").Value
            cv_FormId_s = oRS.Fields.Item("FormId").Value
            cv_GWURL_s = oRS.Fields.Item("GWURL").Value
            cv_APIKEY_s = oRS.Fields.Item("APIKEY").Value

            xSQL = " EXEC WJS_SP_AD_COR65309F3_LMS "                    'EXEC WJS_SP_AD_COR65309F3_XCE
            xSQL = xSQL & "  'H' "
            xSQL = xSQL & ", '" & cv_ApprDocNo_s & "'"

            oRSH.DoQuery(xSQL)

            cv_TITLE_s = oRSH.Fields.Item("FORMTITLE").Value.ToString()
            cv_TITLE_s = Left(cv_TITLE_s, 59)   '59자 제한
            cv_DOCTYPE_s = oRSH.Fields.Item("DocType").Value.ToString()

            xSQL = " EXEC WJS_SP_AD_COR65309F3_LMS "                    'EXEC WJS_SP_AD_COR65309F3_XCE
            xSQL = xSQL & "  'D' "
            xSQL = xSQL & ", '" & cv_ApprDocNo_s & "'"

            oRSD.DoQuery(xSQL)

            ' 헤더
            cv_body_s = ""
            cv_body_s = cv_body_s + "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><body><table style='width:100%;' > "
            cv_body_s = cv_body_s + "<tr>"
            cv_body_s = cv_body_s + "<td style='width:100%;' >"
            cv_body_s = cv_body_s + "<table border='2' style='border-spacing:0;padding:0;width:100%;' >"
            cv_body_s = cv_body_s + "<tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>PO No.</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("DocEntry").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("전기일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("DocDate").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("만기일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("DocDueDate").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("공급업체") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5' >" + oRSH.Fields.Item("CardName").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("사업장") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("BPLID").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;' colspan='2'>" + CFL.GetCaption("담당자") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:25%;text-align:center;' colspan='5'>" + oRSH.Fields.Item("SlpCode").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:120px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;' colspan='2'>" + CFL.GetCaption("비고") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:93%;text-align:left;' colspan='19'>" + oRSH.Fields.Item("Comments").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr></table></tr>"

            ' 디테일
            If cv_DOCTYPE_s = "I" Then  'Item

                cv_body_s = cv_body_s + "<tr style='height:30px;'> <td style='width:100%;' ><table border='2' style='border-spacing:0;padding:0;width:100%;' > <tr style='height:30px;'> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;' colspan='2'>" + CFL.GetCaption("품목코드") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:22%;text-align:center;' colspan='5'>" + CFL.GetCaption("품목명") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:20%;text-align:center;' colspan='5'>" + CFL.GetCaption("품목상세") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("단위") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("수량") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("통화") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("단가") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("금액") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:4%;text-align:center;' >" + CFL.GetCaption("세금그룹") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("세액") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:9%;text-align:center;' colspan='2'>" + CFL.GetCaption("총금액") + "</td>"
                cv_body_s = cv_body_s + "</tr> </tr>"

                For i = 1 To oRSD.RecordCount

                    cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;;' colspan='2'>" + oRSD.Fields.Item("ItemCode").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='5'>" + oRSD.Fields.Item("ItemName").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='5'>" + oRSD.Fields.Item("ItemDetail").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("Unit").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Quantity").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Price").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' >" + oRSD.Fields.Item("VatCode").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;' colspan='2'>" + oRSD.Fields.Item("Amount").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "</tr>"

                    oRSD.MoveNext()
                Next

                oRSD.MoveLast()
                cv_body_s = cv_body_s + "<tr style='height:30px;'> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='13' >" + CFL.GetCaption("합 계") + "</td> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("Quantity_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' ></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;' colspan='2'>" + oRSD.Fields.Item("Amount_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<tr style='height:30px;'>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='13' >" + CFL.GetCaption("선금총계") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("DpmPrcnt").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='5' ></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("DpmAmnt").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"

            ElseIf cv_DOCTYPE_s = "S" Then  'Service

                cv_body_s = cv_body_s + "<tr style='height:30px;'>  <td style='width:100%;' ><table border='2' style='border-spacing:0;padding:0;width:100%;' > <tr style='height:30px;'> "
                'cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;' colspan='2'></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:32%;text-align:center;' colspan='7'>" + CFL.GetCaption("내역") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:20%;text-align:center;' colspan='5'>" + CFL.GetCaption("계정과목") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("단위") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("수량") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("통화") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("단가") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("금액") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:4%;text-align:center;'>" + CFL.GetCaption("세금그룹") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("세액") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:9%;text-align:center;'  colspan='2'>" + CFL.GetCaption("총금액") + "</td>"
                cv_body_s = cv_body_s + "</tr> </tr>"

                For i = 1 To oRSD.RecordCount

                    cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                    'cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='2'></td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='7'>" + oRSD.Fields.Item("ITEMNM").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='5'>" + oRSD.Fields.Item("ACCTNM").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'></td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'></td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'></td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("VatCode").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'  colspan='2'>" + oRSD.Fields.Item("Amount").Value.ToString() + "</td>"
                    cv_body_s = cv_body_s + "</tr>"

                    oRSD.MoveNext()
                Next

                oRSD.MoveLast()
                cv_body_s = cv_body_s + "<tr style='height:30px;'> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='13' >" + CFL.GetCaption("합 계") + "</td> "
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("DocCur").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' ></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("SupAmt_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;'></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("VatAmt_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'  colspan='2'>" + oRSD.Fields.Item("Amount_Total").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<tr style='height:30px;'>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='13' >" + CFL.GetCaption("선금총계") + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("DpmPrcnt").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='5' ></td>"
                cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'  colspan='2'>" + oRSD.Fields.Item("DpmAmnt").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"

            End If

            cv_TITLE_s = UrlEncode(cv_TITLE_s)
            cv_body_s = UrlEncode(cv_body_s)
            cv_APIKEY_s = UrlEncode(cv_APIKEY_s)

            cv_Jason_s = "formId=" & cv_FormId_s & "&userId=" & cv_EmpNo_s & "&apiConsumerkey=" & cv_APIKEY_s & "&orgApprDocNo=" & cv_ApprDocNo_s & "&apprTitle=" & cv_TITLE_s & "&formEditorData=" & cv_body_s
            'cv_Jason_s = "formId=FORM00590004&userId=admin&apiConsumerkey=" + cv_APIKEY_s + "&orgApprDocNo=aaddff&apprTitle=결재 상신 테스트 제목  &formEditorData=테스트 본문"

            byteData = encoding.GetBytes(cv_Jason_s)

            vHeaders = "Content-Type: application/x-www-form-urlencoded" + Chr(10) + Chr(13)

            Try
                If Not ie Is Nothing Then           ' 분개장 결재창이 띄워져 있는 상태면
                    ie.Quit()                       ' 그 창을 닫아버린다. 만약 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 예외처리함.
                End If

            Catch ex As Exception
                ' 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 그 에러 메세지는 무시하기 위해 Try Catch 문을 써서 에러처리를 함.
            End Try

            ie = New SHDocVw.InternetExplorer()     ' 새로 객체 할당 후 보이게 함..
            ie.Visible = True
            ie.Navigate2(cv_GWURL_s, "POST", , byteData, vHeaders)

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
            B1Connections.theAppl.StatusBar.SetText("SENDODPO ERROR : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub

    ''' <summary>
    ''' 지급요청 전자결재 OPEN
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="DocEntry"></param>
    ''' <param name="ie"></param>
    ''' <remarks></remarks>
    Public Sub SENDOVPM(ByVal oForm As SAPbouiCOM.Form, DocEntry As String, ByRef ie As SHDocVw.InternetExplorer)

        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSH As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSD As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String
        Dim encoding As New UTF8Encoding
        Dim cv_GWURL_s As String = ""
        Dim cv_FormId_s As String = ""
        Dim cv_ApprDocNo_s As String = ""
        Dim cv_APIKEY_s As String = ""
        Dim byteData As Byte()

        Dim cv_Jason_s As String
        Dim cv_body_s As String
        Dim cv_EmpNo_s As String
        Dim cv_TITLE_s As String = ""

        Dim i As Integer

        Dim vHeaders As Object

        Try

            cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN ISNULL(T1.U_DTCRDNO, '') <> '' THEN ISNULL(T1.U_DTCRDNO, '') ELSE T0.U_EMPNO END FROM [@WJS_STR01T] T0 LEFT OUTER JOIN [@WJS_SHR11M] T1 ON T0.U_EMPNO = T1.U_EMPNO WHERE T0.DocEntry = '" & DocEntry & "'")

            xSQL = " EXEC WJS_SP_TRB0010F2_LMS "
            xSQL = xSQL & "  " & CFL.GetQD(DocEntry)
            xSQL = xSQL & ", " & CFL.GetQD(cv_EmpNo_s)
            oRS.DoQuery(xSQL)

            cv_ApprDocNo_s = oRS.Fields.Item("ApprDocNo").Value
            cv_FormId_s = oRS.Fields.Item("FormId").Value
            cv_GWURL_s = oRS.Fields.Item("GWURL").Value
            cv_APIKEY_s = oRS.Fields.Item("APIKEY").Value

            xSQL = " EXEC WJS_SP_TRB0010F3_LMS "
            xSQL = xSQL & "  'H' "
            xSQL = xSQL & ", '" & cv_ApprDocNo_s & "'"
            oRSH.DoQuery(xSQL)

            cv_TITLE_s = oRSH.Fields.Item("FORMTITLE").Value.ToString()
            cv_TITLE_s = Left(cv_TITLE_s, 59)   '59자 제한

            xSQL = " EXEC WJS_SP_TRB0010F3_LMS "
            xSQL = xSQL & "  'D' "
            xSQL = xSQL & ", '" & cv_ApprDocNo_s & "'"
            oRSD.DoQuery(xSQL)

            ' 헤더
            cv_body_s = ""
            cv_body_s = cv_body_s + "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><body><table style='width:100%;' > "
            cv_body_s = cv_body_s + "<tr>"
            cv_body_s = cv_body_s + "<td style='width:100%;' >"
            cv_body_s = cv_body_s + "<table border='2' style='border-spacing:0;padding:0;width:100%;' >"
            cv_body_s = cv_body_s + "<tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;'>" + CFL.GetCaption("요청번호") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:18%;text-align:center;' colspan='2'>" + oRSH.Fields.Item("DocEntry").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;'>" + CFL.GetCaption("요청일자") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:54%;text-align:center;'colspan='2'>" + oRSH.Fields.Item("ReqDate").Value.ToString() + "</td>"
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;'></td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;'>" + CFL.GetCaption("지급방법") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:93%;text-align:left; padding-left:5px;'colspan='13' >" + oRSH.Fields.Item("Descript").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;'>" + CFL.GetCaption("적요") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:93%;text-align:left; padding-left:5px;' colspan='13'>" + oRSH.Fields.Item("Rmk").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr>"

            ' 디테일
            cv_body_s = cv_body_s + "<tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;'>" + CFL.GetCaption("사업장") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;' colspan='2'>" + CFL.GetCaption("지급계정") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;'>" + CFL.GetCaption("공급업체") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:42%;text-align:center;'>" + CFL.GetCaption("상세적요") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;'>" + CFL.GetCaption("금액") + "</td>"
            cv_body_s = cv_body_s + "</tr>"

            For i = 1 To oRSD.RecordCount

                cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("BPLId").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'colspan='2'>" + oRSD.Fields.Item("AcctNm").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRSD.Fields.Item("CardNm").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1; '>" + oRSD.Fields.Item("Rmk").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("ReqAmt").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "</tr>"

                oRSD.MoveNext()
            Next

            oRSD.MoveLast()
            cv_body_s = cv_body_s + "<tr style='height:30px;'> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' ></td> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='4'>" + CFL.GetCaption("소계") + "</td> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRSD.Fields.Item("ReqAmt_Total").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"

            cv_TITLE_s = UrlEncode(cv_TITLE_s)
            cv_body_s = UrlEncode(cv_body_s)
            cv_APIKEY_s = UrlEncode(cv_APIKEY_s)

            cv_Jason_s = "formId=" & cv_FormId_s & "&userId=" & cv_EmpNo_s & "&apiConsumerkey=" & cv_APIKEY_s & "&orgApprDocNo=" & cv_ApprDocNo_s & "&apprTitle=" & cv_TITLE_s & "&formEditorData=" & cv_body_s

            byteData = encoding.GetBytes(cv_Jason_s)

            vHeaders = "Content-Type: application/x-www-form-urlencoded" + Chr(10) + Chr(13)

            Try
                If Not ie Is Nothing Then           ' 분개장 결재창이 띄워져 있는 상태면
                    ie.Quit()                       ' 그 창을 닫아버린다. 만약 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 예외처리함.
                End If

            Catch ex As Exception
                ' 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 그 에러 메세지는 무시하기 위해 Try Catch 문을 써서 에러처리를 함.
            End Try

            ie = New SHDocVw.InternetExplorer()     ' 새로 객체 할당 후 보이게 함..
            ie.Visible = True
            ie.Navigate2(cv_GWURL_s, "POST", , byteData, vHeaders)

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
            B1Connections.theAppl.StatusBar.SetText("SENDOVPM ERROR : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub


    Public Sub SENDFI02(ByVal oForm As SAPbouiCOM.Form, GWDOCNO As String, ByRef ie As SHDocVw.InternetExplorer)

        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSH As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSD As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String
        Dim encoding As New UTF8Encoding
        Dim cv_GWURL_s As String = ""
        Dim cv_FormId_s As String = ""
        Dim cv_ApprDocNo_s As String = ""
        Dim cv_APIKEY_s As String = ""
        Dim byteData As Byte()

        Dim cv_Jason_s As String
        Dim cv_body_s As String
        Dim cv_EmpNo_s As String
        Dim cv_TITLE_s As String = ""

        Dim i As Integer

        Dim vHeaders As Object

        Try

            'cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN MAX(ISNULL(T1.U_DTCRDNO, '')) <> '' THEN MAX(ISNULL(T1.U_DTCRDNO, '')) ELSE MAX(T0.U_EMPNO) END FROM [@WJS_UFI02T_LMS] T0 LEFT OUTER JOIN [@WJS_SHR11M] T1 ON T0.U_EMPNO = T1.U_EMPNO WHERE T0.U_GWDOCNO = '" & GWDOCNO & "'" & "GROUP BY T0.U_GWDOCNO")
            cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN MAX(ISNULL(T1.U_DTCRDNO, '')) <> '' THEN MAX(ISNULL(T1.U_DTCRDNO, '')) ELSE MAX(T0.U_GWEMPNO) END FROM [@WJS_UFI02T_LMS] T0 LEFT OUTER JOIN [@WJS_SHR11M] T1 ON T0.U_GWEMPNO = T1.U_EMPNO WHERE T0.U_GWDOCNO = '" & GWDOCNO & "'" & "GROUP BY T0.U_GWDOCNO")

            xSQL = " EXEC WJS_SP_FIB0070F3_LMS "
            xSQL = xSQL & "  " & CFL.GetQD(GWDOCNO)
            xSQL = xSQL & ", " & CFL.GetQD(cv_EmpNo_s)
            'xSQL = xSQL & ", " & CFL.GetQD(oForm.Items.Item("edtGWDATE").Specific.Value.ToString)

            oRS.DoQuery(xSQL)

            cv_ApprDocNo_s = oRS.Fields.Item("ApprDocNo").Value
            cv_FormId_s = oRS.Fields.Item("FormId").Value
            cv_GWURL_s = oRS.Fields.Item("GWURL").Value
            cv_APIKEY_s = oRS.Fields.Item("APIKEY").Value

            xSQL = " EXEC WJS_SP_FIB0070F2_LMS "
            xSQL = xSQL & "'" & cv_ApprDocNo_s & "'"

            oRS.DoQuery(xSQL)

            cv_TITLE_s = oRS.Fields.Item("FORMTITLE").Value.ToString()
            cv_TITLE_s = Left(cv_TITLE_s, 59)   '59자 제한

            ' 헤더
            cv_body_s = ""
            cv_body_s = cv_body_s + "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><body><table style='width:100%;' > "
            cv_body_s = cv_body_s + "<tr>"

            cv_body_s = cv_body_s + "<td style='width:100%;' >"
            cv_body_s = cv_body_s + "<table border='2' style='border-spacing:0;padding:0;width:100%;' >"
            cv_body_s = cv_body_s + "<tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;'>" + CFL.GetCaption("그룹전표번호") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:10%;text-align:center;' colspan='2'>" + oRS.Fields.Item("GWDOCNO").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;'>" + CFL.GetCaption("전기일자") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:74%;text-align:center;' colspan='12'>" + oRS.Fields.Item("DOCDATE").Value.ToString() + "</td>"
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:14%;text-align:center;'></td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;'>" + CFL.GetCaption("적요") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;width:93%;text-align:left; padding-left:5px;' colspan='15'>" + oRS.Fields.Item("GMEMO").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"

            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;'>" + CFL.GetCaption("전표번호") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;' colspan='2'>" + CFL.GetCaption("비용일자") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;'>" + CFL.GetCaption("계정코드") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;' colspan='2'>" + CFL.GetCaption("계정과목") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;' colspan='2'>" + CFL.GetCaption("제조/손익/BP") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;'>" + CFL.GetCaption("프로젝트") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;' colspan='2'>" + CFL.GetCaption("적요") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("차변") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("대변") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:3%;text-align:center;'>" + CFL.GetCaption("통화") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:4%;text-align:center;'>" + CFL.GetCaption("세금그룹") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("카드번호") + "</td>"
            cv_body_s = cv_body_s + "</tr>"

            For i = 1 To oRS.RecordCount

                cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("Docentry").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='2'>" + oRS.Fields.Item("DOCDATE").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("ACCTCD").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='2'>" + oRS.Fields.Item("ACCTNM").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;' colspan='2'>" + oRS.Fields.Item("OCRNM").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("PROJECT").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:left;padding:0px;border:1;padding-left:5px;' colspan='2'>" + oRS.Fields.Item("MEMO").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("DEBIT").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("CREDIT").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("CURR").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("VATGROUP").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("CARDNO").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "</tr>"

                oRS.MoveNext()
            Next

            'oRS.MoveLast()
            'cv_body_s = cv_body_s + "<tr style='height:30px;'> "
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;text-align:center;padding:0px;border:1;' > " + CFL.GetCaption("합계") + " </td> "
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;text-align:center;padding:0px;border:1;' colspan='7'></td> "
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("DEBIT").Value.ToString() + "</td>"
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("CREDIT").Value.ToString() + "</td>"
            'cv_body_s = cv_body_s + "<td style='font-weight:bold;text-align:center;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("CURR").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"


            cv_TITLE_s = UrlEncode(cv_TITLE_s)
            cv_body_s = UrlEncode(cv_body_s)
            cv_APIKEY_s = UrlEncode(cv_APIKEY_s)

            '테스트할 때 주석 풀기
            'Exit Try

            cv_Jason_s = "formId=" & cv_FormId_s & "&userId=" & cv_EmpNo_s & "&apiConsumerkey=" & cv_APIKEY_s & "&orgApprDocNo=" & cv_ApprDocNo_s & "&apprTitle=" & cv_TITLE_s & "&formEditorData=" & cv_body_s

            byteData = encoding.GetBytes(cv_Jason_s)

            vHeaders = "Content-Type: application/x-www-form-urlencoded" + Chr(10) + Chr(13)

            Try
                If Not ie Is Nothing Then           ' 분개장 결재창이 띄워져 있는 상태면
                    ie.Quit()                       ' 그 창을 닫아버린다. 만약 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 예외처리함.
                End If

            Catch ex As Exception
                '' 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 그 에러 메세지는 무시하기 위해 Try Catch 문을 써서 에러처리를 함.

            End Try

            ie = New SHDocVw.InternetExplorer()     ' 새로 객체 할당 후 보이게 함..
            ie.Visible = True
            ie.Navigate2(cv_GWURL_s, "POST", , byteData, vHeaders)

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
            B1Connections.theAppl.StatusBar.SetText("SENDOPOR ERROR : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub
 ''' <summary>
    ''' 외주가공비정산 전자결재 OPEN   '한국은 사용안함.
    ''' </summary>
    ''' <param name="oForm"></param>
    ''' <param name="DocEntry"></param>
    ''' <param name="ie"></param>
    ''' <remarks></remarks>
    Public Sub SENDPP04(ByVal oForm As SAPbouiCOM.Form, DocEntry As String, ByRef ie As SHDocVw.InternetExplorer)

        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSH As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim oRSD As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        Dim xSQL As String
        Dim encoding As New UTF8Encoding
        Dim cv_GWURL_s As String = ""
        Dim cv_FormId_s As String = ""
        Dim cv_ApprDocNo_s As String = ""
        Dim cv_APIKEY_s As String = ""
        Dim byteData As Byte()

        Dim cv_Jason_s As String
        Dim cv_body_s As String
        Dim cv_EmpNo_s As String
        Dim cv_TITLE_s As String = ""
        Dim i As Integer
        Dim vHeaders As Object

        Try
            cv_EmpNo_s = CFL.GetValue("SELECT CASE WHEN ISNULL(T1.U_DTCRDNO, '') <> '' THEN ISNULL(T1.U_DTCRDNO, '') ELSE T0.U_EMPNO END FROM [@WJS_UPP04T_LMS] T0 LEFT OUTER JOIN [@WJS_SHR11M] T1 ON T0.U_EMPNO = T1.U_EMPNO WHERE T0.DocEntry = '" & DocEntry & "'")

            xSQL = " EXEC WJS_SP_PPB0100F_LMS "
            xSQL = xSQL & "  " & CFL.GetQD(DocEntry)
            xSQL = xSQL & ", " & CFL.GetQD(cv_EmpNo_s)

            oRS.DoQuery(xSQL)

            cv_ApprDocNo_s = oRS.Fields.Item("ApprDocNo").Value
            cv_FormId_s = oRS.Fields.Item("FormId").Value
            cv_GWURL_s = oRS.Fields.Item("GWURL").Value
            cv_APIKEY_s = oRS.Fields.Item("APIKEY").Value

            xSQL = " EXEC WJS_SP_PPB0100F2_LMS "
            xSQL = xSQL & "  " & CFL.GetQD(DocEntry)

            oRS.DoQuery(xSQL)

            cv_TITLE_s = oRS.Fields.Item("FORMTITLE").Value.ToString()
            cv_TITLE_s = Left(cv_TITLE_s, 59)   '59자 제한

            ' 헤더
            cv_body_s = ""
            cv_body_s = cv_body_s + "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><body><table style='width:100%;' > "
            cv_body_s = cv_body_s + "<tr>"

            cv_body_s = cv_body_s + "<td style='width:100%;' >"
            cv_body_s = cv_body_s + "<table border='2' style='border-spacing:0;padding:0;width:100%;' >"
            cv_body_s = cv_body_s + "<tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("문서번호") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;' colspan='2'>" + oRS.Fields.Item("DOCENTRY").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("전기일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:36%;text-align:center;' colspan='3'>" + oRS.Fields.Item("DOCDT").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("만기일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:36%;text-align:center;' colspan='3'>" + oRS.Fields.Item("DUEDT").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("공급업체") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;' colspan='2'>" + oRS.Fields.Item("CARDNM").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("사업장") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:36%;text-align:center;' colspan='3'>" + oRS.Fields.Item("BPLID").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("증빙일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:36%;text-align:center;' colspan='3'>" + oRS.Fields.Item("TAXDT").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("비용계정") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:44%;text-align:center;' colspan='4'>" + oRS.Fields.Item("EACCTNM").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("채무계정") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:44%;text-align:center;' colspan='5'>" + oRS.Fields.Item("LACCTNM").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:60px;'>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("비고") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:95%;text-align:left; padding-left:5px;' colspan='13'>" + oRS.Fields.Item("RMK").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr><tr style='height:30px;'>"

            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("입고일") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;'>" + CFL.GetCaption("품목코드") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;'>" + CFL.GetCaption("품목명") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:6%;text-align:center;'>" + CFL.GetCaption("단위") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:7%;text-align:center;'>" + CFL.GetCaption("정산수량") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("통화") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:8%;text-align:center;'>" + CFL.GetCaption("단가") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:5%;text-align:center;'>" + CFL.GetCaption("세금그룹") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:10%;text-align:center;'>" + CFL.GetCaption("세액") + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;width:12%;text-align:center;'>" + CFL.GetCaption("총금액") + "</td>"
            cv_body_s = cv_body_s + "</tr>"

            For i = 1 To oRS.RecordCount

                cv_body_s = cv_body_s + "<tr style='height:27px;'>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("PINDT").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("ITEMCD").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("ITEMNM").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("UOM").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("INVQTY").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("CURR").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("PRC").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:center;padding:0px;border:1;'>" + oRS.Fields.Item("VATCD").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("VAT").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "<td style='text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("TOTAMT").Value.ToString() + "</td>"
                cv_body_s = cv_body_s + "</tr>"

                oRS.MoveNext()
            Next

            oRS.MoveLast()
            cv_body_s = cv_body_s + "<tr style='height:30px;'> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' colspan='4' >" + CFL.GetCaption("합 계") + "</td> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("QTY").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' >  </td> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' >  </td> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:center;padding:0px;border:1;' >  </td> "
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("SUMVAT").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "<td style='font-weight:bold;background-color:whitesmoke;text-align:right;padding:0px;border:1;padding-right:5px;'>" + oRS.Fields.Item("SUMAMT").Value.ToString() + "</td>"
            cv_body_s = cv_body_s + "</tr></table></td></tr></table></body></html>"

            cv_TITLE_s = UrlEncode(cv_TITLE_s)
            cv_body_s = UrlEncode(cv_body_s)
            cv_APIKEY_s = UrlEncode(cv_APIKEY_s)

            cv_Jason_s = "formId=" & cv_FormId_s & "&userId=" & cv_EmpNo_s & "&apiConsumerkey=" & cv_APIKEY_s & "&orgApprDocNo=" & cv_ApprDocNo_s & "&apprTitle=" & cv_TITLE_s & "&formEditorData=" & cv_body_s

            byteData = encoding.GetBytes(cv_Jason_s)

            vHeaders = "Content-Type: application/x-www-form-urlencoded" + Chr(10) + Chr(13)

            Try
                If Not ie Is Nothing Then           ' 분개장 결재창이 띄워져 있는 상태면
                    ie.Quit()                       ' 그 창을 닫아버린다. 만약 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 예외처리함.
                End If

            Catch ex As Exception
                ' 분개장 결재창을 강제로 닫아버렸으면 에러 발생하는데 그 에러 메세지는 무시하기 위해 Try Catch 문을 써서 에러처리를 함.
            End Try

            ie = New SHDocVw.InternetExplorer()     ' 새로 객체 할당 후 보이게 함..
            ie.Visible = True
            ie.Navigate2(cv_GWURL_s, "POST", , byteData, vHeaders)

        Catch ex As Exception
            CFL.COMMON_MESSAGE("!", ex.Message)
            B1Connections.theAppl.StatusBar.SetText("SENDPP04 ERROR : " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try

    End Sub

    Public Function GetLMSCODE(ByVal sITEMCODE As String) As String
        Dim sLMSCODE As String = ""
        Dim oRS As SAPbobsCOM.Recordset = B1Connections.diCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        Dim xSQL As String = ""
        Try
            xSQL = " SELECT TOP 1 B.PRJCODE AS PRJCD FROM OITM A INNER JOIN OPRJ B ON A.U_NITEMCD = B.PRJCODE WHERE A.ITEMCODE = " & CFL.GetQD(sITEMCODE)
            oRS.DoQuery(xSQL)
            If oRS.RecordCount <> 0 Then
                sLMSCODE = oRS.Fields.Item("PRJCD").Value
            Else
                sLMSCODE = ""
            End If
        Catch ex As Exception
            B1Connections.theAppl.StatusBar.SetText("GetLMSCODE " & Err.Description, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oRS = Nothing
        End Try
        GetLMSCODE = sLMSCODE
    End Function

#End Region

End Module
