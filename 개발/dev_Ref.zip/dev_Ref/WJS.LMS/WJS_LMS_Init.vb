﻿Option Strict Off
Option Explicit On
Imports AddOnBase

Public Class WJS_LMS_Init
    Implements IDisposable

    Dim xSQL As String

    Public Sub New()
        Me.Init()
    End Sub

    Public Sub Init()

        Try

            'B1Connections.theAppl.StatusBar.SetText("WJS_CKH 애드온 실행중...", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)

            CFL.LoadFromXMLMenuCst()

            ''무역 관리
            If (B1Connections.theAppl.Menus.Exists("WJS_TM01_LMS")) Then
                If (Not System.IO.File.Exists(B1Connections.theAppl.Menus.Item("WJS_TM01_LMS").Image())) Then
                    If System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "\IMG\TM.JPG") Then
                        B1Connections.theAppl.Menus.Item("WJS_TM01_LMS").Image = System.Windows.Forms.Application.StartupPath + "\IMG\TM.JPG"
                    End If
                End If
            End If

            ''품질 관리
            If (B1Connections.theAppl.Menus.Exists("WJS_QM00_LMS")) Then
                If (Not System.IO.File.Exists(B1Connections.theAppl.Menus.Item("WJS_QM00_LMS").Image())) Then
                    If System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "\IMG\QM.JPG") Then
                        B1Connections.theAppl.Menus.Item("WJS_QM00_LMS").Image = System.Windows.Forms.Application.StartupPath + "\IMG\QM.JPG"
                    End If
                End If
            End If

            ''설비 관리
            If (B1Connections.theAppl.Menus.Exists("WJS_PM00_LMS")) Then
                If (Not System.IO.File.Exists(B1Connections.theAppl.Menus.Item("WJS_PM00_LMS").Image())) Then
                    If System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "\IMG\PM.JPG") Then
                        B1Connections.theAppl.Menus.Item("WJS_PM00_LMS").Image = System.Windows.Forms.Application.StartupPath + "\IMG\PM.JPG"
                    End If
                End If
            End If

            ''FTA 관리
            If (B1Connections.theAppl.Menus.Exists("WJS_EC00_LMS")) Then
                If (Not System.IO.File.Exists(B1Connections.theAppl.Menus.Item("WJS_EC00_LMS").Image())) Then
                    If System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "\IMG\DM.JPG") Then
                        B1Connections.theAppl.Menus.Item("WJS_EC00_LMS").Image = System.Windows.Forms.Application.StartupPath + "\IMG\DM.JPG"
                    End If
                End If
            End If

            ''인터페이스 관리
            'If (B1Connections.theAppl.Menus.Exists("WJS_AD01_CKH")) Then
            '    If (Not System.IO.File.Exists(B1Connections.theAppl.Menus.Item("WJS_AD01_CKH").Image())) Then
            '        If System.IO.File.Exists(System.Windows.Forms.Application.StartupPath + "\IMG\ECM.JPG") Then
            '            B1Connections.theAppl.Menus.Item("WJS_AD01_CKH").Image = System.Windows.Forms.Application.StartupPath + "\IMG\ECM.JPG"
            '        End If
            '    End If
            'End If

            

            Dim ADSUB As WJS.LMS.LMS_ADDEVT = New LMS.LMS_ADDEVT()

            'B1Connections.theAppl.StatusBar.SetText("WJS_CKH 애드온이 실행 되었습니다.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

        Catch ex As Exception
            B1Connections.theAppl.MessageBox("커스터마이징모듈 생성중 오류가 발생하였습니다. 관리자에게 문의 하십시오." + ex.Message)
        End Try

    End Sub


    Private disposedValue As Boolean = False        ' 중복 호출을 검색하려면

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: 명시적으로 호출되면 관리되지 않는 리소스를 해제합니다.
            End If

            ' TODO: 관리되지 않는 공유 리소스를 해제합니다.
        End If
        Me.disposedValue = True
    End Sub


#Region " IDisposable Support "
    ' 삭제 가능한 패턴을 올바르게 구현하기 위해 Visual Basic에서 추가한 코드입니다.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' 이 코드는 변경하지 마십시오. 위의 Dispose(ByVal disposing As Boolean)에 정리 코드를 입력하십시오.
        Dispose(True)
        'GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class
