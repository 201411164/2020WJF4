﻿Public Class Form2

    Private Sub bt_EXCE_Click(sender As Object, e As EventArgs) Handles bt_EXCE.Click

        Dim Count As Long
        Dim FldName As String
        Dim FldVal As String
        Dim FldName1 As String
        Dim FldVal1 As String
        Dim i As Integer
        Dim RecSet As SAPbobsCOM.Recordset
        Dim CardCode As String
        Dim ItemCode As String
        Dim DocDate As String
        RecSet = Form1.vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        CardCode = TextBox1.Text
        ItemCode = TextBox2.Text
        DocDate = TextBox3.Text

        If CardCode = "" Or ItemCode = "" Or DocDate = "" Then
            MessageBox.Show("모든 값을 입력하시기바랍니다.")
        Else
            RecSet.DoQuery("exec dbo.TEST '" & CardCode & "', '" & ItemCode & "', '" & DocDate & "'")

            Count = RecSet.Fields.Count
            While RecSet.EoF = False

                ''The inner loop runs over all the fields in one record (line) of the table
                'For i = 0 To Count - 1
                '    FldName = RecSet.Fields.Item(i).Name
                '    FldVal = RecSet.Fields.Item(i).Value
                '    FldName1 += FldName + " "
                '    FldVal1 += FldVal + " "

                '    'Here you can manipulate the data as you want
                'Next i
                ''Move to the next record
                'RecSet.MoveNext()

                For i = 0 To Count - 1
                    FldName = RecSet.Fields.Item(i).Name
                    FldName1 += FldName + " "
                    FldVal = RecSet.Fields.Item(i).Value
                    If i <> Count - 1 Then
                        FldVal1 += FldVal + " "
                    Else
                        FldVal1 += FldVal + vbLf
                    End If
                    'Here you can manipulate the data as you want
                Next i
                'Move to the next record
                RecSet.MoveNext()
                If RecSet.EoF <> True Then
                    FldName1 = ""
                End If

            End While
            Me.Close()
            MessageBox.Show(FldName1 + vbLf + FldVal1)
        End If

    End Sub

    Private Sub bt_Cancel_Click(sender As Object, e As EventArgs) Handles bt_Cancel.Click
        Me.Close()
    End Sub
End Class