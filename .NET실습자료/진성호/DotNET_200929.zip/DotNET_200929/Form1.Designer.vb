﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bt_Connection = New System.Windows.Forms.Button()
        Me.bt_Disconnection = New System.Windows.Forms.Button()
        Me.bt_Select = New System.Windows.Forms.Button()
        Me.bt_SP = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bt_Connection
        '
        Me.bt_Connection.Location = New System.Drawing.Point(27, 59)
        Me.bt_Connection.Name = "bt_Connection"
        Me.bt_Connection.Size = New System.Drawing.Size(75, 23)
        Me.bt_Connection.TabIndex = 0
        Me.bt_Connection.Text = "연결"
        Me.bt_Connection.UseVisualStyleBackColor = True
        '
        'bt_Disconnection
        '
        Me.bt_Disconnection.Location = New System.Drawing.Point(137, 59)
        Me.bt_Disconnection.Name = "bt_Disconnection"
        Me.bt_Disconnection.Size = New System.Drawing.Size(75, 23)
        Me.bt_Disconnection.TabIndex = 1
        Me.bt_Disconnection.Text = "해제"
        Me.bt_Disconnection.UseVisualStyleBackColor = True
        '
        'bt_Select
        '
        Me.bt_Select.Location = New System.Drawing.Point(27, 105)
        Me.bt_Select.Name = "bt_Select"
        Me.bt_Select.Size = New System.Drawing.Size(75, 23)
        Me.bt_Select.TabIndex = 2
        Me.bt_Select.Text = "조회"
        Me.bt_Select.UseVisualStyleBackColor = True
        '
        'bt_SP
        '
        Me.bt_SP.Location = New System.Drawing.Point(137, 105)
        Me.bt_SP.Name = "bt_SP"
        Me.bt_SP.Size = New System.Drawing.Size(95, 23)
        Me.bt_SP.TabIndex = 3
        Me.bt_SP.Text = "저장프로시저"
        Me.bt_SP.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 214)
        Me.Controls.Add(Me.bt_SP)
        Me.Controls.Add(Me.bt_Select)
        Me.Controls.Add(Me.bt_Disconnection)
        Me.Controls.Add(Me.bt_Connection)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bt_Connection As System.Windows.Forms.Button
    Friend WithEvents bt_Disconnection As System.Windows.Forms.Button
    Friend WithEvents bt_Select As System.Windows.Forms.Button
    Friend WithEvents bt_SP As System.Windows.Forms.Button

End Class
