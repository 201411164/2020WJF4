﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bt_Connect = New System.Windows.Forms.Button()
        Me.bt_Disconnect = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_ItemCode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.bt_Remove = New System.Windows.Forms.Button()
        Me.txt_ItemName = New System.Windows.Forms.TextBox()
        Me.bt_Select = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bt_Connect
        '
        Me.bt_Connect.Location = New System.Drawing.Point(328, 24)
        Me.bt_Connect.Name = "bt_Connect"
        Me.bt_Connect.Size = New System.Drawing.Size(75, 23)
        Me.bt_Connect.TabIndex = 0
        Me.bt_Connect.Text = "연결"
        Me.bt_Connect.UseVisualStyleBackColor = True
        '
        'bt_Disconnect
        '
        Me.bt_Disconnect.Location = New System.Drawing.Point(328, 74)
        Me.bt_Disconnect.Name = "bt_Disconnect"
        Me.bt_Disconnect.Size = New System.Drawing.Size(75, 23)
        Me.bt_Disconnect.TabIndex = 1
        Me.bt_Disconnect.Text = "해제"
        Me.bt_Disconnect.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ItemCode"
        '
        'txt_ItemCode
        '
        Me.txt_ItemCode.Location = New System.Drawing.Point(111, 26)
        Me.txt_ItemCode.Name = "txt_ItemCode"
        Me.txt_ItemCode.Size = New System.Drawing.Size(100, 21)
        Me.txt_ItemCode.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "내역"
        '
        'bt_Remove
        '
        Me.bt_Remove.Location = New System.Drawing.Point(164, 113)
        Me.bt_Remove.Name = "bt_Remove"
        Me.bt_Remove.Size = New System.Drawing.Size(75, 23)
        Me.bt_Remove.TabIndex = 5
        Me.bt_Remove.Text = "삭제"
        Me.bt_Remove.UseVisualStyleBackColor = True
        '
        'txt_ItemName
        '
        Me.txt_ItemName.Location = New System.Drawing.Point(111, 71)
        Me.txt_ItemName.Name = "txt_ItemName"
        Me.txt_ItemName.Size = New System.Drawing.Size(152, 21)
        Me.txt_ItemName.TabIndex = 6
        '
        'bt_Select
        '
        Me.bt_Select.Location = New System.Drawing.Point(65, 113)
        Me.bt_Select.Name = "bt_Select"
        Me.bt_Select.Size = New System.Drawing.Size(75, 23)
        Me.bt_Select.TabIndex = 7
        Me.bt_Select.Text = "조회"
        Me.bt_Select.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 170)
        Me.Controls.Add(Me.bt_Select)
        Me.Controls.Add(Me.txt_ItemName)
        Me.Controls.Add(Me.bt_Remove)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_ItemCode)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.bt_Disconnect)
        Me.Controls.Add(Me.bt_Connect)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bt_Connect As System.Windows.Forms.Button
    Friend WithEvents bt_Disconnect As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_ItemCode As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents bt_Remove As System.Windows.Forms.Button
    Friend WithEvents txt_ItemName As System.Windows.Forms.TextBox
    Friend WithEvents bt_Select As System.Windows.Forms.Button

End Class
