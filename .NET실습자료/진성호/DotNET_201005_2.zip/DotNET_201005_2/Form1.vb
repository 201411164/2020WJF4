﻿Public Class Form1
    Public vCompany As SAPbobsCOM.Company
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vCompany = New SAPbobsCOM.Company
    End Sub

    Private Sub bt_Connect_Click(sender As Object, e As EventArgs) Handles bt_Connect.Click
        'Initialize the Company Object for the Connect method
        vCompany.Server = "77106151-PC\MSSQLSERVER_2017"
        vCompany.CompanyDB = "SBODemoKR"
        vCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017
        vCompany.UserName = "manager"
        vCompany.Password = "manager"

        Dim nResult As Long
        Dim strErrString As String

        'Connect to the database
        nResult = vCompany.Connect

        'Display the result
        MsgBox("result is " + Str(nResult))
        Call vCompany.GetLastError(nResult, strErrString)
        MsgBox("GetLastError(" + Str(nResult) + ", " + strErrString + ")")
    End Sub

    Private Sub bt_Disconnect_Click(sender As Object, e As EventArgs) Handles bt_Disconnect.Click
        If vCompany.Connected = False Then
            MsgBox("이미 해제되어 있습니다.")
        Else
            vCompany.Disconnect()

            If vCompany.Connected = False Then
                MsgBox("해제성공")
            Else
                MsgBox("해제실패")
            End If
        End If
    End Sub

    Private Sub bt_Remove_Click(sender As Object, e As EventArgs) Handles bt_Remove.Click

        Dim nErr As Long
        Dim errMsg As String
        Dim vItems As SAPbobsCOM.Items
        vItems = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
        Dim ItemCode As String
        Dim ItemRemove As String
        Dim ItemCode_Check As String

        ItemCode = txt_ItemCode.Text
        ItemCode_Check = ItemCode.Substring(0, 2)

        'Get the required record of the current object
        If (vItems.GetByKey(ItemCode) = True) And (ItemCode_Check = "SH") Then
            'Update the required properties
            ItemRemove = vItems.ItemCode
            Call vItems.Remove()

            If (vItems.GetByKey(ItemCode) = False) Then
                MessageBox.Show("[ 삭제 사항 적용 완료 ]" + vbLf + "* 삭제 품목 번호 = " + ItemCode)
                txt_ItemCode.Clear()
                txt_ItemName.Clear()
            Else
                MessageBox.Show("삭제 사항이 적용되지 않았습니다.")
            End If
        ElseIf (vItems.GetByKey(ItemCode) = True) And (ItemCode_Check <> "SH") Then
            MessageBox.Show("삭제 할 수 없는 품목입니다.")
        Else
            MessageBox.Show("해당 품목이 존재하지 않습니다.")
        End If

        

        'check for errors
        Call vCompany.GetLastError(nErr, errMsg)
        If (0 <> nErr) Then
            MsgBox("Found error:" + Str(nErr) + "," + errMsg)
        End If

    End Sub

    Private Sub bt_Select_Click(sender As Object, e As EventArgs) Handles bt_Select.Click
        Dim RetVal As Long
        Dim vItems As SAPbobsCOM.Items
        vItems = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
        Dim ItemCode As String
        Dim ItemName As String
        Dim ErrCode As Long
        Dim ErrMsg As String

        ItemCode = txt_ItemCode.Text

        'Retrieve a record by its key from the database
        RetVal = vItems.GetByKey(ItemCode)

        'Check errors
        If RetVal <> -1 Then
            vCompany.GetLastError(ErrCode, ErrMsg)
            MsgBox("Failed to Retrieve the record " & ErrCode & " " & ErrMsg)
            Exit Sub
        End If

        txt_ItemCode.Text = vItems.ItemCode.ToString
        txt_ItemName.Text = vItems.ItemName.ToString
    End Sub
End Class
