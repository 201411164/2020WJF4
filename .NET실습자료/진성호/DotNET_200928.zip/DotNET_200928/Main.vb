﻿Public Class Main

    'Private myConn As SqlConnection 'DB 연결 설정
    'Private myCmd As SqlCommand '쿼리 실행
    'Private myReader As SqlDataReader '쿼리 결과 검색
    'Private results As String

    Public myConn As SqlConnection 'DB 연결 설정
    Public myCmd As SqlCommand '쿼리 실행
    Public myReader As SqlDataReader '쿼리 결과 검색
    Public results As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        TextBox1.Text = "TESTDB"
        TextBox2.Text = "77106151-PC\MSSQLSERVER_2017"
        TextBox3.Text = "SSPI"

    End Sub


    Private Sub bt_Connection_Click(sender As Object, e As EventArgs) Handles bt_Connection.Click

        Dim sConStr As String = "Initial Catalog=" & TextBox1.Text & ";Data Source=" & TextBox2.Text & ";Integrated Security=" & TextBox3.Text & ";"

        If myConn Is Nothing Then
            myConn = New SqlConnection(sConStr)
        End If

        If myConn.State = ConnectionState.Open Then
            MsgBox("이미 연결되어 있습니다.")

        Else

            MsgBox(sConStr & " 으로 연결합니다.")

            Try
                myConn.Open()

                If myConn.State = ConnectionState.Open Then
                    MsgBox("연결성공")
                Else
                    MsgBox("연결실패")
                End If


            Catch ex As Exception

                MsgBox(Err.Description)

            End Try

        End If

    End Sub

    Private Sub bt_Disconnection_Click(sender As Object, e As EventArgs) Handles bt_Disconnection.Click

        If myConn.State = ConnectionState.Closed Then
            MsgBox("이미 해제되어 있습니다.")
        Else
            myConn.Close()

            If myConn.State = ConnectionState.Closed Then
                MsgBox("해제성공")
            Else
                MsgBox("해제실패")
            End If
        End If

    End Sub

    Private Sub bt_Select_Click(sender As Object, e As EventArgs) Handles bt_Select.Click

        Using myCmd As New SqlCommand()
            With myCmd
                .Connection = myConn
                .CommandType = CommandType.Text
                .CommandText = "SELECT * FROM TESTTABLE"
            End With

            Try
                myReader = myCmd.ExecuteReader()

                Do While myReader.Read()
                    results = results & myReader.GetString(0) & vbTab & myReader.GetString(1) & vbLf  'String Type만 가져올 수 있다.
                Loop
                MsgBox(results)

            Catch ex As Exception

                MessageBox.Show(ex.Message.ToString(), "Error Message")

            Finally

                results = ""

                If myReader.IsClosed = False Then
                    myReader.Close()
                End If

                myReader = Nothing

            End Try

        End Using
    End Sub

    Private Sub bt_Insert_Click(sender As Object, e As EventArgs) Handles bt_Insert.Click

        Dim InsertForm As New Insert()
        InsertForm.Show()


    End Sub

    Private Sub bt_Update_Click(sender As Object, e As EventArgs) Handles bt_Update.Click

        Dim UpdateForm As New Update()
        UpdateForm.Show()


    End Sub

    Private Sub bt_Delete_Click(sender As Object, e As EventArgs) Handles bt_Delete.Click

        Dim DeleteForm As New Delete()
        DeleteForm.Show()


    End Sub
End Class
