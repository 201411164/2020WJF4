﻿Public Class Delete

    Public D_Column1 As String
    Public D_Column2 As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        D_Column1 = TextBox1.Text
        D_Column2 = TextBox2.Text

        Dim a As Integer

        Using myCmd As New SqlCommand()

            With myCmd
                .Connection = Main.myConn
                .CommandType = CommandType.Text
                If D_Column1 = "" Or D_Column2 = "" Then
                    MessageBox.Show("삭제할 Column1과 Column2 모두 입력하시기바랍니다.")
                Else
                    .CommandText = "DELETE FROM TESTTABLE WHERE Column1 = " & Me.D_Column1 & " AND Column2 = " & Me.D_Column2

                    Try
                        a = .ExecuteNonQuery()

                    Catch ex As Exception

                        MessageBox.Show(ex.Message.ToString(), "Error Message")

                    End Try

                    If a <> -1 Then
                        MessageBox.Show("삭제완료", "Info Message")
                        Me.Close()
                    Else
                        MessageBox.Show("삭제실패", "Error Message")
                        Me.Close()
                    End If

                End If

            End With


        End Using


        'Dim a As Integer

        'Using myCmd As New SqlCommand()

        '    With myCmd
        '        .Connection = myConn
        '        .CommandType = CommandType.Text
        '        .CommandText = "DELETE FROM TESTTABLE WHERE Column1 = @param1"
        '        .Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = "500"

        '        Try
        '            a = .ExecuteNonQuery()

        '        Catch ex As Exception

        '            MessageBox.Show(ex.Message.ToString(), "Error Message")

        '        End Try

        '        If a <> -1 Then
        '            MessageBox.Show("삭제완료", "Info Message")
        '        Else
        '            MessageBox.Show("삭제실패", "Error Message")
        '        End If

        '    End With


        'End Using

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class