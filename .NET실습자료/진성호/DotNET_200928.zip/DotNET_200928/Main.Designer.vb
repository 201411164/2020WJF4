﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.bt_Connection = New System.Windows.Forms.Button()
        Me.bt_Disconnection = New System.Windows.Forms.Button()
        Me.bt_Select = New System.Windows.Forms.Button()
        Me.bt_Insert = New System.Windows.Forms.Button()
        Me.bt_Update = New System.Windows.Forms.Button()
        Me.bt_Delete = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Initial Catalog"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Data Source"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Integrated Security"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(165, 24)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(146, 21)
        Me.TextBox1.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(165, 55)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(146, 21)
        Me.TextBox2.TabIndex = 4
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(165, 87)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(146, 21)
        Me.TextBox3.TabIndex = 5
        '
        'bt_Connection
        '
        Me.bt_Connection.Location = New System.Drawing.Point(427, 22)
        Me.bt_Connection.Name = "bt_Connection"
        Me.bt_Connection.Size = New System.Drawing.Size(75, 23)
        Me.bt_Connection.TabIndex = 6
        Me.bt_Connection.Text = "연결"
        Me.bt_Connection.UseVisualStyleBackColor = True
        '
        'bt_Disconnection
        '
        Me.bt_Disconnection.Location = New System.Drawing.Point(539, 22)
        Me.bt_Disconnection.Name = "bt_Disconnection"
        Me.bt_Disconnection.Size = New System.Drawing.Size(75, 23)
        Me.bt_Disconnection.TabIndex = 7
        Me.bt_Disconnection.Text = "해제"
        Me.bt_Disconnection.UseVisualStyleBackColor = True
        '
        'bt_Select
        '
        Me.bt_Select.Location = New System.Drawing.Point(427, 85)
        Me.bt_Select.Name = "bt_Select"
        Me.bt_Select.Size = New System.Drawing.Size(75, 23)
        Me.bt_Select.TabIndex = 8
        Me.bt_Select.Text = "조회"
        Me.bt_Select.UseVisualStyleBackColor = True
        '
        'bt_Insert
        '
        Me.bt_Insert.Location = New System.Drawing.Point(539, 85)
        Me.bt_Insert.Name = "bt_Insert"
        Me.bt_Insert.Size = New System.Drawing.Size(75, 23)
        Me.bt_Insert.TabIndex = 9
        Me.bt_Insert.Text = "입력"
        Me.bt_Insert.UseVisualStyleBackColor = True
        '
        'bt_Update
        '
        Me.bt_Update.Location = New System.Drawing.Point(650, 85)
        Me.bt_Update.Name = "bt_Update"
        Me.bt_Update.Size = New System.Drawing.Size(75, 23)
        Me.bt_Update.TabIndex = 10
        Me.bt_Update.Text = "수정"
        Me.bt_Update.UseVisualStyleBackColor = True
        '
        'bt_Delete
        '
        Me.bt_Delete.Location = New System.Drawing.Point(761, 85)
        Me.bt_Delete.Name = "bt_Delete"
        Me.bt_Delete.Size = New System.Drawing.Size(75, 23)
        Me.bt_Delete.TabIndex = 11
        Me.bt_Delete.Text = "삭제"
        Me.bt_Delete.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(937, 441)
        Me.Controls.Add(Me.bt_Delete)
        Me.Controls.Add(Me.bt_Update)
        Me.Controls.Add(Me.bt_Insert)
        Me.Controls.Add(Me.bt_Select)
        Me.Controls.Add(Me.bt_Disconnection)
        Me.Controls.Add(Me.bt_Connection)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Main"
        Me.Text = "MAIN"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents bt_Connection As System.Windows.Forms.Button
    Friend WithEvents bt_Disconnection As System.Windows.Forms.Button
    Friend WithEvents bt_Select As System.Windows.Forms.Button
    Friend WithEvents bt_Insert As System.Windows.Forms.Button
    Friend WithEvents bt_Update As System.Windows.Forms.Button
    Friend WithEvents bt_Delete As System.Windows.Forms.Button

End Class
