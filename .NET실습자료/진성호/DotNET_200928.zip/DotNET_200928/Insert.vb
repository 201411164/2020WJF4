﻿Public Class Insert

    Public I_Column1 As String
    Public I_Column2 As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        I_Column1 = TextBox1.Text
        I_Column2 = TextBox2.Text

        Dim a As Integer

        Using myCmd As New SqlCommand()

            With myCmd
                .Connection = Main.myConn
                .CommandType = CommandType.Text

                If I_Column1 = "" Or I_Column2 = "" Then
                    MessageBox.Show("Column1과 Column2 모두 입력하시기바랍니다.")

                Else
                    .CommandText = "INSERT INTO TESTTABLE SELECT '" & Me.I_Column1 & "', '" & Me.I_Column2 & "'"

                    Try
                        a = .ExecuteNonQuery()

                    Catch ex As Exception

                        MessageBox.Show(ex.Message.ToString(), "Error Message")

                    End Try

                    If a <> -1 Then
                        MessageBox.Show("입력완료", "Info Message")
                        Me.Close()
                    Else
                        MessageBox.Show("입력실패", "Error Message")
                        Me.Close()
                    End If

                End If             

            End With


        End Using
        'Dim a As Integer

        'Using myCmd As New SqlCommand()

        '    With myCmd
        '        .Connection = myConn
        '        .CommandType = CommandType.Text
        '        .CommandText = "INSERT INTO TESTTABLE (Column1, Column2) Values (@param1, @param2)"
        '        .Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = "3"
        '        .Parameters.Add("@param2", SqlDbType.NChar, 10).Value = "1"

        '        Try
        '            a = .ExecuteNonQuery()

        '        Catch ex As Exception

        '            MessageBox.Show(ex.Message.ToString(), "Error Message")

        '        End Try

        '        If a <> -1 Then
        '            MessageBox.Show("입력완료", "Info Message")
        '        Else
        '            MessageBox.Show("입력실패", "Error Message")
        '        End If

        '    End With


        'End Using

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class