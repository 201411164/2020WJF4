﻿Public Class Update

    Public U_Column1B As String
    Public U_Column1A As String
    Public U_Column2B As String
    Public U_Column2A As String

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub bt_Update_Ok_Click(sender As Object, e As EventArgs) Handles bt_Update_Ok.Click

        U_Column1B = TextBox1.Text
        U_Column1A = TextBox2.Text

        U_Column2B = TextBox3.Text
        U_Column2A = TextBox4.Text

        Dim a As Integer

        Using myCmd As New SqlCommand()

            With myCmd
                .Connection = Main.myConn
                .CommandType = CommandType.Text
                If U_Column1A = "" Or U_Column1B = "" Or U_Column2A = "" Or U_Column2B = "" Then
                    MessageBox.Show("모든 값을 다 입력하시기바랍니다.")
                Else
                    .CommandText = "UPDATE TESTTABLE SET Column1 = " & Me.U_Column1A & ", Column2 = " & Me.U_Column2A & " WHERE Column1 = " & Me.U_Column1B & "AND Column2 = " & Me.U_Column2B

                    Try
                        a = .ExecuteNonQuery()

                    Catch ex As Exception

                        MessageBox.Show(ex.Message.ToString(), "Error Message")

                    End Try

                    If a <> -1 Then
                        MessageBox.Show("수정완료", "Info Message")
                        Me.Close()
                    Else
                        MessageBox.Show("수정실패", "Error Message")
                        Me.Close()
                    End If

                End If

            End With

        End Using

    End Sub

    Private Sub bt_Update_Cancel_Click(sender As Object, e As EventArgs) Handles bt_Update_Cancel.Click

        Me.Close()

    End Sub
End Class