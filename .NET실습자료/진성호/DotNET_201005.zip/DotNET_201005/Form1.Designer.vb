﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_CardCode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_CardType = New System.Windows.Forms.TextBox()
        Me.txt_CardName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_Cellular = New System.Windows.Forms.TextBox()
        Me.lb_Cellular = New System.Windows.Forms.Label()
        Me.bt_Select = New System.Windows.Forms.Button()
        Me.bt_Connect = New System.Windows.Forms.Button()
        Me.bt_Disconnect = New System.Windows.Forms.Button()
        Me.bt_Update = New System.Windows.Forms.Button()
        Me.bt_Update_OK = New System.Windows.Forms.Button()
        Me.bt_Close = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(46, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "CardCode"
        '
        'txt_CardCode
        '
        Me.txt_CardCode.Location = New System.Drawing.Point(114, 28)
        Me.txt_CardCode.Name = "txt_CardCode"
        Me.txt_CardCode.Size = New System.Drawing.Size(163, 21)
        Me.txt_CardCode.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(46, 124)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "비즈니스파트너유형"
        '
        'txt_CardType
        '
        Me.txt_CardType.Location = New System.Drawing.Point(165, 121)
        Me.txt_CardType.Name = "txt_CardType"
        Me.txt_CardType.Size = New System.Drawing.Size(163, 21)
        Me.txt_CardType.TabIndex = 3
        '
        'txt_CardName
        '
        Me.txt_CardName.Location = New System.Drawing.Point(165, 164)
        Me.txt_CardName.Name = "txt_CardName"
        Me.txt_CardName.Size = New System.Drawing.Size(163, 21)
        Me.txt_CardName.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(46, 167)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(113, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "비즈니스파트너이름"
        '
        'txt_Cellular
        '
        Me.txt_Cellular.Location = New System.Drawing.Point(165, 207)
        Me.txt_Cellular.Name = "txt_Cellular"
        Me.txt_Cellular.Size = New System.Drawing.Size(163, 21)
        Me.txt_Cellular.TabIndex = 7
        '
        'lb_Cellular
        '
        Me.lb_Cellular.AutoSize = True
        Me.lb_Cellular.Location = New System.Drawing.Point(46, 210)
        Me.lb_Cellular.Name = "lb_Cellular"
        Me.lb_Cellular.Size = New System.Drawing.Size(69, 12)
        Me.lb_Cellular.TabIndex = 6
        Me.lb_Cellular.Text = "휴대폰 번호"
        '
        'bt_Select
        '
        Me.bt_Select.Location = New System.Drawing.Point(84, 68)
        Me.bt_Select.Name = "bt_Select"
        Me.bt_Select.Size = New System.Drawing.Size(75, 23)
        Me.bt_Select.TabIndex = 8
        Me.bt_Select.Text = "조회"
        Me.bt_Select.UseVisualStyleBackColor = True
        '
        'bt_Connect
        '
        Me.bt_Connect.Location = New System.Drawing.Point(354, 28)
        Me.bt_Connect.Name = "bt_Connect"
        Me.bt_Connect.Size = New System.Drawing.Size(75, 23)
        Me.bt_Connect.TabIndex = 9
        Me.bt_Connect.Text = "연결"
        Me.bt_Connect.UseVisualStyleBackColor = True
        '
        'bt_Disconnect
        '
        Me.bt_Disconnect.Location = New System.Drawing.Point(354, 68)
        Me.bt_Disconnect.Name = "bt_Disconnect"
        Me.bt_Disconnect.Size = New System.Drawing.Size(75, 23)
        Me.bt_Disconnect.TabIndex = 10
        Me.bt_Disconnect.Text = "해제"
        Me.bt_Disconnect.UseVisualStyleBackColor = True
        '
        'bt_Update
        '
        Me.bt_Update.Location = New System.Drawing.Point(202, 68)
        Me.bt_Update.Name = "bt_Update"
        Me.bt_Update.Size = New System.Drawing.Size(75, 23)
        Me.bt_Update.TabIndex = 11
        Me.bt_Update.Text = "변경"
        Me.bt_Update.UseVisualStyleBackColor = True
        '
        'bt_Update_OK
        '
        Me.bt_Update_OK.Location = New System.Drawing.Point(354, 205)
        Me.bt_Update_OK.Name = "bt_Update_OK"
        Me.bt_Update_OK.Size = New System.Drawing.Size(75, 23)
        Me.bt_Update_OK.TabIndex = 12
        Me.bt_Update_OK.Text = "확인"
        Me.bt_Update_OK.UseVisualStyleBackColor = True
        '
        'bt_Close
        '
        Me.bt_Close.Location = New System.Drawing.Point(212, 248)
        Me.bt_Close.Name = "bt_Close"
        Me.bt_Close.Size = New System.Drawing.Size(75, 23)
        Me.bt_Close.TabIndex = 13
        Me.bt_Close.Text = "닫기"
        Me.bt_Close.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(498, 283)
        Me.Controls.Add(Me.bt_Close)
        Me.Controls.Add(Me.bt_Update_OK)
        Me.Controls.Add(Me.bt_Update)
        Me.Controls.Add(Me.bt_Disconnect)
        Me.Controls.Add(Me.bt_Connect)
        Me.Controls.Add(Me.bt_Select)
        Me.Controls.Add(Me.txt_Cellular)
        Me.Controls.Add(Me.lb_Cellular)
        Me.Controls.Add(Me.txt_CardName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_CardType)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_CardCode)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_CardCode As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_CardType As System.Windows.Forms.TextBox
    Friend WithEvents txt_CardName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_Cellular As System.Windows.Forms.TextBox
    Friend WithEvents lb_Cellular As System.Windows.Forms.Label
    Friend WithEvents bt_Select As System.Windows.Forms.Button
    Friend WithEvents bt_Connect As System.Windows.Forms.Button
    Friend WithEvents bt_Disconnect As System.Windows.Forms.Button
    Friend WithEvents bt_Update As System.Windows.Forms.Button
    Friend WithEvents bt_Update_OK As System.Windows.Forms.Button
    Friend WithEvents bt_Close As System.Windows.Forms.Button

End Class
