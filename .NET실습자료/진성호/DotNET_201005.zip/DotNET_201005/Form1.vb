﻿Public Class Form1
    Public vCompany As SAPbobsCOM.Company

    Private Sub bt_Connect_Click(sender As Object, e As EventArgs) Handles bt_Connect.Click

        'Initialize the Company Object for the Connect method
        vCompany.Server = "77106151-PC\MSSQLSERVER_2017"
        vCompany.CompanyDB = "SBODemoKR"
        vCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017
        vCompany.UserName = "manager"
        vCompany.Password = "manager"

        Dim nResult As Long
        Dim strErrString As String

        'Connect to the database
        nResult = vCompany.Connect

        'Display the result
        MsgBox("result is " + Str(nResult))
        Call vCompany.GetLastError(nResult, strErrString)
        MsgBox("GetLastError(" + Str(nResult) + ", " + strErrString + ")")

    End Sub

    Private Sub bt_Disconnect_Click(sender As Object, e As EventArgs) Handles bt_Disconnect.Click

        If vCompany.Connected = False Then
            MsgBox("이미 해제되어 있습니다.")
        Else
            vCompany.Disconnect()

            If vCompany.Connected = False Then
                MsgBox("해제성공")
            Else
                MsgBox("해제실패")
            End If
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vCompany = New SAPbobsCOM.Company
        bt_Update_OK.Hide()
    End Sub

    Private Sub bt_Select_Click(sender As Object, e As EventArgs) Handles bt_Select.Click

        Dim RetVal As Long
        Dim vBP As SAPbobsCOM.BusinessPartners
        vBP = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)
        Dim BPCode As String
        Dim ErrCode As Long
        Dim ErrMsg As String

        BPCode = txt_CardCode.Text

        'Retrieve a record by its key from the database
        RetVal = vBP.GetByKey(BPCode)

        'Check errors
        If RetVal <> -1 Then
            vCompany.GetLastError(ErrCode, ErrMsg)
            MsgBox("Failed to Retrieve the record " & ErrCode & " " & ErrMsg)
            Exit Sub
        End If

        txt_CardType.Text = vBP.CardType.ToString
        txt_CardName.Text = vBP.CardName.ToString
        txt_Cellular.Text = vBP.Cellular.ToString



    End Sub

    Private Sub bt_Update_Click(sender As Object, e As EventArgs) Handles bt_Update.Click

        lb_Cellular.Text = "변경할 휴대폰 번호"
        txt_Cellular.Clear()
        bt_Update_OK.Visible = True

    End Sub

    Private Sub bt_Update_OK_Click(sender As Object, e As EventArgs) Handles bt_Update_OK.Click

        Dim nErr As Long
        Dim errMsg As String
        Dim vBP As SAPbobsCOM.BusinessPartners
        vBP = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)
        Dim BPCode As String
        Dim BPCellular_After As String
        Dim BPCellular_Before As String

        BPCode = txt_CardCode.Text
        BPCellular_After = txt_Cellular.Text

        'Get the required record of the current object
        If (vBP.GetByKey(BPCode) = True) Then
            'Update the required properties
            BPCellular_Before = vBP.Cellular
            vBP.Cellular = BPCellular_After
            If (BPCellular_After = BPCellular_Before) Then
                MessageBox.Show("이전 값과 변경할 값이 같습니다.")
                txt_Cellular.Clear()
            Else
                Call vBP.Update()

                If (vBP.GetByKey(BPCode) = True) Then
                    If (vBP.Cellular = BPCellular_After) Then
                        MessageBox.Show("[ 변경사항 적용 완료 ]" + vbLf + "* 변경 전 휴대폰 번호 = " + BPCellular_Before + vbLf + "* 변경 후 휴대폰 번호 = " + vBP.Cellular)
                        lb_Cellular.Text = "휴대폰 번호"
                        bt_Update_OK.Hide()
                    Else
                        MessageBox.Show("변경사항이 적용되지 않았습니다.")
                        txt_Cellular.Text = BPCellular_Before
                    End If
                End If

            End If
        End If

        'check for errors
        Call vCompany.GetLastError(nErr, errMsg)
        If (0 <> nErr) Then
            MsgBox("Found error:" + Str(nErr) + "," + errMsg)
        End If

    End Sub

    Private Sub bt_Close_Click(sender As Object, e As EventArgs) Handles bt_Close.Click
        Close()
    End Sub
End Class
